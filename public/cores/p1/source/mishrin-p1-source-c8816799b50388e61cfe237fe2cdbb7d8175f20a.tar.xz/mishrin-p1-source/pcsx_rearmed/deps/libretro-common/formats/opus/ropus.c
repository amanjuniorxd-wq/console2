/* Copyright  (C) 2010-2026 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (ropus.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial
 * portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT
 * LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* ropus.c -- standalone Opus audio decoder (RFC 6716).
 *
 * A single-file Opus decoder covering SILK, CELT and hybrid modes,
 * mono and stereo, at all frame sizes, decoding to 48 kHz.  Two
 * independent output pipelines are provided:
 *
 *   - ropus_decode_s16(): bit-exact with a libopus 1.4 FIXED_POINT
 *     build's opus_decode().
 *   - ropus_decode_f32(): bit-exact with a libopus 1.4 float build's
 *     opus_decode_float().
 *
 * SILK is decoded in its native fixed-point form and shared by both
 * pipelines (the float pipeline scales by 1/32768 exactly as libopus
 * does); CELT is implemented twice, once in float and once in fixed
 * point, so neither pipeline ever converts through the other's
 *  numeric domain.
 *
 * Derived from the libopus 1.4 reference implementation
 * (BSD licensed, Copyright (c) Xiph.Org Foundation, Skype Limited);
 * quantization tables are extracted from it verbatim.
 *
 * Intentional limitations (media-player scope):
 *   - no PLC/CNG/FEC: intended for loss-free file playback.  Packets
 *     must be presented in order and complete.
 *   - transitions between CELT-only and SILK/hybrid modes decode
 *     without the 2.5 ms concealment crossfade libopus performs;
 *     encoders emit in-band redundancy at these boundaries (handled
 *     exactly), in which case libopus skips the crossfade too and the
 *     output remains bit-exact.
 *   - channel mapping family 0 only (mono/stereo, no multistream).
 */

#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include <retro_inline.h>

/* SIMD kernels for the hot CELT loops (FFT butterflies, MDCT rotates,
 * TDAC, band scaling).  Every vector path performs the same IEEE
 * operations per element in the same order as the scalar code, so the
 * output stays bit-identical; the scalar code remains the reference
 * and the fallback.  NEON float is enabled on AArch64 only: ARMv7
 * NEON flushes denormals to zero, which would break bit-exactness on
 * decaying tails.  Define ROPUS_NO_SIMD to force the scalar paths. */
#if !defined(ROPUS_NO_SIMD)
#if defined(__SSE2__) || defined(_M_X64) ||       (defined(_M_IX86_FP) && _M_IX86_FP >= 2)
#define ROPUS_SSE2 1
#include <emmintrin.h>
#elif defined(__aarch64__) && defined(__ARM_NEON)
#define ROPUS_NEON 1
#include <arm_neon.h>
#endif
#endif

/* ==================================================================== */
/* Range decoder (celt/entdec.c, entcode.c).                            */
/* ==================================================================== */
#define ROPUS_EC_SYM_BITS   8
#define ROPUS_EC_CODE_BITS  32
#define ROPUS_EC_SYM_MAX    ((1u << ROPUS_EC_SYM_BITS) - 1)
#define ROPUS_EC_CODE_TOP   (((uint32_t)1u) << (ROPUS_EC_CODE_BITS - 1))
#define ROPUS_EC_CODE_BOT   (ROPUS_EC_CODE_TOP >> ROPUS_EC_SYM_BITS)
#define ROPUS_EC_CODE_EXTRA ((ROPUS_EC_CODE_BITS - 2) % ROPUS_EC_SYM_BITS + 1)
#define ROPUS_EC_UINT_BITS  8
#define ROPUS_EC_WINDOW_SIZE 32

typedef struct
{
   const uint8_t *buf;
   uint32_t storage;
   uint32_t end_offs;
   uint32_t end_window;
   int      nend_bits;
   int      nbits_total;
   uint32_t offs;
   uint32_t rng;
   uint32_t val;
   uint32_t ext;
   int      rem;
   int      error;
} ropus_ec;

static INLINE int ropus_ec_ilog(uint32_t v)
{
   int ret = !!v;
   int m;
   m = !!(v & 0xFFFF0000) << 4; v >>= m; ret |= m;
   m = !!(v & 0xFF00) << 3;     v >>= m; ret |= m;
   m = !!(v & 0xF0) << 2;       v >>= m; ret |= m;
   m = !!(v & 0xC) << 1;        v >>= m; ret |= m;
   ret += !!(v & 0x2);
   return ret;
}

static int ropus_ec_read_byte(ropus_ec *e)
{
   return e->offs < e->storage ? e->buf[e->offs++] : 0;
}

static int ropus_ec_read_byte_from_end(ropus_ec *e)
{
   return e->end_offs < e->storage
      ? e->buf[e->storage - ++(e->end_offs)] : 0;
}

static void ropus_ec_dec_normalize(ropus_ec *e)
{
   while (e->rng <= ROPUS_EC_CODE_BOT)
   {
      int sym;
      e->nbits_total += ROPUS_EC_SYM_BITS;
      e->rng <<= ROPUS_EC_SYM_BITS;
      sym = e->rem;
      e->rem = ropus_ec_read_byte(e);
      sym = (sym << ROPUS_EC_SYM_BITS | e->rem)
         >> (ROPUS_EC_SYM_BITS - ROPUS_EC_CODE_EXTRA);
      e->val = ((e->val << ROPUS_EC_SYM_BITS) + (ROPUS_EC_SYM_MAX & ~sym))
         & (ROPUS_EC_CODE_TOP - 1);
   }
}

static void ropus_ec_dec_init(ropus_ec *e, const uint8_t *buf,
      uint32_t storage)
{
   e->buf = buf;
   e->storage = storage;
   e->end_offs = 0;
   e->end_window = 0;
   e->nend_bits = 0;
   e->nbits_total = ROPUS_EC_CODE_BITS + 1
      - ((ROPUS_EC_CODE_BITS - ROPUS_EC_CODE_EXTRA) / ROPUS_EC_SYM_BITS)
      * ROPUS_EC_SYM_BITS;
   e->offs = 0;
   e->rng = 1u << ROPUS_EC_CODE_EXTRA;
   e->rem = ropus_ec_read_byte(e);
   e->val = e->rng - 1
      - (e->rem >> (ROPUS_EC_SYM_BITS - ROPUS_EC_CODE_EXTRA));
   e->error = 0;
   ropus_ec_dec_normalize(e);
}

static unsigned ropus_ec_decode(ropus_ec *e, unsigned ft)
{
   unsigned s;
   e->ext = e->rng / ft;
   s = (unsigned)(e->val / e->ext);
   return ft - (s + 1 < ft ? s + 1 : ft);
}

static unsigned ropus_ec_decode_bin(ropus_ec *e, unsigned bits)
{
   unsigned s;
   e->ext = e->rng >> bits;
   s = (unsigned)(e->val / e->ext);
   return (1u << bits) - (s + 1 < (1u << bits) ? s + 1 : (1u << bits));
}

static void ropus_ec_dec_update(ropus_ec *e, unsigned fl, unsigned fh,
      unsigned ft)
{
   uint32_t s = e->ext * (ft - fh);
   e->val -= s;
   e->rng = fl > 0 ? e->ext * (fh - fl) : e->rng - s;
   ropus_ec_dec_normalize(e);
}

static int ropus_ec_dec_bit_logp(ropus_ec *e, unsigned logp)
{
   uint32_t r, d, s;
   int ret;
   r = e->rng;
   d = e->val;
   s = r >> logp;
   ret = d < s;
   if (!ret)
      e->val = d - s;
   e->rng = ret ? s : r - s;
   ropus_ec_dec_normalize(e);
   return ret;
}

static int ropus_ec_dec_icdf(ropus_ec *e, const uint8_t *icdf, unsigned ftb)
{
   uint32_t r, d, s, t;
   int ret;
   s = e->rng;
   d = e->val;
   r = s >> ftb;
   ret = -1;
   do
   {
      t = s;
      s = r * icdf[++ret];
   } while (d < s);
   e->val = d - s;
   e->rng = t - s;
   ropus_ec_dec_normalize(e);
   return ret;
}

static uint32_t ropus_ec_dec_bits(ropus_ec *e, unsigned bits)
{
   uint32_t window = e->end_window;
   int available = e->nend_bits;
   uint32_t ret;
   if ((unsigned)available < bits)
   {
      do
      {
         window |= (uint32_t)ropus_ec_read_byte_from_end(e) << available;
         available += ROPUS_EC_SYM_BITS;
      } while (available <= ROPUS_EC_WINDOW_SIZE - ROPUS_EC_SYM_BITS);
   }
   ret = window & (((uint32_t)1 << bits) - 1u);
   window >>= bits;
   available -= bits;
   e->end_window = window;
   e->nend_bits = available;
   e->nbits_total += bits;
   return ret;
}

static uint32_t ropus_ec_dec_uint(ropus_ec *e, uint32_t ft)
{
   unsigned ft2, s;
   int ftb;
   ft--;
   ftb = ropus_ec_ilog(ft);
   if (ftb > ROPUS_EC_UINT_BITS)
   {
      uint32_t t;
      ftb -= ROPUS_EC_UINT_BITS;
      ft2 = (unsigned)(ft >> ftb) + 1;
      s = ropus_ec_decode(e, ft2);
      ropus_ec_dec_update(e, s, s + 1, ft2);
      t = (uint32_t)s << ftb | ropus_ec_dec_bits(e, ftb);
      if (t <= ft)
         return t;
      e->error = 1;
      return ft;
   }
   ft++;
   s = ropus_ec_decode(e, (unsigned)ft);
   ropus_ec_dec_update(e, s, s + 1, (unsigned)ft);
   return s;
}

static INLINE int ropus_ec_tell(const ropus_ec *e)
{
   return e->nbits_total - ropus_ec_ilog(e->rng);
}

/* entcode.c: ec_tell_frac with 1/8 bit precision */
static uint32_t ropus_ec_tell_frac(const ropus_ec *e)
{
   static const unsigned correction[8] =
      { 35733, 38967, 42495, 46340, 50535, 55109, 60097, 65535 };
   uint32_t nbits, r;
   int l;
   unsigned b;
   nbits = (uint32_t)e->nbits_total << 3;
   l = ropus_ec_ilog(e->rng);
   r = e->rng >> (l - 16);
   b = (r >> 12) - 8;
   b += r > correction[b];
   l = (l << 3) + (int)b;
   return nbits - (uint32_t)l;
}

/* ==================================================================== */
/* Opus packet parsing (src/opus.c opus_packet_parse_impl).             */
/* ==================================================================== */
#define ROPUS_MAX_FRAMES 48
/* Output channels an Opus stream may carry.  RFC 7845's mapping family
 * 1 allows up to 8; the cap is the table size, not a decode limit. */
#define ROPUS_MAX_CHANNELS 8

typedef struct
{
   int toc;                 /* TOC byte                                 */
   int mode;                /* 0 = SILK, 1 = hybrid, 2 = CELT           */
   int bandwidth;           /* 0=NB 1=MB 2=WB 3=SWB 4=FB                */
   int frame_size;          /* samples at 48 kHz per frame              */
   int stereo;
   int nframes;
   const uint8_t *frames[ROPUS_MAX_FRAMES];
   int16_t sizes[ROPUS_MAX_FRAMES];
} ropus_packet;

static int ropus_parse_size(const uint8_t *data, int len, int16_t *size)
{
   if (len < 1)
   {
      *size = -1;
      return -1;
   }
   if (data[0] < 252)
   {
      *size = data[0];
      return 1;
   }
   if (len < 2)
   {
      *size = -1;
      return -1;
   }
   *size = (int16_t)(4 * data[1] + data[0]);
   return 2;
}

static int ropus_toc_frame_size(int toc)
{
   /* opus_packet_get_samples_per_frame, Fs = 48000 */
   int audiosize;
   if (toc & 0x80)
   {
      audiosize = (toc >> 3) & 0x3;
      audiosize = (48000 << audiosize) / 400;
   }
   else if ((toc & 0x60) == 0x60)
      audiosize = (toc & 0x08) ? 48000 / 50 : 48000 / 100;
   else
   {
      audiosize = (toc >> 3) & 0x3;
      if (audiosize == 3)
         audiosize = 48000 * 60 / 1000;
      else
         audiosize = (48000 << audiosize) / 100;
   }
   return audiosize;
}

/* opus_packet_parse_impl (non-self-delimited).  Returns the number of
 * frames, or -1 on a malformed packet. */
/* Parse one Opus packet.
 *
 * 'self_delim' selects the self-delimiting framing of RFC 6716
 * Appendix B, where the final frame's length is coded rather than
 * implied by what is left of the packet.  Every substream of a
 * multistream packet but the last is framed that way, because the
 * decoder has to know where one ends before it can find the next.
 * 'consumed', when given, reports how far into 'data' this packet
 * reached, which is where the next substream begins. */
static int ropus_packet_parse(const uint8_t *data, int32_t len,
      ropus_packet *p, int self_delim, int32_t *consumed)
{
   int i, bytes, count, cbr;
   uint8_t ch, toc;
   int framesize;
   int32_t last_size;
   const uint8_t *data0 = data;

   if (len <= 0)
      return -1;

   framesize = ropus_toc_frame_size(data[0]);

   cbr = 0;
   toc = *data++;
   len--;
   last_size = len;
   switch (toc & 0x3)
   {
      case 0:
         count = 1;
         break;
      case 1:
         count = 2;
         cbr = 1;
         if (len & 0x1)
            return -1;
         last_size = len / 2;
         p->sizes[0] = (int16_t)last_size;
         break;
      case 2:
         count = 2;
         bytes = ropus_parse_size(data, len, &p->sizes[0]);
         len -= bytes;
         if (p->sizes[0] < 0 || p->sizes[0] > len)
            return -1;
         data += bytes;
         last_size = len - p->sizes[0];
         break;
      default: /* case 3 */
         if (len < 1)
            return -1;
         ch = *data++;
         count = ch & 0x3F;
         if (count <= 0 || framesize * (int32_t)count > 5760)
            return -1;
         len--;
         if (ch & 0x40)
         {
            int pd;
            do
            {
               int tmp;
               if (len <= 0)
                  return -1;
               pd = *data++;
               len--;
               tmp = pd == 255 ? 254 : pd;
               len -= tmp;
            } while (pd == 255);
         }
         if (len < 0)
            return -1;
         cbr = !(ch & 0x80);
         if (!cbr)
         {
            last_size = len;
            for (i = 0; i < count - 1; i++)
            {
               bytes = ropus_parse_size(data, len, &p->sizes[i]);
               len -= bytes;
               if (p->sizes[i] < 0 || p->sizes[i] > len)
                  return -1;
               data += bytes;
               last_size -= bytes + p->sizes[i];
            }
            if (last_size < 0)
               return -1;
         }
         else
         {
            last_size = len / count;
            if (last_size * count != len)
               return -1;
            for (i = 0; i < count - 1; i++)
               p->sizes[i] = (int16_t)last_size;
         }
         break;
   }
   if (self_delim)
   {
      /* The last frame's length is coded here rather than inferred.
       * For a CBR packet it is every frame's length. */
      bytes = ropus_parse_size(data, len, &p->sizes[count - 1]);
      len -= bytes;
      if (p->sizes[count - 1] < 0)
         return -1;
      data += bytes;
      if (cbr)
      {
         if ((int32_t)p->sizes[count - 1] * count > len)
            return -1;
         for (i = 0; i < count - 1; i++)
            p->sizes[i] = p->sizes[count - 1];
      }
      else if ((int32_t)bytes + p->sizes[count - 1] > last_size)
         return -1;
      last_size -= bytes + p->sizes[count - 1];
   }
   else
   {
      /* Not coded, so it is whatever is left - and what is left can
       * exceed what a frame may hold, which only shows up here. */
      if (last_size > 1275)
         return -1;
      p->sizes[count - 1] = (int16_t)last_size;
   }

   for (i = 0; i < count; i++)
   {
      p->frames[i] = data;
      data += p->sizes[i];
   }
   if (consumed)
      *consumed = (int32_t)(data - data0);

   p->toc = toc;
   if (toc & 0x80)
   {
      p->mode = 2;                        /* CELT only                 */
      p->bandwidth = 1 + ((toc >> 5) & 0x3);   /* MB+0..3               */
      if (p->bandwidth == 1)
         p->bandwidth = 0;                /* MB -> NB                  */
   }
   else if ((toc & 0x60) == 0x60)
   {
      p->mode = 1;                        /* hybrid                    */
      p->bandwidth = (toc & 0x10) ? 4 : 3;     /* FB : SWB              */
   }
   else
   {
      p->mode = 0;                        /* SILK only                 */
      p->bandwidth = (toc >> 5) & 0x3;         /* NB/MB/WB              */
   }
   p->stereo = (toc >> 2) & 1;
   p->frame_size = framesize;
   p->nframes = count;
   return count;
}

/* ==================================================================== */
/* CELT constants and mode data for 48 kHz (mode48000_960_120).         */
/* ==================================================================== */
/* Tables extracted verbatim from libopus v1.4 (BSD).            */

static const int16_t ropus_eband5ms[] = {
/*0  200 400 600 800  1k 1.2 1.4 1.6  2k 2.4 2.8 3.2  4k 4.8 5.6 6.8  8k 9.6 12k 15.6 */
  0,  1,  2,  3,  4,  5,  6,  7,  8, 10, 12, 14, 16, 20, 24, 28, 34, 40, 48, 60, 78, 100
};

static const uint8_t ropus_band_allocation[] = {
/*0  200 400 600 800  1k 1.2 1.4 1.6  2k 2.4 2.8 3.2  4k 4.8 5.6 6.8  8k 9.6 12k 15.6 */
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
 90, 80, 75, 69, 63, 56, 49, 40, 34, 29, 20, 18, 10,  0,  0,  0,  0,  0,  0,  0,  0,
110,100, 90, 84, 78, 71, 65, 58, 51, 45, 39, 32, 26, 20, 12,  0,  0,  0,  0,  0,  0,
118,110,103, 93, 86, 80, 75, 70, 65, 59, 53, 47, 40, 31, 23, 15,  4,  0,  0,  0,  0,
126,119,112,104, 95, 89, 83, 78, 72, 66, 60, 54, 47, 39, 32, 25, 17, 12,  1,  0,  0,
134,127,120,114,103, 97, 91, 85, 78, 72, 66, 60, 54, 47, 41, 35, 29, 23, 16, 10,  1,
144,137,130,124,113,107,101, 95, 88, 82, 76, 70, 64, 57, 51, 45, 39, 33, 26, 15,  1,
152,145,138,132,123,117,111,105, 98, 92, 86, 80, 74, 67, 61, 55, 49, 43, 36, 20,  1,
162,155,148,142,133,127,121,115,108,102, 96, 90, 84, 77, 71, 65, 59, 53, 46, 30,  1,
172,165,158,152,143,137,131,125,118,112,106,100, 94, 87, 81, 75, 69, 63, 56, 45, 20,
200,200,200,200,200,200,200,200,198,193,188,183,178,173,168,163,158,153,148,129,104,
};

static const int16_t ropus_logN400[21] = {
0, 0, 0, 0, 0, 0, 0, 0, 8, 8, 8, 8, 16, 16, 16, 21, 21, 24, 29, 34, 36, };

static const float ropus_window120[120] = {
6.7286966e-05f, 0.00060551348f, 0.0016815970f, 0.0032947962f, 0.0054439943f,
0.0081276923f, 0.011344001f, 0.015090633f, 0.019364886f, 0.024163635f,
0.029483315f, 0.035319905f, 0.041668911f, 0.048525347f, 0.055883718f,
0.063737999f, 0.072081616f, 0.080907428f, 0.090207705f, 0.099974111f,
0.11019769f, 0.12086883f, 0.13197729f, 0.14351214f, 0.15546177f,
0.16781389f, 0.18055550f, 0.19367290f, 0.20715171f, 0.22097682f,
0.23513243f, 0.24960208f, 0.26436860f, 0.27941419f, 0.29472040f,
0.31026818f, 0.32603788f, 0.34200931f, 0.35816177f, 0.37447407f,
0.39092462f, 0.40749142f, 0.42415215f, 0.44088423f, 0.45766484f,
0.47447104f, 0.49127978f, 0.50806798f, 0.52481261f, 0.54149077f,
0.55807973f, 0.57455701f, 0.59090049f, 0.60708841f, 0.62309951f,
0.63891306f, 0.65450896f, 0.66986776f, 0.68497077f, 0.69980010f,
0.71433873f, 0.72857055f, 0.74248043f, 0.75605424f, 0.76927895f,
0.78214257f, 0.79463430f, 0.80674445f, 0.81846456f, 0.82978733f,
0.84070669f, 0.85121779f, 0.86131698f, 0.87100183f, 0.88027111f,
0.88912479f, 0.89756398f, 0.90559094f, 0.91320904f, 0.92042270f,
0.92723738f, 0.93365955f, 0.93969656f, 0.94535671f, 0.95064907f,
0.95558353f, 0.96017067f, 0.96442171f, 0.96834849f, 0.97196334f,
0.97527906f, 0.97830883f, 0.98106616f, 0.98356480f, 0.98581869f,
0.98784191f, 0.98964856f, 0.99125274f, 0.99266849f, 0.99390969f,
0.99499004f, 0.99592297f, 0.99672162f, 0.99739874f, 0.99796667f,
0.99843728f, 0.99882195f, 0.99913147f, 0.99937606f, 0.99956527f,
0.99970802f, 0.99981248f, 0.99988613f, 0.99993565f, 0.99996697f,
0.99998518f, 0.99999457f, 0.99999859f, 0.99999982f, 1.0000000f,
};

static const int16_t ropus_cache_index50[105] = {
-1, -1, -1, -1, -1, -1, -1, -1, 0, 0, 0, 0, 41, 41, 41,
82, 82, 123, 164, 200, 222, 0, 0, 0, 0, 0, 0, 0, 0, 41,
41, 41, 41, 123, 123, 123, 164, 164, 240, 266, 283, 295, 41, 41, 41,
41, 41, 41, 41, 41, 123, 123, 123, 123, 240, 240, 240, 266, 266, 305,
318, 328, 336, 123, 123, 123, 123, 123, 123, 123, 123, 240, 240, 240, 240,
305, 305, 305, 318, 318, 343, 351, 358, 364, 240, 240, 240, 240, 240, 240,
240, 240, 305, 305, 305, 305, 343, 343, 343, 351, 351, 370, 376, 382, 387,
};

static const uint8_t ropus_cache_bits50[392] = {
40, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7,
7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 40, 15, 23, 28,
31, 34, 36, 38, 39, 41, 42, 43, 44, 45, 46, 47, 47, 49, 50,
51, 52, 53, 54, 55, 55, 57, 58, 59, 60, 61, 62, 63, 63, 65,
66, 67, 68, 69, 70, 71, 71, 40, 20, 33, 41, 48, 53, 57, 61,
64, 66, 69, 71, 73, 75, 76, 78, 80, 82, 85, 87, 89, 91, 92,
94, 96, 98, 101, 103, 105, 107, 108, 110, 112, 114, 117, 119, 121, 123,
124, 126, 128, 40, 23, 39, 51, 60, 67, 73, 79, 83, 87, 91, 94,
97, 100, 102, 105, 107, 111, 115, 118, 121, 124, 126, 129, 131, 135, 139,
142, 145, 148, 150, 153, 155, 159, 163, 166, 169, 172, 174, 177, 179, 35,
28, 49, 65, 78, 89, 99, 107, 114, 120, 126, 132, 136, 141, 145, 149,
153, 159, 165, 171, 176, 180, 185, 189, 192, 199, 205, 211, 216, 220, 225,
229, 232, 239, 245, 251, 21, 33, 58, 79, 97, 112, 125, 137, 148, 157,
166, 174, 182, 189, 195, 201, 207, 217, 227, 235, 243, 251, 17, 35, 63,
86, 106, 123, 139, 152, 165, 177, 187, 197, 206, 214, 222, 230, 237, 250,
25, 31, 55, 75, 91, 105, 117, 128, 138, 146, 154, 161, 168, 174, 180,
185, 190, 200, 208, 215, 222, 229, 235, 240, 245, 255, 16, 36, 65, 89,
110, 128, 144, 159, 173, 185, 196, 207, 217, 226, 234, 242, 250, 11, 41,
74, 103, 128, 151, 172, 191, 209, 225, 241, 255, 9, 43, 79, 110, 138,
163, 186, 207, 227, 246, 12, 39, 71, 99, 123, 144, 164, 182, 198, 214,
228, 241, 253, 9, 44, 81, 113, 142, 168, 192, 214, 235, 255, 7, 49,
90, 127, 160, 191, 220, 247, 6, 51, 95, 134, 170, 203, 234, 7, 47,
87, 123, 155, 184, 212, 237, 6, 52, 97, 137, 174, 208, 240, 5, 57,
106, 151, 192, 231, 5, 59, 111, 158, 202, 243, 5, 55, 103, 147, 187,
224, 5, 60, 113, 161, 206, 248, 4, 65, 122, 175, 224, 4, 67, 127,
182, 234, };

static const uint8_t ropus_cache_caps50[168] = {
224, 224, 224, 224, 224, 224, 224, 224, 160, 160, 160, 160, 185, 185, 185,
178, 178, 168, 134, 61, 37, 224, 224, 224, 224, 224, 224, 224, 224, 240,
240, 240, 240, 207, 207, 207, 198, 198, 183, 144, 66, 40, 160, 160, 160,
160, 160, 160, 160, 160, 185, 185, 185, 185, 193, 193, 193, 183, 183, 172,
138, 64, 38, 240, 240, 240, 240, 240, 240, 240, 240, 207, 207, 207, 207,
204, 204, 204, 193, 193, 180, 143, 66, 40, 185, 185, 185, 185, 185, 185,
185, 185, 193, 193, 193, 193, 193, 193, 193, 183, 183, 172, 138, 65, 39,
207, 207, 207, 207, 207, 207, 207, 207, 204, 204, 204, 204, 201, 201, 201,
188, 188, 176, 141, 66, 40, 193, 193, 193, 193, 193, 193, 193, 193, 193,
193, 193, 193, 194, 194, 194, 184, 184, 173, 139, 65, 39, 204, 204, 204,
204, 204, 204, 204, 204, 201, 201, 201, 201, 198, 198, 198, 187, 187, 175,
140, 66, 40, };

static const uint8_t ropus_e_prob_model[4][2][42] = {
   /*120 sample frames.*/
   {
      /*Inter*/
      {
          72, 127,  65, 129,  66, 128,  65, 128,  64, 128,  62, 128,  64, 128,
          64, 128,  92,  78,  92,  79,  92,  78,  90,  79, 116,  41, 115,  40,
         114,  40, 132,  26, 132,  26, 145,  17, 161,  12, 176,  10, 177,  11
      },
      /*Intra*/
      {
          24, 179,  48, 138,  54, 135,  54, 132,  53, 134,  56, 133,  55, 132,
          55, 132,  61, 114,  70,  96,  74,  88,  75,  88,  87,  74,  89,  66,
          91,  67, 100,  59, 108,  50, 120,  40, 122,  37,  97,  43,  78,  50
      }
   },
   /*240 sample frames.*/
   {
      /*Inter*/
      {
          83,  78,  84,  81,  88,  75,  86,  74,  87,  71,  90,  73,  93,  74,
          93,  74, 109,  40, 114,  36, 117,  34, 117,  34, 143,  17, 145,  18,
         146,  19, 162,  12, 165,  10, 178,   7, 189,   6, 190,   8, 177,   9
      },
      /*Intra*/
      {
          23, 178,  54, 115,  63, 102,  66,  98,  69,  99,  74,  89,  71,  91,
          73,  91,  78,  89,  86,  80,  92,  66,  93,  64, 102,  59, 103,  60,
         104,  60, 117,  52, 123,  44, 138,  35, 133,  31,  97,  38,  77,  45
      }
   },
   /*480 sample frames.*/
   {
      /*Inter*/
      {
          61,  90,  93,  60, 105,  42, 107,  41, 110,  45, 116,  38, 113,  38,
         112,  38, 124,  26, 132,  27, 136,  19, 140,  20, 155,  14, 159,  16,
         158,  18, 170,  13, 177,  10, 187,   8, 192,   6, 175,   9, 159,  10
      },
      /*Intra*/
      {
          21, 178,  59, 110,  71,  86,  75,  85,  84,  83,  91,  66,  88,  73,
          87,  72,  92,  75,  98,  72, 105,  58, 107,  54, 115,  52, 114,  55,
         112,  56, 129,  51, 132,  40, 150,  33, 140,  29,  98,  35,  77,  42
      }
   },
   /*960 sample frames.*/
   {
      /*Inter*/
      {
          42, 121,  96,  66, 108,  43, 111,  40, 117,  44, 123,  32, 120,  36,
         119,  33, 127,  33, 134,  34, 139,  21, 147,  23, 152,  20, 158,  25,
         154,  26, 166,  21, 173,  16, 184,  13, 184,  10, 150,  13, 139,  15
      },
      /*Intra*/
      {
          22, 178,  63, 114,  74,  82,  84,  83,  92,  82, 103,  62,  96,  72,
          96,  67, 101,  73, 107,  72, 113,  55, 118,  52, 125,  52, 118,  52,
         117,  55, 135,  49, 137,  39, 157,  32, 145,  29,  97,  33,  77,  40
      }
   }
};

static const uint8_t ropus_small_energy_icdf[3]={2,1,0};

static const uint8_t ropus_trim_icdf[11] = {126, 124, 119, 109, 87, 41, 19, 9, 4, 2, 0};

static const uint8_t ropus_spread_icdf[4] = {25, 23, 2, 0};

static const uint8_t ropus_tapset_icdf[3]={2,1,0};

static const int8_t ropus_tf_select_table[4][8] = {
    /*isTransient=0     isTransient=1 */
      {0, -1, 0, -1,    0,-1, 0,-1}, /* 2.5 ms */
      {0, -1, 0, -2,    1, 0, 1,-1}, /* 5 ms */
      {0, -2, 0, -3,    2, 0, 1,-1}, /* 10 ms */
      {0, -2, 0, -3,    3, 0, 1,-1}, /* 20 ms */
};

static const uint8_t ropus_log2_frac_table[24]={
   0,
   8,13,
  16,19,21,23,
  24,26,27,28,29,30,31,32,
  32,33,34,34,35,36,36,37,37
};

/* fixed-point (Q15) window for the s16 pipeline */
static const int16_t ropus_window120_q15[120] = {
2, 20, 55, 108, 178,
266, 372, 494, 635, 792,
966, 1157, 1365, 1590, 1831,
2089, 2362, 2651, 2956, 3276,
3611, 3961, 4325, 4703, 5094,
5499, 5916, 6346, 6788, 7241,
7705, 8179, 8663, 9156, 9657,
10167, 10684, 11207, 11736, 12271,
12810, 13353, 13899, 14447, 14997,
15547, 16098, 16648, 17197, 17744,
18287, 18827, 19363, 19893, 20418,
20936, 21447, 21950, 22445, 22931,
23407, 23874, 24330, 24774, 25208,
25629, 26039, 26435, 26819, 27190,
27548, 27893, 28224, 28541, 28845,
29135, 29411, 29674, 29924, 30160,
30384, 30594, 30792, 30977, 31151,
31313, 31463, 31602, 31731, 31849,
31958, 32057, 32148, 32229, 32303,
32370, 32429, 32481, 32528, 32568,
32604, 32634, 32661, 32683, 32701,
32717, 32729, 32740, 32748, 32754,
32758, 32762, 32764, 32766, 32767,
32767, 32767, 32767, 32767, 32767,
};

/* MDCT/FFT tables from libopus v1.4 static_modes_float.h (float pipeline). */

typedef struct { float r, i; } ropus_cpx;

static const ropus_cpx ropus_fft_twiddles[480] = {
{1.0000000f, -0.0000000f}, {0.99991433f, -0.013089596f},
{0.99965732f, -0.026176948f}, {0.99922904f, -0.039259816f},
{0.99862953f, -0.052335956f}, {0.99785892f, -0.065403129f},
{0.99691733f, -0.078459096f}, {0.99580493f, -0.091501619f},
{0.99452190f, -0.10452846f}, {0.99306846f, -0.11753740f},
{0.99144486f, -0.13052619f}, {0.98965139f, -0.14349262f},
{0.98768834f, -0.15643447f}, {0.98555606f, -0.16934950f},
{0.98325491f, -0.18223553f}, {0.98078528f, -0.19509032f},
{0.97814760f, -0.20791169f}, {0.97534232f, -0.22069744f},
{0.97236992f, -0.23344536f}, {0.96923091f, -0.24615329f},
{0.96592583f, -0.25881905f}, {0.96245524f, -0.27144045f},
{0.95881973f, -0.28401534f}, {0.95501994f, -0.29654157f},
{0.95105652f, -0.30901699f}, {0.94693013f, -0.32143947f},
{0.94264149f, -0.33380686f}, {0.93819134f, -0.34611706f},
{0.93358043f, -0.35836795f}, {0.92880955f, -0.37055744f},
{0.92387953f, -0.38268343f}, {0.91879121f, -0.39474386f},
{0.91354546f, -0.40673664f}, {0.90814317f, -0.41865974f},
{0.90258528f, -0.43051110f}, {0.89687274f, -0.44228869f},
{0.89100652f, -0.45399050f}, {0.88498764f, -0.46561452f},
{0.87881711f, -0.47715876f}, {0.87249601f, -0.48862124f},
{0.86602540f, -0.50000000f}, {0.85940641f, -0.51129309f},
{0.85264016f, -0.52249856f}, {0.84572782f, -0.53361452f},
{0.83867057f, -0.54463904f}, {0.83146961f, -0.55557023f},
{0.82412619f, -0.56640624f}, {0.81664156f, -0.57714519f},
{0.80901699f, -0.58778525f}, {0.80125381f, -0.59832460f},
{0.79335334f, -0.60876143f}, {0.78531693f, -0.61909395f},
{0.77714596f, -0.62932039f}, {0.76884183f, -0.63943900f},
{0.76040597f, -0.64944805f}, {0.75183981f, -0.65934582f},
{0.74314483f, -0.66913061f}, {0.73432251f, -0.67880075f},
{0.72537437f, -0.68835458f}, {0.71630194f, -0.69779046f},
{0.70710678f, -0.70710678f}, {0.69779046f, -0.71630194f},
{0.68835458f, -0.72537437f}, {0.67880075f, -0.73432251f},
{0.66913061f, -0.74314483f}, {0.65934582f, -0.75183981f},
{0.64944805f, -0.76040597f}, {0.63943900f, -0.76884183f},
{0.62932039f, -0.77714596f}, {0.61909395f, -0.78531693f},
{0.60876143f, -0.79335334f}, {0.59832460f, -0.80125381f},
{0.58778525f, -0.80901699f}, {0.57714519f, -0.81664156f},
{0.56640624f, -0.82412619f}, {0.55557023f, -0.83146961f},
{0.54463904f, -0.83867057f}, {0.53361452f, -0.84572782f},
{0.52249856f, -0.85264016f}, {0.51129309f, -0.85940641f},
{0.50000000f, -0.86602540f}, {0.48862124f, -0.87249601f},
{0.47715876f, -0.87881711f}, {0.46561452f, -0.88498764f},
{0.45399050f, -0.89100652f}, {0.44228869f, -0.89687274f},
{0.43051110f, -0.90258528f}, {0.41865974f, -0.90814317f},
{0.40673664f, -0.91354546f}, {0.39474386f, -0.91879121f},
{0.38268343f, -0.92387953f}, {0.37055744f, -0.92880955f},
{0.35836795f, -0.93358043f}, {0.34611706f, -0.93819134f},
{0.33380686f, -0.94264149f}, {0.32143947f, -0.94693013f},
{0.30901699f, -0.95105652f}, {0.29654157f, -0.95501994f},
{0.28401534f, -0.95881973f}, {0.27144045f, -0.96245524f},
{0.25881905f, -0.96592583f}, {0.24615329f, -0.96923091f},
{0.23344536f, -0.97236992f}, {0.22069744f, -0.97534232f},
{0.20791169f, -0.97814760f}, {0.19509032f, -0.98078528f},
{0.18223553f, -0.98325491f}, {0.16934950f, -0.98555606f},
{0.15643447f, -0.98768834f}, {0.14349262f, -0.98965139f},
{0.13052619f, -0.99144486f}, {0.11753740f, -0.99306846f},
{0.10452846f, -0.99452190f}, {0.091501619f, -0.99580493f},
{0.078459096f, -0.99691733f}, {0.065403129f, -0.99785892f},
{0.052335956f, -0.99862953f}, {0.039259816f, -0.99922904f},
{0.026176948f, -0.99965732f}, {0.013089596f, -0.99991433f},
{6.1230318e-17f, -1.0000000f}, {-0.013089596f, -0.99991433f},
{-0.026176948f, -0.99965732f}, {-0.039259816f, -0.99922904f},
{-0.052335956f, -0.99862953f}, {-0.065403129f, -0.99785892f},
{-0.078459096f, -0.99691733f}, {-0.091501619f, -0.99580493f},
{-0.10452846f, -0.99452190f}, {-0.11753740f, -0.99306846f},
{-0.13052619f, -0.99144486f}, {-0.14349262f, -0.98965139f},
{-0.15643447f, -0.98768834f}, {-0.16934950f, -0.98555606f},
{-0.18223553f, -0.98325491f}, {-0.19509032f, -0.98078528f},
{-0.20791169f, -0.97814760f}, {-0.22069744f, -0.97534232f},
{-0.23344536f, -0.97236992f}, {-0.24615329f, -0.96923091f},
{-0.25881905f, -0.96592583f}, {-0.27144045f, -0.96245524f},
{-0.28401534f, -0.95881973f}, {-0.29654157f, -0.95501994f},
{-0.30901699f, -0.95105652f}, {-0.32143947f, -0.94693013f},
{-0.33380686f, -0.94264149f}, {-0.34611706f, -0.93819134f},
{-0.35836795f, -0.93358043f}, {-0.37055744f, -0.92880955f},
{-0.38268343f, -0.92387953f}, {-0.39474386f, -0.91879121f},
{-0.40673664f, -0.91354546f}, {-0.41865974f, -0.90814317f},
{-0.43051110f, -0.90258528f}, {-0.44228869f, -0.89687274f},
{-0.45399050f, -0.89100652f}, {-0.46561452f, -0.88498764f},
{-0.47715876f, -0.87881711f}, {-0.48862124f, -0.87249601f},
{-0.50000000f, -0.86602540f}, {-0.51129309f, -0.85940641f},
{-0.52249856f, -0.85264016f}, {-0.53361452f, -0.84572782f},
{-0.54463904f, -0.83867057f}, {-0.55557023f, -0.83146961f},
{-0.56640624f, -0.82412619f}, {-0.57714519f, -0.81664156f},
{-0.58778525f, -0.80901699f}, {-0.59832460f, -0.80125381f},
{-0.60876143f, -0.79335334f}, {-0.61909395f, -0.78531693f},
{-0.62932039f, -0.77714596f}, {-0.63943900f, -0.76884183f},
{-0.64944805f, -0.76040597f}, {-0.65934582f, -0.75183981f},
{-0.66913061f, -0.74314483f}, {-0.67880075f, -0.73432251f},
{-0.68835458f, -0.72537437f}, {-0.69779046f, -0.71630194f},
{-0.70710678f, -0.70710678f}, {-0.71630194f, -0.69779046f},
{-0.72537437f, -0.68835458f}, {-0.73432251f, -0.67880075f},
{-0.74314483f, -0.66913061f}, {-0.75183981f, -0.65934582f},
{-0.76040597f, -0.64944805f}, {-0.76884183f, -0.63943900f},
{-0.77714596f, -0.62932039f}, {-0.78531693f, -0.61909395f},
{-0.79335334f, -0.60876143f}, {-0.80125381f, -0.59832460f},
{-0.80901699f, -0.58778525f}, {-0.81664156f, -0.57714519f},
{-0.82412619f, -0.56640624f}, {-0.83146961f, -0.55557023f},
{-0.83867057f, -0.54463904f}, {-0.84572782f, -0.53361452f},
{-0.85264016f, -0.52249856f}, {-0.85940641f, -0.51129309f},
{-0.86602540f, -0.50000000f}, {-0.87249601f, -0.48862124f},
{-0.87881711f, -0.47715876f}, {-0.88498764f, -0.46561452f},
{-0.89100652f, -0.45399050f}, {-0.89687274f, -0.44228869f},
{-0.90258528f, -0.43051110f}, {-0.90814317f, -0.41865974f},
{-0.91354546f, -0.40673664f}, {-0.91879121f, -0.39474386f},
{-0.92387953f, -0.38268343f}, {-0.92880955f, -0.37055744f},
{-0.93358043f, -0.35836795f}, {-0.93819134f, -0.34611706f},
{-0.94264149f, -0.33380686f}, {-0.94693013f, -0.32143947f},
{-0.95105652f, -0.30901699f}, {-0.95501994f, -0.29654157f},
{-0.95881973f, -0.28401534f}, {-0.96245524f, -0.27144045f},
{-0.96592583f, -0.25881905f}, {-0.96923091f, -0.24615329f},
{-0.97236992f, -0.23344536f}, {-0.97534232f, -0.22069744f},
{-0.97814760f, -0.20791169f}, {-0.98078528f, -0.19509032f},
{-0.98325491f, -0.18223553f}, {-0.98555606f, -0.16934950f},
{-0.98768834f, -0.15643447f}, {-0.98965139f, -0.14349262f},
{-0.99144486f, -0.13052619f}, {-0.99306846f, -0.11753740f},
{-0.99452190f, -0.10452846f}, {-0.99580493f, -0.091501619f},
{-0.99691733f, -0.078459096f}, {-0.99785892f, -0.065403129f},
{-0.99862953f, -0.052335956f}, {-0.99922904f, -0.039259816f},
{-0.99965732f, -0.026176948f}, {-0.99991433f, -0.013089596f},
{-1.0000000f, -1.2246064e-16f}, {-0.99991433f, 0.013089596f},
{-0.99965732f, 0.026176948f}, {-0.99922904f, 0.039259816f},
{-0.99862953f, 0.052335956f}, {-0.99785892f, 0.065403129f},
{-0.99691733f, 0.078459096f}, {-0.99580493f, 0.091501619f},
{-0.99452190f, 0.10452846f}, {-0.99306846f, 0.11753740f},
{-0.99144486f, 0.13052619f}, {-0.98965139f, 0.14349262f},
{-0.98768834f, 0.15643447f}, {-0.98555606f, 0.16934950f},
{-0.98325491f, 0.18223553f}, {-0.98078528f, 0.19509032f},
{-0.97814760f, 0.20791169f}, {-0.97534232f, 0.22069744f},
{-0.97236992f, 0.23344536f}, {-0.96923091f, 0.24615329f},
{-0.96592583f, 0.25881905f}, {-0.96245524f, 0.27144045f},
{-0.95881973f, 0.28401534f}, {-0.95501994f, 0.29654157f},
{-0.95105652f, 0.30901699f}, {-0.94693013f, 0.32143947f},
{-0.94264149f, 0.33380686f}, {-0.93819134f, 0.34611706f},
{-0.93358043f, 0.35836795f}, {-0.92880955f, 0.37055744f},
{-0.92387953f, 0.38268343f}, {-0.91879121f, 0.39474386f},
{-0.91354546f, 0.40673664f}, {-0.90814317f, 0.41865974f},
{-0.90258528f, 0.43051110f}, {-0.89687274f, 0.44228869f},
{-0.89100652f, 0.45399050f}, {-0.88498764f, 0.46561452f},
{-0.87881711f, 0.47715876f}, {-0.87249601f, 0.48862124f},
{-0.86602540f, 0.50000000f}, {-0.85940641f, 0.51129309f},
{-0.85264016f, 0.52249856f}, {-0.84572782f, 0.53361452f},
{-0.83867057f, 0.54463904f}, {-0.83146961f, 0.55557023f},
{-0.82412619f, 0.56640624f}, {-0.81664156f, 0.57714519f},
{-0.80901699f, 0.58778525f}, {-0.80125381f, 0.59832460f},
{-0.79335334f, 0.60876143f}, {-0.78531693f, 0.61909395f},
{-0.77714596f, 0.62932039f}, {-0.76884183f, 0.63943900f},
{-0.76040597f, 0.64944805f}, {-0.75183981f, 0.65934582f},
{-0.74314483f, 0.66913061f}, {-0.73432251f, 0.67880075f},
{-0.72537437f, 0.68835458f}, {-0.71630194f, 0.69779046f},
{-0.70710678f, 0.70710678f}, {-0.69779046f, 0.71630194f},
{-0.68835458f, 0.72537437f}, {-0.67880075f, 0.73432251f},
{-0.66913061f, 0.74314483f}, {-0.65934582f, 0.75183981f},
{-0.64944805f, 0.76040597f}, {-0.63943900f, 0.76884183f},
{-0.62932039f, 0.77714596f}, {-0.61909395f, 0.78531693f},
{-0.60876143f, 0.79335334f}, {-0.59832460f, 0.80125381f},
{-0.58778525f, 0.80901699f}, {-0.57714519f, 0.81664156f},
{-0.56640624f, 0.82412619f}, {-0.55557023f, 0.83146961f},
{-0.54463904f, 0.83867057f}, {-0.53361452f, 0.84572782f},
{-0.52249856f, 0.85264016f}, {-0.51129309f, 0.85940641f},
{-0.50000000f, 0.86602540f}, {-0.48862124f, 0.87249601f},
{-0.47715876f, 0.87881711f}, {-0.46561452f, 0.88498764f},
{-0.45399050f, 0.89100652f}, {-0.44228869f, 0.89687274f},
{-0.43051110f, 0.90258528f}, {-0.41865974f, 0.90814317f},
{-0.40673664f, 0.91354546f}, {-0.39474386f, 0.91879121f},
{-0.38268343f, 0.92387953f}, {-0.37055744f, 0.92880955f},
{-0.35836795f, 0.93358043f}, {-0.34611706f, 0.93819134f},
{-0.33380686f, 0.94264149f}, {-0.32143947f, 0.94693013f},
{-0.30901699f, 0.95105652f}, {-0.29654157f, 0.95501994f},
{-0.28401534f, 0.95881973f}, {-0.27144045f, 0.96245524f},
{-0.25881905f, 0.96592583f}, {-0.24615329f, 0.96923091f},
{-0.23344536f, 0.97236992f}, {-0.22069744f, 0.97534232f},
{-0.20791169f, 0.97814760f}, {-0.19509032f, 0.98078528f},
{-0.18223553f, 0.98325491f}, {-0.16934950f, 0.98555606f},
{-0.15643447f, 0.98768834f}, {-0.14349262f, 0.98965139f},
{-0.13052619f, 0.99144486f}, {-0.11753740f, 0.99306846f},
{-0.10452846f, 0.99452190f}, {-0.091501619f, 0.99580493f},
{-0.078459096f, 0.99691733f}, {-0.065403129f, 0.99785892f},
{-0.052335956f, 0.99862953f}, {-0.039259816f, 0.99922904f},
{-0.026176948f, 0.99965732f}, {-0.013089596f, 0.99991433f},
{-1.8369095e-16f, 1.0000000f}, {0.013089596f, 0.99991433f},
{0.026176948f, 0.99965732f}, {0.039259816f, 0.99922904f},
{0.052335956f, 0.99862953f}, {0.065403129f, 0.99785892f},
{0.078459096f, 0.99691733f}, {0.091501619f, 0.99580493f},
{0.10452846f, 0.99452190f}, {0.11753740f, 0.99306846f},
{0.13052619f, 0.99144486f}, {0.14349262f, 0.98965139f},
{0.15643447f, 0.98768834f}, {0.16934950f, 0.98555606f},
{0.18223553f, 0.98325491f}, {0.19509032f, 0.98078528f},
{0.20791169f, 0.97814760f}, {0.22069744f, 0.97534232f},
{0.23344536f, 0.97236992f}, {0.24615329f, 0.96923091f},
{0.25881905f, 0.96592583f}, {0.27144045f, 0.96245524f},
{0.28401534f, 0.95881973f}, {0.29654157f, 0.95501994f},
{0.30901699f, 0.95105652f}, {0.32143947f, 0.94693013f},
{0.33380686f, 0.94264149f}, {0.34611706f, 0.93819134f},
{0.35836795f, 0.93358043f}, {0.37055744f, 0.92880955f},
{0.38268343f, 0.92387953f}, {0.39474386f, 0.91879121f},
{0.40673664f, 0.91354546f}, {0.41865974f, 0.90814317f},
{0.43051110f, 0.90258528f}, {0.44228869f, 0.89687274f},
{0.45399050f, 0.89100652f}, {0.46561452f, 0.88498764f},
{0.47715876f, 0.87881711f}, {0.48862124f, 0.87249601f},
{0.50000000f, 0.86602540f}, {0.51129309f, 0.85940641f},
{0.52249856f, 0.85264016f}, {0.53361452f, 0.84572782f},
{0.54463904f, 0.83867057f}, {0.55557023f, 0.83146961f},
{0.56640624f, 0.82412619f}, {0.57714519f, 0.81664156f},
{0.58778525f, 0.80901699f}, {0.59832460f, 0.80125381f},
{0.60876143f, 0.79335334f}, {0.61909395f, 0.78531693f},
{0.62932039f, 0.77714596f}, {0.63943900f, 0.76884183f},
{0.64944805f, 0.76040597f}, {0.65934582f, 0.75183981f},
{0.66913061f, 0.74314483f}, {0.67880075f, 0.73432251f},
{0.68835458f, 0.72537437f}, {0.69779046f, 0.71630194f},
{0.70710678f, 0.70710678f}, {0.71630194f, 0.69779046f},
{0.72537437f, 0.68835458f}, {0.73432251f, 0.67880075f},
{0.74314483f, 0.66913061f}, {0.75183981f, 0.65934582f},
{0.76040597f, 0.64944805f}, {0.76884183f, 0.63943900f},
{0.77714596f, 0.62932039f}, {0.78531693f, 0.61909395f},
{0.79335334f, 0.60876143f}, {0.80125381f, 0.59832460f},
{0.80901699f, 0.58778525f}, {0.81664156f, 0.57714519f},
{0.82412619f, 0.56640624f}, {0.83146961f, 0.55557023f},
{0.83867057f, 0.54463904f}, {0.84572782f, 0.53361452f},
{0.85264016f, 0.52249856f}, {0.85940641f, 0.51129309f},
{0.86602540f, 0.50000000f}, {0.87249601f, 0.48862124f},
{0.87881711f, 0.47715876f}, {0.88498764f, 0.46561452f},
{0.89100652f, 0.45399050f}, {0.89687274f, 0.44228869f},
{0.90258528f, 0.43051110f}, {0.90814317f, 0.41865974f},
{0.91354546f, 0.40673664f}, {0.91879121f, 0.39474386f},
{0.92387953f, 0.38268343f}, {0.92880955f, 0.37055744f},
{0.93358043f, 0.35836795f}, {0.93819134f, 0.34611706f},
{0.94264149f, 0.33380686f}, {0.94693013f, 0.32143947f},
{0.95105652f, 0.30901699f}, {0.95501994f, 0.29654157f},
{0.95881973f, 0.28401534f}, {0.96245524f, 0.27144045f},
{0.96592583f, 0.25881905f}, {0.96923091f, 0.24615329f},
{0.97236992f, 0.23344536f}, {0.97534232f, 0.22069744f},
{0.97814760f, 0.20791169f}, {0.98078528f, 0.19509032f},
{0.98325491f, 0.18223553f}, {0.98555606f, 0.16934950f},
{0.98768834f, 0.15643447f}, {0.98965139f, 0.14349262f},
{0.99144486f, 0.13052619f}, {0.99306846f, 0.11753740f},
{0.99452190f, 0.10452846f}, {0.99580493f, 0.091501619f},
{0.99691733f, 0.078459096f}, {0.99785892f, 0.065403129f},
{0.99862953f, 0.052335956f}, {0.99922904f, 0.039259816f},
{0.99965732f, 0.026176948f}, {0.99991433f, 0.013089596f},
};

static const int16_t ropus_fft_bitrev480[480] = {
0, 96, 192, 288, 384, 32, 128, 224, 320, 416, 64, 160, 256, 352, 448,
8, 104, 200, 296, 392, 40, 136, 232, 328, 424, 72, 168, 264, 360, 456,
16, 112, 208, 304, 400, 48, 144, 240, 336, 432, 80, 176, 272, 368, 464,
24, 120, 216, 312, 408, 56, 152, 248, 344, 440, 88, 184, 280, 376, 472,
4, 100, 196, 292, 388, 36, 132, 228, 324, 420, 68, 164, 260, 356, 452,
12, 108, 204, 300, 396, 44, 140, 236, 332, 428, 76, 172, 268, 364, 460,
20, 116, 212, 308, 404, 52, 148, 244, 340, 436, 84, 180, 276, 372, 468,
28, 124, 220, 316, 412, 60, 156, 252, 348, 444, 92, 188, 284, 380, 476,
1, 97, 193, 289, 385, 33, 129, 225, 321, 417, 65, 161, 257, 353, 449,
9, 105, 201, 297, 393, 41, 137, 233, 329, 425, 73, 169, 265, 361, 457,
17, 113, 209, 305, 401, 49, 145, 241, 337, 433, 81, 177, 273, 369, 465,
25, 121, 217, 313, 409, 57, 153, 249, 345, 441, 89, 185, 281, 377, 473,
5, 101, 197, 293, 389, 37, 133, 229, 325, 421, 69, 165, 261, 357, 453,
13, 109, 205, 301, 397, 45, 141, 237, 333, 429, 77, 173, 269, 365, 461,
21, 117, 213, 309, 405, 53, 149, 245, 341, 437, 85, 181, 277, 373, 469,
29, 125, 221, 317, 413, 61, 157, 253, 349, 445, 93, 189, 285, 381, 477,
2, 98, 194, 290, 386, 34, 130, 226, 322, 418, 66, 162, 258, 354, 450,
10, 106, 202, 298, 394, 42, 138, 234, 330, 426, 74, 170, 266, 362, 458,
18, 114, 210, 306, 402, 50, 146, 242, 338, 434, 82, 178, 274, 370, 466,
26, 122, 218, 314, 410, 58, 154, 250, 346, 442, 90, 186, 282, 378, 474,
6, 102, 198, 294, 390, 38, 134, 230, 326, 422, 70, 166, 262, 358, 454,
14, 110, 206, 302, 398, 46, 142, 238, 334, 430, 78, 174, 270, 366, 462,
22, 118, 214, 310, 406, 54, 150, 246, 342, 438, 86, 182, 278, 374, 470,
30, 126, 222, 318, 414, 62, 158, 254, 350, 446, 94, 190, 286, 382, 478,
3, 99, 195, 291, 387, 35, 131, 227, 323, 419, 67, 163, 259, 355, 451,
11, 107, 203, 299, 395, 43, 139, 235, 331, 427, 75, 171, 267, 363, 459,
19, 115, 211, 307, 403, 51, 147, 243, 339, 435, 83, 179, 275, 371, 467,
27, 123, 219, 315, 411, 59, 155, 251, 347, 443, 91, 187, 283, 379, 475,
7, 103, 199, 295, 391, 39, 135, 231, 327, 423, 71, 167, 263, 359, 455,
15, 111, 207, 303, 399, 47, 143, 239, 335, 431, 79, 175, 271, 367, 463,
23, 119, 215, 311, 407, 55, 151, 247, 343, 439, 87, 183, 279, 375, 471,
31, 127, 223, 319, 415, 63, 159, 255, 351, 447, 95, 191, 287, 383, 479,
};

static const int16_t ropus_fft_bitrev240[240] = {
0, 48, 96, 144, 192, 16, 64, 112, 160, 208, 32, 80, 128, 176, 224,
4, 52, 100, 148, 196, 20, 68, 116, 164, 212, 36, 84, 132, 180, 228,
8, 56, 104, 152, 200, 24, 72, 120, 168, 216, 40, 88, 136, 184, 232,
12, 60, 108, 156, 204, 28, 76, 124, 172, 220, 44, 92, 140, 188, 236,
1, 49, 97, 145, 193, 17, 65, 113, 161, 209, 33, 81, 129, 177, 225,
5, 53, 101, 149, 197, 21, 69, 117, 165, 213, 37, 85, 133, 181, 229,
9, 57, 105, 153, 201, 25, 73, 121, 169, 217, 41, 89, 137, 185, 233,
13, 61, 109, 157, 205, 29, 77, 125, 173, 221, 45, 93, 141, 189, 237,
2, 50, 98, 146, 194, 18, 66, 114, 162, 210, 34, 82, 130, 178, 226,
6, 54, 102, 150, 198, 22, 70, 118, 166, 214, 38, 86, 134, 182, 230,
10, 58, 106, 154, 202, 26, 74, 122, 170, 218, 42, 90, 138, 186, 234,
14, 62, 110, 158, 206, 30, 78, 126, 174, 222, 46, 94, 142, 190, 238,
3, 51, 99, 147, 195, 19, 67, 115, 163, 211, 35, 83, 131, 179, 227,
7, 55, 103, 151, 199, 23, 71, 119, 167, 215, 39, 87, 135, 183, 231,
11, 59, 107, 155, 203, 27, 75, 123, 171, 219, 43, 91, 139, 187, 235,
15, 63, 111, 159, 207, 31, 79, 127, 175, 223, 47, 95, 143, 191, 239,
};

static const int16_t ropus_fft_bitrev120[120] = {
0, 24, 48, 72, 96, 8, 32, 56, 80, 104, 16, 40, 64, 88, 112,
4, 28, 52, 76, 100, 12, 36, 60, 84, 108, 20, 44, 68, 92, 116,
1, 25, 49, 73, 97, 9, 33, 57, 81, 105, 17, 41, 65, 89, 113,
5, 29, 53, 77, 101, 13, 37, 61, 85, 109, 21, 45, 69, 93, 117,
2, 26, 50, 74, 98, 10, 34, 58, 82, 106, 18, 42, 66, 90, 114,
6, 30, 54, 78, 102, 14, 38, 62, 86, 110, 22, 46, 70, 94, 118,
3, 27, 51, 75, 99, 11, 35, 59, 83, 107, 19, 43, 67, 91, 115,
7, 31, 55, 79, 103, 15, 39, 63, 87, 111, 23, 47, 71, 95, 119,
};

static const int16_t ropus_fft_bitrev60[60] = {
0, 12, 24, 36, 48, 4, 16, 28, 40, 52, 8, 20, 32, 44, 56,
1, 13, 25, 37, 49, 5, 17, 29, 41, 53, 9, 21, 33, 45, 57,
2, 14, 26, 38, 50, 6, 18, 30, 42, 54, 10, 22, 34, 46, 58,
3, 15, 27, 39, 51, 7, 19, 31, 43, 55, 11, 23, 35, 47, 59,
};

static const float ropus_mdct_twiddles[1800] = {
0.99999994f, 0.99999321f, 0.99997580f, 0.99994773f, 0.99990886f,
0.99985933f, 0.99979913f, 0.99972820f, 0.99964654f, 0.99955416f,
0.99945110f, 0.99933738f, 0.99921292f, 0.99907774f, 0.99893188f,
0.99877530f, 0.99860805f, 0.99843007f, 0.99824142f, 0.99804211f,
0.99783206f, 0.99761140f, 0.99737996f, 0.99713790f, 0.99688518f,
0.99662173f, 0.99634761f, 0.99606287f, 0.99576741f, 0.99546129f,
0.99514455f, 0.99481714f, 0.99447906f, 0.99413031f, 0.99377096f,
0.99340093f, 0.99302030f, 0.99262899f, 0.99222708f, 0.99181455f,
0.99139136f, 0.99095762f, 0.99051321f, 0.99005818f, 0.98959261f,
0.98911643f, 0.98862964f, 0.98813224f, 0.98762429f, 0.98710573f,
0.98657662f, 0.98603696f, 0.98548669f, 0.98492593f, 0.98435456f,
0.98377270f, 0.98318028f, 0.98257732f, 0.98196387f, 0.98133987f,
0.98070538f, 0.98006040f, 0.97940493f, 0.97873890f, 0.97806245f,
0.97737551f, 0.97667813f, 0.97597027f, 0.97525197f, 0.97452319f,
0.97378403f, 0.97303438f, 0.97227436f, 0.97150391f, 0.97072303f,
0.96993178f, 0.96913016f, 0.96831810f, 0.96749574f, 0.96666300f,
0.96581990f, 0.96496642f, 0.96410263f, 0.96322852f, 0.96234411f,
0.96144938f, 0.96054435f, 0.95962906f, 0.95870346f, 0.95776761f,
0.95682150f, 0.95586514f, 0.95489854f, 0.95392174f, 0.95293468f,
0.95193744f, 0.95093000f, 0.94991243f, 0.94888461f, 0.94784665f,
0.94679856f, 0.94574034f, 0.94467193f, 0.94359344f, 0.94250488f,
0.94140619f, 0.94029742f, 0.93917859f, 0.93804967f, 0.93691075f,
0.93576175f, 0.93460274f, 0.93343377f, 0.93225473f, 0.93106574f,
0.92986679f, 0.92865789f, 0.92743903f, 0.92621022f, 0.92497152f,
0.92372292f, 0.92246443f, 0.92119598f, 0.91991776f, 0.91862965f,
0.91733170f, 0.91602397f, 0.91470635f, 0.91337901f, 0.91204184f,
0.91069490f, 0.90933824f, 0.90797186f, 0.90659571f, 0.90520984f,
0.90381432f, 0.90240908f, 0.90099424f, 0.89956969f, 0.89813554f,
0.89669174f, 0.89523834f, 0.89377540f, 0.89230281f, 0.89082074f,
0.88932908f, 0.88782793f, 0.88631725f, 0.88479710f, 0.88326746f,
0.88172835f, 0.88017982f, 0.87862182f, 0.87705445f, 0.87547767f,
0.87389153f, 0.87229604f, 0.87069118f, 0.86907703f, 0.86745358f,
0.86582077f, 0.86417878f, 0.86252749f, 0.86086690f, 0.85919720f,
0.85751826f, 0.85583007f, 0.85413277f, 0.85242635f, 0.85071075f,
0.84898609f, 0.84725231f, 0.84550947f, 0.84375757f, 0.84199661f,
0.84022665f, 0.83844769f, 0.83665979f, 0.83486289f, 0.83305705f,
0.83124226f, 0.82941860f, 0.82758605f, 0.82574469f, 0.82389444f,
0.82203537f, 0.82016748f, 0.81829083f, 0.81640542f, 0.81451124f,
0.81260836f, 0.81069672f, 0.80877650f, 0.80684757f, 0.80490994f,
0.80296379f, 0.80100900f, 0.79904562f, 0.79707366f, 0.79509324f,
0.79310423f, 0.79110676f, 0.78910083f, 0.78708643f, 0.78506362f,
0.78303236f, 0.78099275f, 0.77894479f, 0.77688843f, 0.77482378f,
0.77275085f, 0.77066964f, 0.76858020f, 0.76648247f, 0.76437658f,
0.76226246f, 0.76014024f, 0.75800985f, 0.75587130f, 0.75372469f,
0.75157005f, 0.74940729f, 0.74723655f, 0.74505776f, 0.74287105f,
0.74067634f, 0.73847371f, 0.73626316f, 0.73404479f, 0.73181850f,
0.72958434f, 0.72734243f, 0.72509271f, 0.72283524f, 0.72057003f,
0.71829706f, 0.71601641f, 0.71372813f, 0.71143216f, 0.70912862f,
0.70681745f, 0.70449871f, 0.70217246f, 0.69983864f, 0.69749737f,
0.69514859f, 0.69279242f, 0.69042879f, 0.68805778f, 0.68567938f,
0.68329364f, 0.68090063f, 0.67850029f, 0.67609268f, 0.67367786f,
0.67125577f, 0.66882652f, 0.66639012f, 0.66394657f, 0.66149592f,
0.65903819f, 0.65657341f, 0.65410155f, 0.65162271f, 0.64913690f,
0.64664418f, 0.64414448f, 0.64163786f, 0.63912445f, 0.63660413f,
0.63407701f, 0.63154310f, 0.62900239f, 0.62645501f, 0.62390089f,
0.62134010f, 0.61877263f, 0.61619854f, 0.61361790f, 0.61103064f,
0.60843682f, 0.60583651f, 0.60322970f, 0.60061646f, 0.59799677f,
0.59537065f, 0.59273821f, 0.59009939f, 0.58745426f, 0.58480281f,
0.58214509f, 0.57948118f, 0.57681108f, 0.57413477f, 0.57145232f,
0.56876373f, 0.56606907f, 0.56336832f, 0.56066155f, 0.55794877f,
0.55523002f, 0.55250537f, 0.54977477f, 0.54703826f, 0.54429591f,
0.54154772f, 0.53879374f, 0.53603399f, 0.53326851f, 0.53049731f,
0.52772039f, 0.52493787f, 0.52214974f, 0.51935595f, 0.51655668f,
0.51375180f, 0.51094145f, 0.50812566f, 0.50530440f, 0.50247771f,
0.49964568f, 0.49680826f, 0.49396557f, 0.49111754f, 0.48826426f,
0.48540577f, 0.48254207f, 0.47967321f, 0.47679919f, 0.47392011f,
0.47103590f, 0.46814668f, 0.46525243f, 0.46235323f, 0.45944905f,
0.45653993f, 0.45362595f, 0.45070711f, 0.44778344f, 0.44485497f,
0.44192174f, 0.43898380f, 0.43604112f, 0.43309379f, 0.43014181f,
0.42718524f, 0.42422408f, 0.42125839f, 0.41828820f, 0.41531351f,
0.41233435f, 0.40935081f, 0.40636289f, 0.40337059f, 0.40037400f,
0.39737311f, 0.39436796f, 0.39135858f, 0.38834500f, 0.38532731f,
0.38230544f, 0.37927949f, 0.37624949f, 0.37321547f, 0.37017745f,
0.36713544f, 0.36408952f, 0.36103970f, 0.35798600f, 0.35492846f,
0.35186714f, 0.34880206f, 0.34573323f, 0.34266070f, 0.33958447f,
0.33650464f, 0.33342120f, 0.33033419f, 0.32724363f, 0.32414958f,
0.32105204f, 0.31795108f, 0.31484672f, 0.31173897f, 0.30862790f,
0.30551350f, 0.30239585f, 0.29927495f, 0.29615086f, 0.29302359f,
0.28989318f, 0.28675964f, 0.28362307f, 0.28048345f, 0.27734083f,
0.27419522f, 0.27104670f, 0.26789525f, 0.26474094f, 0.26158381f,
0.25842386f, 0.25526115f, 0.25209570f, 0.24892756f, 0.24575676f,
0.24258332f, 0.23940729f, 0.23622867f, 0.23304754f, 0.22986393f,
0.22667783f, 0.22348931f, 0.22029841f, 0.21710514f, 0.21390954f,
0.21071166f, 0.20751151f, 0.20430915f, 0.20110460f, 0.19789790f,
0.19468907f, 0.19147816f, 0.18826519f, 0.18505022f, 0.18183327f,
0.17861435f, 0.17539354f, 0.17217083f, 0.16894630f, 0.16571994f,
0.16249183f, 0.15926196f, 0.15603039f, 0.15279715f, 0.14956227f,
0.14632578f, 0.14308774f, 0.13984816f, 0.13660708f, 0.13336454f,
0.13012058f, 0.12687522f, 0.12362850f, 0.12038045f, 0.11713112f,
0.11388054f, 0.11062872f, 0.10737573f, 0.10412160f, 0.10086634f,
0.097609997f, 0.094352618f, 0.091094226f, 0.087834857f, 0.084574550f,
0.081313334f, 0.078051247f, 0.074788325f, 0.071524605f, 0.068260118f,
0.064994894f, 0.061728980f, 0.058462404f, 0.055195201f, 0.051927410f,
0.048659060f, 0.045390189f, 0.042120833f, 0.038851023f, 0.035580799f,
0.032310195f, 0.029039243f, 0.025767982f, 0.022496443f, 0.019224664f,
0.015952680f, 0.012680525f, 0.0094082337f, 0.0061358409f, 0.0028633832f,
-0.00040910527f, -0.0036815894f, -0.0069540343f, -0.010226404f, -0.013498665f,
-0.016770782f, -0.020042717f, -0.023314439f, -0.026585912f, -0.029857099f,
-0.033127967f, -0.036398482f, -0.039668605f, -0.042938303f, -0.046207540f,
-0.049476285f, -0.052744497f, -0.056012146f, -0.059279196f, -0.062545612f,
-0.065811358f, -0.069076397f, -0.072340697f, -0.075604223f, -0.078866936f,
-0.082128808f, -0.085389800f, -0.088649876f, -0.091909006f, -0.095167145f,
-0.098424271f, -0.10168034f, -0.10493532f, -0.10818918f, -0.11144188f,
-0.11469338f, -0.11794366f, -0.12119267f, -0.12444039f, -0.12768677f,
-0.13093179f, -0.13417540f, -0.13741758f, -0.14065829f, -0.14389749f,
-0.14713514f, -0.15037122f, -0.15360570f, -0.15683852f, -0.16006967f,
-0.16329910f, -0.16652679f, -0.16975269f, -0.17297678f, -0.17619900f,
-0.17941935f, -0.18263777f, -0.18585424f, -0.18906870f, -0.19228116f,
-0.19549155f, -0.19869985f, -0.20190603f, -0.20511003f, -0.20831184f,
-0.21151142f, -0.21470875f, -0.21790376f, -0.22109644f, -0.22428675f,
-0.22747467f, -0.23066014f, -0.23384315f, -0.23702365f, -0.24020162f,
-0.24337701f, -0.24654980f, -0.24971995f, -0.25288740f, -0.25605217f,
-0.25921419f, -0.26237345f, -0.26552987f, -0.26868346f, -0.27183419f,
-0.27498198f, -0.27812684f, -0.28126872f, -0.28440759f, -0.28754342f,
-0.29067615f, -0.29380578f, -0.29693225f, -0.30005556f, -0.30317566f,
-0.30629250f, -0.30940607f, -0.31251630f, -0.31562322f, -0.31872672f,
-0.32182685f, -0.32492352f, -0.32801670f, -0.33110636f, -0.33419248f,
-0.33727503f, -0.34035397f, -0.34342924f, -0.34650084f, -0.34956875f,
-0.35263291f, -0.35569328f, -0.35874987f, -0.36180258f, -0.36485144f,
-0.36789638f, -0.37093741f, -0.37397444f, -0.37700745f, -0.38003644f,
-0.38306138f, -0.38608220f, -0.38909888f, -0.39211139f, -0.39511973f,
-0.39812380f, -0.40112361f, -0.40411916f, -0.40711036f, -0.41009718f,
-0.41307965f, -0.41605768f, -0.41903123f, -0.42200032f, -0.42496487f,
-0.42792490f, -0.43088034f, -0.43383113f, -0.43677729f, -0.43971881f,
-0.44265559f, -0.44558764f, -0.44851488f, -0.45143735f, -0.45435500f,
-0.45726776f, -0.46017563f, -0.46307856f, -0.46597654f, -0.46886954f,
-0.47175750f, -0.47464043f, -0.47751826f, -0.48039100f, -0.48325855f,
-0.48612097f, -0.48897815f, -0.49183011f, -0.49467680f, -0.49751821f,
-0.50035429f, -0.50318497f, -0.50601029f, -0.50883019f, -0.51164466f,
-0.51445359f, -0.51725709f, -0.52005500f, -0.52284735f, -0.52563411f,
-0.52841520f, -0.53119069f, -0.53396046f, -0.53672451f, -0.53948283f,
-0.54223537f, -0.54498214f, -0.54772300f, -0.55045801f, -0.55318713f,
-0.55591035f, -0.55862761f, -0.56133890f, -0.56404412f, -0.56674337f,
-0.56943649f, -0.57212353f, -0.57480448f, -0.57747924f, -0.58014780f,
-0.58281022f, -0.58546633f, -0.58811617f, -0.59075975f, -0.59339696f,
-0.59602785f, -0.59865236f, -0.60127044f, -0.60388207f, -0.60648727f,
-0.60908598f, -0.61167812f, -0.61426371f, -0.61684275f, -0.61941516f,
-0.62198097f, -0.62454009f, -0.62709254f, -0.62963831f, -0.63217729f,
-0.63470948f, -0.63723493f, -0.63975352f, -0.64226526f, -0.64477009f,
-0.64726806f, -0.64975911f, -0.65224314f, -0.65472025f, -0.65719032f,
-0.65965337f, -0.66210932f, -0.66455823f, -0.66700000f, -0.66943461f,
-0.67186207f, -0.67428231f, -0.67669535f, -0.67910111f, -0.68149966f,
-0.68389088f, -0.68627477f, -0.68865126f, -0.69102043f, -0.69338220f,
-0.69573659f, -0.69808346f, -0.70042288f, -0.70275480f, -0.70507920f,
-0.70739603f, -0.70970529f, -0.71200693f, -0.71430099f, -0.71658736f,
-0.71886611f, -0.72113711f, -0.72340041f, -0.72565591f, -0.72790372f,
-0.73014367f, -0.73237586f, -0.73460019f, -0.73681659f, -0.73902518f,
-0.74122584f, -0.74341851f, -0.74560326f, -0.74778003f, -0.74994880f,
-0.75210953f, -0.75426215f, -0.75640678f, -0.75854325f, -0.76067162f,
-0.76279181f, -0.76490390f, -0.76700771f, -0.76910341f, -0.77119076f,
-0.77326995f, -0.77534080f, -0.77740335f, -0.77945763f, -0.78150350f,
-0.78354102f, -0.78557014f, -0.78759086f, -0.78960317f, -0.79160696f,
-0.79360235f, -0.79558921f, -0.79756755f, -0.79953730f, -0.80149853f,
-0.80345118f, -0.80539525f, -0.80733067f, -0.80925739f, -0.81117553f,
-0.81308490f, -0.81498563f, -0.81687760f, -0.81876087f, -0.82063532f,
-0.82250100f, -0.82435787f, -0.82620591f, -0.82804507f, -0.82987541f,
-0.83169687f, -0.83350939f, -0.83531296f, -0.83710766f, -0.83889335f,
-0.84067005f, -0.84243774f, -0.84419644f, -0.84594607f, -0.84768665f,
-0.84941816f, -0.85114056f, -0.85285389f, -0.85455805f, -0.85625303f,
-0.85793889f, -0.85961550f, -0.86128294f, -0.86294121f, -0.86459017f,
-0.86622989f, -0.86786032f, -0.86948150f, -0.87109333f, -0.87269586f,
-0.87428904f, -0.87587279f, -0.87744725f, -0.87901229f, -0.88056785f,
-0.88211405f, -0.88365078f, -0.88517809f, -0.88669586f, -0.88820416f,
-0.88970292f, -0.89119220f, -0.89267188f, -0.89414203f, -0.89560264f,
-0.89705360f, -0.89849502f, -0.89992678f, -0.90134889f, -0.90276134f,
-0.90416414f, -0.90555727f, -0.90694070f, -0.90831441f, -0.90967834f,
-0.91103262f, -0.91237706f, -0.91371179f, -0.91503674f, -0.91635185f,
-0.91765714f, -0.91895264f, -0.92023826f, -0.92151409f, -0.92277998f,
-0.92403603f, -0.92528218f, -0.92651838f, -0.92774469f, -0.92896110f,
-0.93016750f, -0.93136400f, -0.93255049f, -0.93372697f, -0.93489349f,
-0.93604994f, -0.93719643f, -0.93833286f, -0.93945926f, -0.94057560f,
-0.94168180f, -0.94277799f, -0.94386405f, -0.94494003f, -0.94600588f,
-0.94706154f, -0.94810712f, -0.94914252f, -0.95016778f, -0.95118284f,
-0.95218778f, -0.95318246f, -0.95416695f, -0.95514119f, -0.95610523f,
-0.95705903f, -0.95800257f, -0.95893586f, -0.95985889f, -0.96077162f,
-0.96167403f, -0.96256620f, -0.96344805f, -0.96431959f, -0.96518075f,
-0.96603161f, -0.96687216f, -0.96770233f, -0.96852213f, -0.96933156f,
-0.97013056f, -0.97091925f, -0.97169751f, -0.97246534f, -0.97322279f,
-0.97396982f, -0.97470641f, -0.97543252f, -0.97614825f, -0.97685349f,
-0.97754824f, -0.97823256f, -0.97890645f, -0.97956979f, -0.98022264f,
-0.98086500f, -0.98149687f, -0.98211825f, -0.98272908f, -0.98332942f,
-0.98391914f, -0.98449844f, -0.98506713f, -0.98562527f, -0.98617285f,
-0.98670989f, -0.98723638f, -0.98775226f, -0.98825759f, -0.98875231f,
-0.98923647f, -0.98971003f, -0.99017298f, -0.99062532f, -0.99106705f,
-0.99149817f, -0.99191868f, -0.99232858f, -0.99272782f, -0.99311644f,
-0.99349445f, -0.99386179f, -0.99421853f, -0.99456459f, -0.99489999f,
-0.99522477f, -0.99553883f, -0.99584228f, -0.99613506f, -0.99641716f,
-0.99668860f, -0.99694937f, -0.99719942f, -0.99743885f, -0.99766755f,
-0.99788558f, -0.99809295f, -0.99828959f, -0.99847561f, -0.99865085f,
-0.99881548f, -0.99896932f, -0.99911255f, -0.99924499f, -0.99936682f,
-0.99947786f, -0.99957830f, -0.99966794f, -0.99974692f, -0.99981517f,
-0.99987274f, -0.99991959f, -0.99995571f, -0.99998116f, -0.99999589f,
0.99999964f, 0.99997288f, 0.99990326f, 0.99979085f, 0.99963558f,
0.99943751f, 0.99919659f, 0.99891287f, 0.99858636f, 0.99821711f,
0.99780506f, 0.99735034f, 0.99685282f, 0.99631262f, 0.99572974f,
0.99510419f, 0.99443603f, 0.99372530f, 0.99297196f, 0.99217612f,
0.99133772f, 0.99045694f, 0.98953366f, 0.98856801f, 0.98756003f,
0.98650974f, 0.98541719f, 0.98428243f, 0.98310548f, 0.98188645f,
0.98062533f, 0.97932225f, 0.97797716f, 0.97659022f, 0.97516143f,
0.97369087f, 0.97217858f, 0.97062469f, 0.96902919f, 0.96739221f,
0.96571374f, 0.96399397f, 0.96223283f, 0.96043050f, 0.95858705f,
0.95670253f, 0.95477700f, 0.95281059f, 0.95080340f, 0.94875544f,
0.94666684f, 0.94453770f, 0.94236809f, 0.94015813f, 0.93790787f,
0.93561745f, 0.93328691f, 0.93091643f, 0.92850608f, 0.92605597f,
0.92356616f, 0.92103678f, 0.91846794f, 0.91585976f, 0.91321236f,
0.91052586f, 0.90780038f, 0.90503591f, 0.90223277f, 0.89939094f,
0.89651060f, 0.89359182f, 0.89063478f, 0.88763964f, 0.88460642f,
0.88153529f, 0.87842643f, 0.87527996f, 0.87209594f, 0.86887461f,
0.86561602f, 0.86232042f, 0.85898781f, 0.85561842f, 0.85221243f,
0.84876984f, 0.84529096f, 0.84177583f, 0.83822471f, 0.83463764f,
0.83101481f, 0.82735640f, 0.82366252f, 0.81993335f, 0.81616908f,
0.81236988f, 0.80853581f, 0.80466717f, 0.80076402f, 0.79682660f,
0.79285502f, 0.78884947f, 0.78481019f, 0.78073722f, 0.77663082f,
0.77249116f, 0.76831841f, 0.76411277f, 0.75987434f, 0.75560343f,
0.75130010f, 0.74696463f, 0.74259710f, 0.73819780f, 0.73376691f,
0.72930455f, 0.72481096f, 0.72028631f, 0.71573079f, 0.71114463f,
0.70652801f, 0.70188117f, 0.69720417f, 0.69249737f, 0.68776089f,
0.68299496f, 0.67819971f, 0.67337549f, 0.66852236f, 0.66364062f,
0.65873051f, 0.65379208f, 0.64882571f, 0.64383155f, 0.63880974f,
0.63376063f, 0.62868434f, 0.62358117f, 0.61845124f, 0.61329484f,
0.60811216f, 0.60290343f, 0.59766883f, 0.59240872f, 0.58712316f,
0.58181250f, 0.57647687f, 0.57111657f, 0.56573176f, 0.56032276f,
0.55488980f, 0.54943299f, 0.54395270f, 0.53844911f, 0.53292239f,
0.52737290f, 0.52180082f, 0.51620632f, 0.51058978f, 0.50495136f,
0.49929130f, 0.49360985f, 0.48790723f, 0.48218375f, 0.47643960f,
0.47067502f, 0.46489030f, 0.45908567f, 0.45326138f, 0.44741765f,
0.44155475f, 0.43567297f, 0.42977250f, 0.42385364f, 0.41791660f,
0.41196167f, 0.40598908f, 0.39999911f, 0.39399201f, 0.38796803f,
0.38192743f, 0.37587047f, 0.36979741f, 0.36370850f, 0.35760403f,
0.35148421f, 0.34534934f, 0.33919969f, 0.33303553f, 0.32685706f,
0.32066461f, 0.31445843f, 0.30823877f, 0.30200592f, 0.29576012f,
0.28950164f, 0.28323078f, 0.27694780f, 0.27065292f, 0.26434645f,
0.25802869f, 0.25169984f, 0.24536023f, 0.23901010f, 0.23264973f,
0.22627939f, 0.21989937f, 0.21350993f, 0.20711134f, 0.20070387f,
0.19428782f, 0.18786344f, 0.18143101f, 0.17499080f, 0.16854310f,
0.16208819f, 0.15562633f, 0.14915779f, 0.14268288f, 0.13620184f,
0.12971498f, 0.12322257f, 0.11672486f, 0.11022217f, 0.10371475f,
0.097202882f, 0.090686858f, 0.084166944f, 0.077643424f, 0.071116582f,
0.064586692f, 0.058054037f, 0.051518895f, 0.044981543f, 0.038442269f,
0.031901345f, 0.025359053f, 0.018815678f, 0.012271495f, 0.0057267868f,
-0.00081816671f, -0.0073630852f, -0.013907688f, -0.020451695f, -0.026994826f,
-0.033536803f, -0.040077340f, -0.046616159f, -0.053152986f, -0.059687532f,
-0.066219524f, -0.072748676f, -0.079274714f, -0.085797355f, -0.092316322f,
-0.098831341f, -0.10534211f, -0.11184838f, -0.11834986f, -0.12484626f,
-0.13133731f, -0.13782275f, -0.14430228f, -0.15077563f, -0.15724251f,
-0.16370267f, -0.17015581f, -0.17660165f, -0.18303993f, -0.18947038f,
-0.19589271f, -0.20230664f, -0.20871192f, -0.21510825f, -0.22149536f,
-0.22787298f, -0.23424086f, -0.24059868f, -0.24694622f, -0.25328314f,
-0.25960925f, -0.26592422f, -0.27222782f, -0.27851975f, -0.28479972f,
-0.29106751f, -0.29732284f, -0.30356544f, -0.30979502f, -0.31601134f,
-0.32221413f, -0.32840309f, -0.33457801f, -0.34073856f, -0.34688455f,
-0.35301566f, -0.35913166f, -0.36523229f, -0.37131724f, -0.37738630f,
-0.38343921f, -0.38947567f, -0.39549544f, -0.40149832f, -0.40748394f,
-0.41345215f, -0.41940263f, -0.42533514f, -0.43124944f, -0.43714526f,
-0.44302234f, -0.44888046f, -0.45471936f, -0.46053877f, -0.46633846f,
-0.47211814f, -0.47787762f, -0.48361665f, -0.48933494f, -0.49503228f,
-0.50070840f, -0.50636309f, -0.51199609f, -0.51760709f, -0.52319598f,
-0.52876246f, -0.53430629f, -0.53982723f, -0.54532504f, -0.55079949f,
-0.55625033f, -0.56167740f, -0.56708032f, -0.57245898f, -0.57781315f,
-0.58314258f, -0.58844697f, -0.59372622f, -0.59897995f, -0.60420811f,
-0.60941035f, -0.61458647f, -0.61973625f, -0.62485951f, -0.62995601f,
-0.63502556f, -0.64006782f, -0.64508271f, -0.65007001f, -0.65502942f,
-0.65996075f, -0.66486382f, -0.66973841f, -0.67458433f, -0.67940134f,
-0.68418926f, -0.68894786f, -0.69367695f, -0.69837630f, -0.70304573f,
-0.70768511f, -0.71229410f, -0.71687263f, -0.72142041f, -0.72593731f,
-0.73042315f, -0.73487765f, -0.73930067f, -0.74369204f, -0.74805158f,
-0.75237900f, -0.75667429f, -0.76093709f, -0.76516730f, -0.76936477f,
-0.77352923f, -0.77766061f, -0.78175867f, -0.78582323f, -0.78985411f,
-0.79385114f, -0.79781419f, -0.80174309f, -0.80563760f, -0.80949765f,
-0.81332302f, -0.81711352f, -0.82086903f, -0.82458937f, -0.82827437f,
-0.83192390f, -0.83553779f, -0.83911592f, -0.84265804f, -0.84616417f,
-0.84963393f, -0.85306740f, -0.85646427f, -0.85982448f, -0.86314780f,
-0.86643422f, -0.86968350f, -0.87289548f, -0.87607014f, -0.87920725f,
-0.88230664f, -0.88536829f, -0.88839203f, -0.89137769f, -0.89432514f,
-0.89723432f, -0.90010506f, -0.90293723f, -0.90573072f, -0.90848541f,
-0.91120118f, -0.91387796f, -0.91651553f, -0.91911387f, -0.92167282f,
-0.92419231f, -0.92667222f, -0.92911243f, -0.93151283f, -0.93387336f,
-0.93619382f, -0.93847424f, -0.94071442f, -0.94291431f, -0.94507378f,
-0.94719279f, -0.94927126f, -0.95130903f, -0.95330608f, -0.95526224f,
-0.95717752f, -0.95905179f, -0.96088499f, -0.96267700f, -0.96442777f,
-0.96613729f, -0.96780539f, -0.96943200f, -0.97101706f, -0.97256058f,
-0.97406244f, -0.97552258f, -0.97694093f, -0.97831738f, -0.97965199f,
-0.98094457f, -0.98219514f, -0.98340368f, -0.98457009f, -0.98569429f,
-0.98677629f, -0.98781598f, -0.98881340f, -0.98976845f, -0.99068111f,
-0.99155134f, -0.99237907f, -0.99316430f, -0.99390697f, -0.99460709f,
-0.99526459f, -0.99587947f, -0.99645168f, -0.99698120f, -0.99746799f,
-0.99791211f, -0.99831343f, -0.99867201f, -0.99898779f, -0.99926084f,
-0.99949104f, -0.99967843f, -0.99982297f, -0.99992472f, -0.99998361f,
0.99999869f, 0.99989158f, 0.99961317f, 0.99916345f, 0.99854255f,
0.99775058f, 0.99678761f, 0.99565387f, 0.99434954f, 0.99287480f,
0.99122995f, 0.98941529f, 0.98743105f, 0.98527765f, 0.98295540f,
0.98046476f, 0.97780609f, 0.97497988f, 0.97198665f, 0.96882683f,
0.96550101f, 0.96200979f, 0.95835376f, 0.95453346f, 0.95054960f,
0.94640291f, 0.94209403f, 0.93762374f, 0.93299282f, 0.92820197f,
0.92325211f, 0.91814411f, 0.91287869f, 0.90745693f, 0.90187967f,
0.89614785f, 0.89026248f, 0.88422459f, 0.87803519f, 0.87169534f,
0.86520612f, 0.85856867f, 0.85178405f, 0.84485358f, 0.83777827f,
0.83055943f, 0.82319832f, 0.81569612f, 0.80805415f, 0.80027372f,
0.79235619f, 0.78430289f, 0.77611518f, 0.76779449f, 0.75934225f,
0.75075996f, 0.74204898f, 0.73321080f, 0.72424710f, 0.71515924f,
0.70594883f, 0.69661748f, 0.68716675f, 0.67759830f, 0.66791373f,
0.65811473f, 0.64820296f, 0.63818014f, 0.62804794f, 0.61780810f,
0.60746247f, 0.59701276f, 0.58646071f, 0.57580817f, 0.56505698f,
0.55420899f, 0.54326600f, 0.53222996f, 0.52110273f, 0.50988621f,
0.49858227f, 0.48719296f, 0.47572014f, 0.46416581f, 0.45253196f,
0.44082057f, 0.42903364f, 0.41717321f, 0.40524128f, 0.39323992f,
0.38117120f, 0.36903715f, 0.35683987f, 0.34458145f, 0.33226398f,
0.31988961f, 0.30746040f, 0.29497850f, 0.28244606f, 0.26986524f,
0.25723818f, 0.24456702f, 0.23185398f, 0.21910121f, 0.20631088f,
0.19348522f, 0.18062639f, 0.16773662f, 0.15481812f, 0.14187308f,
0.12890373f, 0.11591230f, 0.10290100f, 0.089872077f, 0.076827750f,
0.063770257f, 0.050701842f, 0.037624735f, 0.024541186f, 0.011453429f,
-0.0016362892f, -0.014725727f, -0.027812643f, -0.040894791f, -0.053969935f,
-0.067035832f, -0.080090240f, -0.093130924f, -0.10615565f, -0.11916219f,
-0.13214831f, -0.14511178f, -0.15805040f, -0.17096193f, -0.18384418f,
-0.19669491f, -0.20951195f, -0.22229309f, -0.23503613f, -0.24773891f,
-0.26039925f, -0.27301496f, -0.28558388f, -0.29810387f, -0.31057280f,
-0.32298848f, -0.33534884f, -0.34765175f, -0.35989508f, -0.37207675f,
-0.38419467f, -0.39624676f, -0.40823093f, -0.42014518f, -0.43198743f,
-0.44375566f, -0.45544785f, -0.46706200f, -0.47859612f, -0.49004826f,
-0.50141639f, -0.51269865f, -0.52389306f, -0.53499764f, -0.54601061f,
-0.55693001f, -0.56775403f, -0.57848072f, -0.58910829f, -0.59963489f,
-0.61005878f, -0.62037814f, -0.63059121f, -0.64069623f, -0.65069145f,
-0.66057515f, -0.67034572f, -0.68000144f, -0.68954057f, -0.69896162f,
-0.70826286f, -0.71744281f, -0.72649974f, -0.73543227f, -0.74423873f,
-0.75291771f, -0.76146764f, -0.76988715f, -0.77817470f, -0.78632891f,
-0.79434842f, -0.80223179f, -0.80997771f, -0.81758487f, -0.82505190f,
-0.83237761f, -0.83956063f, -0.84659988f, -0.85349399f, -0.86024189f,
-0.86684239f, -0.87329435f, -0.87959671f, -0.88574833f, -0.89174819f,
-0.89759529f, -0.90328854f, -0.90882701f, -0.91420978f, -0.91943592f,
-0.92450452f, -0.92941469f, -0.93416560f, -0.93875647f, -0.94318646f,
-0.94745487f, -0.95156091f, -0.95550388f, -0.95928317f, -0.96289814f,
-0.96634805f, -0.96963239f, -0.97275060f, -0.97570217f, -0.97848648f,
-0.98110318f, -0.98355180f, -0.98583186f, -0.98794299f, -0.98988485f,
-0.99165714f, -0.99325943f, -0.99469161f, -0.99595332f, -0.99704438f,
-0.99796462f, -0.99871385f, -0.99929196f, -0.99969882f, -0.99993443f,
0.99999464f, 0.99956632f, 0.99845290f, 0.99665523f, 0.99417448f,
0.99101239f, 0.98717111f, 0.98265326f, 0.97746199f, 0.97160077f,
0.96507365f, 0.95788515f, 0.95004016f, 0.94154406f, 0.93240267f,
0.92262226f, 0.91220951f, 0.90117162f, 0.88951606f, 0.87725091f,
0.86438453f, 0.85092574f, 0.83688372f, 0.82226819f, 0.80708915f,
0.79135692f, 0.77508235f, 0.75827658f, 0.74095112f, 0.72311783f,
0.70478898f, 0.68597710f, 0.66669506f, 0.64695615f, 0.62677377f,
0.60616189f, 0.58513457f, 0.56370622f, 0.54189157f, 0.51970547f,
0.49716324f, 0.47428027f, 0.45107225f, 0.42755505f, 0.40374488f,
0.37965798f, 0.35531086f, 0.33072025f, 0.30590299f, 0.28087607f,
0.25565663f, 0.23026201f, 0.20470956f, 0.17901683f, 0.15320139f,
0.12728097f, 0.10127331f, 0.075196236f, 0.049067631f, 0.022905400f,
-0.0032725304f, -0.029448219f, -0.055603724f, -0.081721120f, -0.10778251f,
-0.13377003f, -0.15966587f, -0.18545228f, -0.21111161f, -0.23662624f,
-0.26197869f, -0.28715160f, -0.31212771f, -0.33688989f, -0.36142120f,
-0.38570482f, -0.40972409f, -0.43346253f, -0.45690393f, -0.48003218f,
-0.50283146f, -0.52528608f, -0.54738069f, -0.56910020f, -0.59042966f,
-0.61135447f, -0.63186026f, -0.65193301f, -0.67155898f, -0.69072473f,
-0.70941705f, -0.72762316f, -0.74533063f, -0.76252723f, -0.77920127f,
-0.79534131f, -0.81093621f, -0.82597536f, -0.84044844f, -0.85434550f,
-0.86765707f, -0.88037395f, -0.89248747f, -0.90398932f, -0.91487163f,
-0.92512697f, -0.93474823f, -0.94372886f, -0.95206273f, -0.95974404f,
-0.96676767f, -0.97312868f, -0.97882277f, -0.98384601f, -0.98819500f,
-0.99186671f, -0.99485862f, -0.99716878f, -0.99879545f, -0.99973762f,
};

static const int16_t ropus_fft_factors480[16] = {5, 96, 3, 32, 4, 8, 2, 4, 4, 1, 0, 0, 0, 0, 0, 0, };

static const int16_t ropus_fft_factors240[16] = {5, 48, 3, 16, 4, 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, };

static const int16_t ropus_fft_factors120[16] = {5, 24, 3, 8, 2, 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, };

static const int16_t ropus_fft_factors60[16] = {5, 12, 3, 4, 4, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, };

/* PVQ V(N,K) combinatoric table, libopus cwrs.c (non-custom). */
static const uint32_t ropus_pvq_u_data[1272]={
  /*N=0, K=0...176:*/
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
#if defined(CUSTOM_MODES)
  /*...208:*/
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0,
#endif
  /*N=1, K=1...176:*/
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
#if defined(CUSTOM_MODES)
  /*...208:*/
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1,
#endif
  /*N=2, K=2...176:*/
  3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41,
  43, 45, 47, 49, 51, 53, 55, 57, 59, 61, 63, 65, 67, 69, 71, 73, 75, 77, 79,
  81, 83, 85, 87, 89, 91, 93, 95, 97, 99, 101, 103, 105, 107, 109, 111, 113,
  115, 117, 119, 121, 123, 125, 127, 129, 131, 133, 135, 137, 139, 141, 143,
  145, 147, 149, 151, 153, 155, 157, 159, 161, 163, 165, 167, 169, 171, 173,
  175, 177, 179, 181, 183, 185, 187, 189, 191, 193, 195, 197, 199, 201, 203,
  205, 207, 209, 211, 213, 215, 217, 219, 221, 223, 225, 227, 229, 231, 233,
  235, 237, 239, 241, 243, 245, 247, 249, 251, 253, 255, 257, 259, 261, 263,
  265, 267, 269, 271, 273, 275, 277, 279, 281, 283, 285, 287, 289, 291, 293,
  295, 297, 299, 301, 303, 305, 307, 309, 311, 313, 315, 317, 319, 321, 323,
  325, 327, 329, 331, 333, 335, 337, 339, 341, 343, 345, 347, 349, 351,
#if defined(CUSTOM_MODES)
  /*...208:*/
  353, 355, 357, 359, 361, 363, 365, 367, 369, 371, 373, 375, 377, 379, 381,
  383, 385, 387, 389, 391, 393, 395, 397, 399, 401, 403, 405, 407, 409, 411,
  413, 415,
#endif
  /*N=3, K=3...176:*/
  13, 25, 41, 61, 85, 113, 145, 181, 221, 265, 313, 365, 421, 481, 545, 613,
  685, 761, 841, 925, 1013, 1105, 1201, 1301, 1405, 1513, 1625, 1741, 1861,
  1985, 2113, 2245, 2381, 2521, 2665, 2813, 2965, 3121, 3281, 3445, 3613, 3785,
  3961, 4141, 4325, 4513, 4705, 4901, 5101, 5305, 5513, 5725, 5941, 6161, 6385,
  6613, 6845, 7081, 7321, 7565, 7813, 8065, 8321, 8581, 8845, 9113, 9385, 9661,
  9941, 10225, 10513, 10805, 11101, 11401, 11705, 12013, 12325, 12641, 12961,
  13285, 13613, 13945, 14281, 14621, 14965, 15313, 15665, 16021, 16381, 16745,
  17113, 17485, 17861, 18241, 18625, 19013, 19405, 19801, 20201, 20605, 21013,
  21425, 21841, 22261, 22685, 23113, 23545, 23981, 24421, 24865, 25313, 25765,
  26221, 26681, 27145, 27613, 28085, 28561, 29041, 29525, 30013, 30505, 31001,
  31501, 32005, 32513, 33025, 33541, 34061, 34585, 35113, 35645, 36181, 36721,
  37265, 37813, 38365, 38921, 39481, 40045, 40613, 41185, 41761, 42341, 42925,
  43513, 44105, 44701, 45301, 45905, 46513, 47125, 47741, 48361, 48985, 49613,
  50245, 50881, 51521, 52165, 52813, 53465, 54121, 54781, 55445, 56113, 56785,
  57461, 58141, 58825, 59513, 60205, 60901, 61601,
#if defined(CUSTOM_MODES)
  /*...208:*/
  62305, 63013, 63725, 64441, 65161, 65885, 66613, 67345, 68081, 68821, 69565,
  70313, 71065, 71821, 72581, 73345, 74113, 74885, 75661, 76441, 77225, 78013,
  78805, 79601, 80401, 81205, 82013, 82825, 83641, 84461, 85285, 86113,
#endif
  /*N=4, K=4...176:*/
  63, 129, 231, 377, 575, 833, 1159, 1561, 2047, 2625, 3303, 4089, 4991, 6017,
  7175, 8473, 9919, 11521, 13287, 15225, 17343, 19649, 22151, 24857, 27775,
  30913, 34279, 37881, 41727, 45825, 50183, 54809, 59711, 64897, 70375, 76153,
  82239, 88641, 95367, 102425, 109823, 117569, 125671, 134137, 142975, 152193,
  161799, 171801, 182207, 193025, 204263, 215929, 228031, 240577, 253575,
  267033, 280959, 295361, 310247, 325625, 341503, 357889, 374791, 392217,
  410175, 428673, 447719, 467321, 487487, 508225, 529543, 551449, 573951,
  597057, 620775, 645113, 670079, 695681, 721927, 748825, 776383, 804609,
  833511, 863097, 893375, 924353, 956039, 988441, 1021567, 1055425, 1090023,
  1125369, 1161471, 1198337, 1235975, 1274393, 1313599, 1353601, 1394407,
  1436025, 1478463, 1521729, 1565831, 1610777, 1656575, 1703233, 1750759,
  1799161, 1848447, 1898625, 1949703, 2001689, 2054591, 2108417, 2163175,
  2218873, 2275519, 2333121, 2391687, 2451225, 2511743, 2573249, 2635751,
  2699257, 2763775, 2829313, 2895879, 2963481, 3032127, 3101825, 3172583,
  3244409, 3317311, 3391297, 3466375, 3542553, 3619839, 3698241, 3777767,
  3858425, 3940223, 4023169, 4107271, 4192537, 4278975, 4366593, 4455399,
  4545401, 4636607, 4729025, 4822663, 4917529, 5013631, 5110977, 5209575,
  5309433, 5410559, 5512961, 5616647, 5721625, 5827903, 5935489, 6044391,
  6154617, 6266175, 6379073, 6493319, 6608921, 6725887, 6844225, 6963943,
  7085049, 7207551,
#if defined(CUSTOM_MODES)
  /*...208:*/
  7331457, 7456775, 7583513, 7711679, 7841281, 7972327, 8104825, 8238783,
  8374209, 8511111, 8649497, 8789375, 8930753, 9073639, 9218041, 9363967,
  9511425, 9660423, 9810969, 9963071, 10116737, 10271975, 10428793, 10587199,
  10747201, 10908807, 11072025, 11236863, 11403329, 11571431, 11741177,
  11912575,
#endif
  /*N=5, K=5...176:*/
  321, 681, 1289, 2241, 3649, 5641, 8361, 11969, 16641, 22569, 29961, 39041,
  50049, 63241, 78889, 97281, 118721, 143529, 172041, 204609, 241601, 283401,
  330409, 383041, 441729, 506921, 579081, 658689, 746241, 842249, 947241,
  1061761, 1186369, 1321641, 1468169, 1626561, 1797441, 1981449, 2179241,
  2391489, 2618881, 2862121, 3121929, 3399041, 3694209, 4008201, 4341801,
  4695809, 5071041, 5468329, 5888521, 6332481, 6801089, 7295241, 7815849,
  8363841, 8940161, 9545769, 10181641, 10848769, 11548161, 12280841, 13047849,
  13850241, 14689089, 15565481, 16480521, 17435329, 18431041, 19468809,
  20549801, 21675201, 22846209, 24064041, 25329929, 26645121, 28010881,
  29428489, 30899241, 32424449, 34005441, 35643561, 37340169, 39096641,
  40914369, 42794761, 44739241, 46749249, 48826241, 50971689, 53187081,
  55473921, 57833729, 60268041, 62778409, 65366401, 68033601, 70781609,
  73612041, 76526529, 79526721, 82614281, 85790889, 89058241, 92418049,
  95872041, 99421961, 103069569, 106816641, 110664969, 114616361, 118672641,
  122835649, 127107241, 131489289, 135983681, 140592321, 145317129, 150160041,
  155123009, 160208001, 165417001, 170752009, 176215041, 181808129, 187533321,
  193392681, 199388289, 205522241, 211796649, 218213641, 224775361, 231483969,
  238341641, 245350569, 252512961, 259831041, 267307049, 274943241, 282741889,
  290705281, 298835721, 307135529, 315607041, 324252609, 333074601, 342075401,
  351257409, 360623041, 370174729, 379914921, 389846081, 399970689, 410291241,
  420810249, 431530241, 442453761, 453583369, 464921641, 476471169, 488234561,
  500214441, 512413449, 524834241, 537479489, 550351881, 563454121, 576788929,
  590359041, 604167209, 618216201, 632508801,
#if defined(CUSTOM_MODES)
  /*...208:*/
  647047809, 661836041, 676876329, 692171521, 707724481, 723538089, 739615241,
  755958849, 772571841, 789457161, 806617769, 824056641, 841776769, 859781161,
  878072841, 896654849, 915530241, 934702089, 954173481, 973947521, 994027329,
  1014416041, 1035116809, 1056132801, 1077467201, 1099123209, 1121104041,
  1143412929, 1166053121, 1189027881, 1212340489, 1235994241,
#endif
  /*N=6, K=6...96:*/
  1683, 3653, 7183, 13073, 22363, 36365, 56695, 85305, 124515, 177045, 246047,
  335137, 448427, 590557, 766727, 982729, 1244979, 1560549, 1937199, 2383409,
  2908411, 3522221, 4235671, 5060441, 6009091, 7095093, 8332863, 9737793,
  11326283, 13115773, 15124775, 17372905, 19880915, 22670725, 25765455,
  29189457, 32968347, 37129037, 41699767, 46710137, 52191139, 58175189,
  64696159, 71789409, 79491819, 87841821, 96879431, 106646281, 117185651,
  128542501, 140763503, 153897073, 167993403, 183104493, 199284183, 216588185,
  235074115, 254801525, 275831935, 298228865, 322057867, 347386557, 374284647,
  402823977, 433078547, 465124549, 499040399, 534906769, 572806619, 612825229,
  655050231, 699571641, 746481891, 795875861, 847850911, 902506913, 959946283,
  1020274013, 1083597703, 1150027593, 1219676595, 1292660325, 1369097135,
  1449108145, 1532817275, 1620351277, 1711839767, 1807415257, 1907213187,
  2011371957, 2120032959,
#if defined(CUSTOM_MODES)
  /*...109:*/
  2233340609U, 2351442379U, 2474488829U, 2602633639U, 2736033641U, 2874848851U,
  3019242501U, 3169381071U, 3325434321U, 3487575323U, 3655980493U, 3830829623U,
  4012305913U,
#endif
  /*N=7, K=7...54*/
  8989, 19825, 40081, 75517, 134245, 227305, 369305, 579125, 880685, 1303777,
  1884961, 2668525, 3707509, 5064793, 6814249, 9041957, 11847485, 15345233,
  19665841, 24957661, 31388293, 39146185, 48442297, 59511829, 72616013,
  88043969, 106114625, 127178701, 151620757, 179861305, 212358985, 249612805,
  292164445, 340600625, 395555537, 457713341, 527810725, 606639529, 695049433,
  793950709, 904317037, 1027188385, 1163673953, 1314955181, 1482288821,
  1667010073, 1870535785, 2094367717,
#if defined(CUSTOM_MODES)
  /*...60:*/
  2340095869U, 2609401873U, 2904062449U, 3225952925U, 3577050821U, 3959439497U,
#endif
  /*N=8, K=8...37*/
  48639, 108545, 224143, 433905, 795455, 1392065, 2340495, 3800305, 5984767,
  9173505, 13726991, 20103025, 28875327, 40754369, 56610575, 77500017,
  104692735, 139703809, 184327311, 240673265, 311207743, 398796225, 506750351,
  638878193, 799538175, 993696769, 1226990095, 1505789553, 1837271615,
  2229491905U,
#if defined(CUSTOM_MODES)
  /*...40:*/
  2691463695U, 3233240945U, 3866006015U,
#endif
  /*N=9, K=9...28:*/
  265729, 598417, 1256465, 2485825, 4673345, 8405905, 14546705, 24331777,
  39490049, 62390545, 96220561, 145198913, 214828609, 312193553, 446304145,
  628496897, 872893441, 1196924561, 1621925137, 2173806145U,
#if defined(CUSTOM_MODES)
  /*...29:*/
  2883810113U,
#endif
  /*N=10, K=10...24:*/
  1462563, 3317445, 7059735, 14218905, 27298155, 50250765, 89129247, 152951073,
  254831667, 413442773, 654862247, 1014889769, 1541911931, 2300409629U,
  3375210671U,
  /*N=11, K=11...19:*/
  8097453, 18474633, 39753273, 81270333, 158819253, 298199265, 540279585,
  948062325, 1616336765,
#if defined(CUSTOM_MODES)
  /*...20:*/
  2684641785U,
#endif
  /*N=12, K=12...18:*/
  45046719, 103274625, 224298231, 464387817, 921406335, 1759885185,
  3248227095U,
  /*N=13, K=13...16:*/
  251595969, 579168825, 1267854873, 2653649025U,
  /*N=14, K=14:*/
  1409933619
};

static const uint32_t *const ropus_pvq_u_row[15]={
  ropus_pvq_u_data+   0,ropus_pvq_u_data+ 176,ropus_pvq_u_data+ 351,
  ropus_pvq_u_data+ 525,ropus_pvq_u_data+ 698,ropus_pvq_u_data+ 870,
  ropus_pvq_u_data+1041,ropus_pvq_u_data+1131,ropus_pvq_u_data+1178,
  ropus_pvq_u_data+1207,ropus_pvq_u_data+1226,ropus_pvq_u_data+1240,
  ropus_pvq_u_data+1248,ropus_pvq_u_data+1254,ropus_pvq_u_data+1257
};

/* Fixed-point MDCT/FFT twiddles (static_modes_fixed.h, Q15 int16). */

typedef struct { int16_t r, i; } ropus_cpx_q;

static const ropus_cpx_q ropus_fft_twiddles_q[480] = {
{32767, 0}, {32766, -429},
{32757, -858}, {32743, -1287},
{32724, -1715}, {32698, -2143},
{32667, -2570}, {32631, -2998},
{32588, -3425}, {32541, -3851},
{32488, -4277}, {32429, -4701},
{32364, -5125}, {32295, -5548},
{32219, -5971}, {32138, -6393},
{32051, -6813}, {31960, -7231},
{31863, -7650}, {31760, -8067},
{31652, -8481}, {31539, -8895},
{31419, -9306}, {31294, -9716},
{31165, -10126}, {31030, -10532},
{30889, -10937}, {30743, -11340},
{30592, -11741}, {30436, -12141},
{30274, -12540}, {30107, -12935},
{29936, -13328}, {29758, -13718},
{29577, -14107}, {29390, -14493},
{29197, -14875}, {29000, -15257},
{28797, -15635}, {28590, -16010},
{28379, -16384}, {28162, -16753},
{27940, -17119}, {27714, -17484},
{27482, -17845}, {27246, -18205},
{27006, -18560}, {26760, -18911},
{26510, -19260}, {26257, -19606},
{25997, -19947}, {25734, -20286},
{25466, -20621}, {25194, -20952},
{24918, -21281}, {24637, -21605},
{24353, -21926}, {24063, -22242},
{23770, -22555}, {23473, -22865},
{23171, -23171}, {22866, -23472},
{22557, -23769}, {22244, -24063},
{21927, -24352}, {21606, -24636},
{21282, -24917}, {20954, -25194},
{20622, -25465}, {20288, -25733},
{19949, -25997}, {19607, -26255},
{19261, -26509}, {18914, -26760},
{18561, -27004}, {18205, -27246},
{17846, -27481}, {17485, -27713},
{17122, -27940}, {16755, -28162},
{16385, -28378}, {16012, -28590},
{15636, -28797}, {15258, -28999},
{14878, -29197}, {14494, -29389},
{14108, -29576}, {13720, -29757},
{13329, -29934}, {12937, -30107},
{12540, -30274}, {12142, -30435},
{11744, -30592}, {11342, -30743},
{10939, -30889}, {10534, -31030},
{10127, -31164}, {9718, -31294},
{9307, -31418}, {8895, -31537},
{8482, -31652}, {8067, -31759},
{7650, -31862}, {7233, -31960},
{6815, -32051}, {6393, -32138},
{5973, -32219}, {5549, -32294},
{5127, -32364}, {4703, -32429},
{4278, -32487}, {3852, -32541},
{3426, -32588}, {2999, -32630},
{2572, -32667}, {2144, -32698},
{1716, -32724}, {1287, -32742},
{860, -32757}, {430, -32766},
{0, -32767}, {-429, -32766},
{-858, -32757}, {-1287, -32743},
{-1715, -32724}, {-2143, -32698},
{-2570, -32667}, {-2998, -32631},
{-3425, -32588}, {-3851, -32541},
{-4277, -32488}, {-4701, -32429},
{-5125, -32364}, {-5548, -32295},
{-5971, -32219}, {-6393, -32138},
{-6813, -32051}, {-7231, -31960},
{-7650, -31863}, {-8067, -31760},
{-8481, -31652}, {-8895, -31539},
{-9306, -31419}, {-9716, -31294},
{-10126, -31165}, {-10532, -31030},
{-10937, -30889}, {-11340, -30743},
{-11741, -30592}, {-12141, -30436},
{-12540, -30274}, {-12935, -30107},
{-13328, -29936}, {-13718, -29758},
{-14107, -29577}, {-14493, -29390},
{-14875, -29197}, {-15257, -29000},
{-15635, -28797}, {-16010, -28590},
{-16384, -28379}, {-16753, -28162},
{-17119, -27940}, {-17484, -27714},
{-17845, -27482}, {-18205, -27246},
{-18560, -27006}, {-18911, -26760},
{-19260, -26510}, {-19606, -26257},
{-19947, -25997}, {-20286, -25734},
{-20621, -25466}, {-20952, -25194},
{-21281, -24918}, {-21605, -24637},
{-21926, -24353}, {-22242, -24063},
{-22555, -23770}, {-22865, -23473},
{-23171, -23171}, {-23472, -22866},
{-23769, -22557}, {-24063, -22244},
{-24352, -21927}, {-24636, -21606},
{-24917, -21282}, {-25194, -20954},
{-25465, -20622}, {-25733, -20288},
{-25997, -19949}, {-26255, -19607},
{-26509, -19261}, {-26760, -18914},
{-27004, -18561}, {-27246, -18205},
{-27481, -17846}, {-27713, -17485},
{-27940, -17122}, {-28162, -16755},
{-28378, -16385}, {-28590, -16012},
{-28797, -15636}, {-28999, -15258},
{-29197, -14878}, {-29389, -14494},
{-29576, -14108}, {-29757, -13720},
{-29934, -13329}, {-30107, -12937},
{-30274, -12540}, {-30435, -12142},
{-30592, -11744}, {-30743, -11342},
{-30889, -10939}, {-31030, -10534},
{-31164, -10127}, {-31294, -9718},
{-31418, -9307}, {-31537, -8895},
{-31652, -8482}, {-31759, -8067},
{-31862, -7650}, {-31960, -7233},
{-32051, -6815}, {-32138, -6393},
{-32219, -5973}, {-32294, -5549},
{-32364, -5127}, {-32429, -4703},
{-32487, -4278}, {-32541, -3852},
{-32588, -3426}, {-32630, -2999},
{-32667, -2572}, {-32698, -2144},
{-32724, -1716}, {-32742, -1287},
{-32757, -860}, {-32766, -430},
{-32767, 0}, {-32766, 429},
{-32757, 858}, {-32743, 1287},
{-32724, 1715}, {-32698, 2143},
{-32667, 2570}, {-32631, 2998},
{-32588, 3425}, {-32541, 3851},
{-32488, 4277}, {-32429, 4701},
{-32364, 5125}, {-32295, 5548},
{-32219, 5971}, {-32138, 6393},
{-32051, 6813}, {-31960, 7231},
{-31863, 7650}, {-31760, 8067},
{-31652, 8481}, {-31539, 8895},
{-31419, 9306}, {-31294, 9716},
{-31165, 10126}, {-31030, 10532},
{-30889, 10937}, {-30743, 11340},
{-30592, 11741}, {-30436, 12141},
{-30274, 12540}, {-30107, 12935},
{-29936, 13328}, {-29758, 13718},
{-29577, 14107}, {-29390, 14493},
{-29197, 14875}, {-29000, 15257},
{-28797, 15635}, {-28590, 16010},
{-28379, 16384}, {-28162, 16753},
{-27940, 17119}, {-27714, 17484},
{-27482, 17845}, {-27246, 18205},
{-27006, 18560}, {-26760, 18911},
{-26510, 19260}, {-26257, 19606},
{-25997, 19947}, {-25734, 20286},
{-25466, 20621}, {-25194, 20952},
{-24918, 21281}, {-24637, 21605},
{-24353, 21926}, {-24063, 22242},
{-23770, 22555}, {-23473, 22865},
{-23171, 23171}, {-22866, 23472},
{-22557, 23769}, {-22244, 24063},
{-21927, 24352}, {-21606, 24636},
{-21282, 24917}, {-20954, 25194},
{-20622, 25465}, {-20288, 25733},
{-19949, 25997}, {-19607, 26255},
{-19261, 26509}, {-18914, 26760},
{-18561, 27004}, {-18205, 27246},
{-17846, 27481}, {-17485, 27713},
{-17122, 27940}, {-16755, 28162},
{-16385, 28378}, {-16012, 28590},
{-15636, 28797}, {-15258, 28999},
{-14878, 29197}, {-14494, 29389},
{-14108, 29576}, {-13720, 29757},
{-13329, 29934}, {-12937, 30107},
{-12540, 30274}, {-12142, 30435},
{-11744, 30592}, {-11342, 30743},
{-10939, 30889}, {-10534, 31030},
{-10127, 31164}, {-9718, 31294},
{-9307, 31418}, {-8895, 31537},
{-8482, 31652}, {-8067, 31759},
{-7650, 31862}, {-7233, 31960},
{-6815, 32051}, {-6393, 32138},
{-5973, 32219}, {-5549, 32294},
{-5127, 32364}, {-4703, 32429},
{-4278, 32487}, {-3852, 32541},
{-3426, 32588}, {-2999, 32630},
{-2572, 32667}, {-2144, 32698},
{-1716, 32724}, {-1287, 32742},
{-860, 32757}, {-430, 32766},
{0, 32767}, {429, 32766},
{858, 32757}, {1287, 32743},
{1715, 32724}, {2143, 32698},
{2570, 32667}, {2998, 32631},
{3425, 32588}, {3851, 32541},
{4277, 32488}, {4701, 32429},
{5125, 32364}, {5548, 32295},
{5971, 32219}, {6393, 32138},
{6813, 32051}, {7231, 31960},
{7650, 31863}, {8067, 31760},
{8481, 31652}, {8895, 31539},
{9306, 31419}, {9716, 31294},
{10126, 31165}, {10532, 31030},
{10937, 30889}, {11340, 30743},
{11741, 30592}, {12141, 30436},
{12540, 30274}, {12935, 30107},
{13328, 29936}, {13718, 29758},
{14107, 29577}, {14493, 29390},
{14875, 29197}, {15257, 29000},
{15635, 28797}, {16010, 28590},
{16384, 28379}, {16753, 28162},
{17119, 27940}, {17484, 27714},
{17845, 27482}, {18205, 27246},
{18560, 27006}, {18911, 26760},
{19260, 26510}, {19606, 26257},
{19947, 25997}, {20286, 25734},
{20621, 25466}, {20952, 25194},
{21281, 24918}, {21605, 24637},
{21926, 24353}, {22242, 24063},
{22555, 23770}, {22865, 23473},
{23171, 23171}, {23472, 22866},
{23769, 22557}, {24063, 22244},
{24352, 21927}, {24636, 21606},
{24917, 21282}, {25194, 20954},
{25465, 20622}, {25733, 20288},
{25997, 19949}, {26255, 19607},
{26509, 19261}, {26760, 18914},
{27004, 18561}, {27246, 18205},
{27481, 17846}, {27713, 17485},
{27940, 17122}, {28162, 16755},
{28378, 16385}, {28590, 16012},
{28797, 15636}, {28999, 15258},
{29197, 14878}, {29389, 14494},
{29576, 14108}, {29757, 13720},
{29934, 13329}, {30107, 12937},
{30274, 12540}, {30435, 12142},
{30592, 11744}, {30743, 11342},
{30889, 10939}, {31030, 10534},
{31164, 10127}, {31294, 9718},
{31418, 9307}, {31537, 8895},
{31652, 8482}, {31759, 8067},
{31862, 7650}, {31960, 7233},
{32051, 6815}, {32138, 6393},
{32219, 5973}, {32294, 5549},
{32364, 5127}, {32429, 4703},
{32487, 4278}, {32541, 3852},
{32588, 3426}, {32630, 2999},
{32667, 2572}, {32698, 2144},
{32724, 1716}, {32742, 1287},
{32757, 860}, {32766, 430},
};

static const int16_t ropus_mdct_twiddles_q[1800] = {
32767, 32767, 32767, 32766, 32765,
32763, 32761, 32759, 32756, 32753,
32750, 32746, 32742, 32738, 32733,
32728, 32722, 32717, 32710, 32704,
32697, 32690, 32682, 32674, 32666,
32657, 32648, 32639, 32629, 32619,
32609, 32598, 32587, 32576, 32564,
32552, 32539, 32526, 32513, 32500,
32486, 32472, 32457, 32442, 32427,
32411, 32395, 32379, 32362, 32345,
32328, 32310, 32292, 32274, 32255,
32236, 32217, 32197, 32177, 32157,
32136, 32115, 32093, 32071, 32049,
32027, 32004, 31981, 31957, 31933,
31909, 31884, 31859, 31834, 31809,
31783, 31756, 31730, 31703, 31676,
31648, 31620, 31592, 31563, 31534,
31505, 31475, 31445, 31415, 31384,
31353, 31322, 31290, 31258, 31226,
31193, 31160, 31127, 31093, 31059,
31025, 30990, 30955, 30920, 30884,
30848, 30812, 30775, 30738, 30701,
30663, 30625, 30587, 30548, 30509,
30470, 30430, 30390, 30350, 30309,
30269, 30227, 30186, 30144, 30102,
30059, 30016, 29973, 29930, 29886,
29842, 29797, 29752, 29707, 29662,
29616, 29570, 29524, 29477, 29430,
29383, 29335, 29287, 29239, 29190,
29142, 29092, 29043, 28993, 28943,
28892, 28842, 28791, 28739, 28688,
28636, 28583, 28531, 28478, 28425,
28371, 28317, 28263, 28209, 28154,
28099, 28044, 27988, 27932, 27876,
27820, 27763, 27706, 27648, 27591,
27533, 27474, 27416, 27357, 27298,
27238, 27178, 27118, 27058, 26997,
26936, 26875, 26814, 26752, 26690,
26628, 26565, 26502, 26439, 26375,
26312, 26247, 26183, 26119, 26054,
25988, 25923, 25857, 25791, 25725,
25658, 25592, 25524, 25457, 25389,
25322, 25253, 25185, 25116, 25047,
24978, 24908, 24838, 24768, 24698,
24627, 24557, 24485, 24414, 24342,
24270, 24198, 24126, 24053, 23980,
23907, 23834, 23760, 23686, 23612,
23537, 23462, 23387, 23312, 23237,
23161, 23085, 23009, 22932, 22856,
22779, 22701, 22624, 22546, 22468,
22390, 22312, 22233, 22154, 22075,
21996, 21916, 21836, 21756, 21676,
21595, 21515, 21434, 21352, 21271,
21189, 21107, 21025, 20943, 20860,
20777, 20694, 20611, 20528, 20444,
20360, 20276, 20192, 20107, 20022,
19937, 19852, 19767, 19681, 19595,
19509, 19423, 19336, 19250, 19163,
19076, 18988, 18901, 18813, 18725,
18637, 18549, 18460, 18372, 18283,
18194, 18104, 18015, 17925, 17835,
17745, 17655, 17565, 17474, 17383,
17292, 17201, 17110, 17018, 16927,
16835, 16743, 16650, 16558, 16465,
16372, 16279, 16186, 16093, 15999,
15906, 15812, 15718, 15624, 15529,
15435, 15340, 15245, 15150, 15055,
14960, 14864, 14769, 14673, 14577,
14481, 14385, 14288, 14192, 14095,
13998, 13901, 13804, 13706, 13609,
13511, 13414, 13316, 13218, 13119,
13021, 12923, 12824, 12725, 12626,
12527, 12428, 12329, 12230, 12130,
12030, 11930, 11831, 11730, 11630,
11530, 11430, 11329, 11228, 11128,
11027, 10926, 10824, 10723, 10622,
10520, 10419, 10317, 10215, 10113,
10011, 9909, 9807, 9704, 9602,
9499, 9397, 9294, 9191, 9088,
8985, 8882, 8778, 8675, 8572,
8468, 8364, 8261, 8157, 8053,
7949, 7845, 7741, 7637, 7532,
7428, 7323, 7219, 7114, 7009,
6905, 6800, 6695, 6590, 6485,
6380, 6274, 6169, 6064, 5958,
5853, 5747, 5642, 5536, 5430,
5325, 5219, 5113, 5007, 4901,
4795, 4689, 4583, 4476, 4370,
4264, 4157, 4051, 3945, 3838,
3732, 3625, 3518, 3412, 3305,
3198, 3092, 2985, 2878, 2771,
2664, 2558, 2451, 2344, 2237,
2130, 2023, 1916, 1809, 1702,
1594, 1487, 1380, 1273, 1166,
1059, 952, 844, 737, 630,
523, 416, 308, 201, 94,
-13, -121, -228, -335, -442,
-550, -657, -764, -871, -978,
-1086, -1193, -1300, -1407, -1514,
-1621, -1728, -1835, -1942, -2049,
-2157, -2263, -2370, -2477, -2584,
-2691, -2798, -2905, -3012, -3118,
-3225, -3332, -3439, -3545, -3652,
-3758, -3865, -3971, -4078, -4184,
-4290, -4397, -4503, -4609, -4715,
-4821, -4927, -5033, -5139, -5245,
-5351, -5457, -5562, -5668, -5774,
-5879, -5985, -6090, -6195, -6301,
-6406, -6511, -6616, -6721, -6826,
-6931, -7036, -7140, -7245, -7349,
-7454, -7558, -7663, -7767, -7871,
-7975, -8079, -8183, -8287, -8390,
-8494, -8597, -8701, -8804, -8907,
-9011, -9114, -9217, -9319, -9422,
-9525, -9627, -9730, -9832, -9934,
-10037, -10139, -10241, -10342, -10444,
-10546, -10647, -10748, -10850, -10951,
-11052, -11153, -11253, -11354, -11455,
-11555, -11655, -11756, -11856, -11955,
-12055, -12155, -12254, -12354, -12453,
-12552, -12651, -12750, -12849, -12947,
-13046, -13144, -13242, -13340, -13438,
-13536, -13633, -13731, -13828, -13925,
-14022, -14119, -14216, -14312, -14409,
-14505, -14601, -14697, -14793, -14888,
-14984, -15079, -15174, -15269, -15364,
-15459, -15553, -15647, -15741, -15835,
-15929, -16023, -16116, -16210, -16303,
-16396, -16488, -16581, -16673, -16766,
-16858, -16949, -17041, -17133, -17224,
-17315, -17406, -17497, -17587, -17678,
-17768, -17858, -17948, -18037, -18127,
-18216, -18305, -18394, -18483, -18571,
-18659, -18747, -18835, -18923, -19010,
-19098, -19185, -19271, -19358, -19444,
-19531, -19617, -19702, -19788, -19873,
-19959, -20043, -20128, -20213, -20297,
-20381, -20465, -20549, -20632, -20715,
-20798, -20881, -20963, -21046, -21128,
-21210, -21291, -21373, -21454, -21535,
-21616, -21696, -21776, -21856, -21936,
-22016, -22095, -22174, -22253, -22331,
-22410, -22488, -22566, -22643, -22721,
-22798, -22875, -22951, -23028, -23104,
-23180, -23256, -23331, -23406, -23481,
-23556, -23630, -23704, -23778, -23852,
-23925, -23998, -24071, -24144, -24216,
-24288, -24360, -24432, -24503, -24574,
-24645, -24716, -24786, -24856, -24926,
-24995, -25064, -25133, -25202, -25270,
-25339, -25406, -25474, -25541, -25608,
-25675, -25742, -25808, -25874, -25939,
-26005, -26070, -26135, -26199, -26264,
-26327, -26391, -26455, -26518, -26581,
-26643, -26705, -26767, -26829, -26891,
-26952, -27013, -27073, -27133, -27193,
-27253, -27312, -27372, -27430, -27489,
-27547, -27605, -27663, -27720, -27777,
-27834, -27890, -27946, -28002, -28058,
-28113, -28168, -28223, -28277, -28331,
-28385, -28438, -28491, -28544, -28596,
-28649, -28701, -28752, -28803, -28854,
-28905, -28955, -29006, -29055, -29105,
-29154, -29203, -29251, -29299, -29347,
-29395, -29442, -29489, -29535, -29582,
-29628, -29673, -29719, -29764, -29808,
-29853, -29897, -29941, -29984, -30027,
-30070, -30112, -30154, -30196, -30238,
-30279, -30320, -30360, -30400, -30440,
-30480, -30519, -30558, -30596, -30635,
-30672, -30710, -30747, -30784, -30821,
-30857, -30893, -30929, -30964, -30999,
-31033, -31068, -31102, -31135, -31168,
-31201, -31234, -31266, -31298, -31330,
-31361, -31392, -31422, -31453, -31483,
-31512, -31541, -31570, -31599, -31627,
-31655, -31682, -31710, -31737, -31763,
-31789, -31815, -31841, -31866, -31891,
-31915, -31939, -31963, -31986, -32010,
-32032, -32055, -32077, -32099, -32120,
-32141, -32162, -32182, -32202, -32222,
-32241, -32260, -32279, -32297, -32315,
-32333, -32350, -32367, -32383, -32399,
-32415, -32431, -32446, -32461, -32475,
-32489, -32503, -32517, -32530, -32542,
-32555, -32567, -32579, -32590, -32601,
-32612, -32622, -32632, -32641, -32651,
-32659, -32668, -32676, -32684, -32692,
-32699, -32706, -32712, -32718, -32724,
-32729, -32734, -32739, -32743, -32747,
-32751, -32754, -32757, -32760, -32762,
-32764, -32765, -32767, -32767, -32767,
32767, 32767, 32765, 32761, 32756,
32750, 32742, 32732, 32722, 32710,
32696, 32681, 32665, 32647, 32628,
32608, 32586, 32562, 32538, 32512,
32484, 32455, 32425, 32393, 32360,
32326, 32290, 32253, 32214, 32174,
32133, 32090, 32046, 32001, 31954,
31906, 31856, 31805, 31753, 31700,
31645, 31588, 31530, 31471, 31411,
31349, 31286, 31222, 31156, 31089,
31020, 30951, 30880, 30807, 30733,
30658, 30582, 30504, 30425, 30345,
30263, 30181, 30096, 30011, 29924,
29836, 29747, 29656, 29564, 29471,
29377, 29281, 29184, 29086, 28987,
28886, 28784, 28681, 28577, 28471,
28365, 28257, 28147, 28037, 27925,
27812, 27698, 27583, 27467, 27349,
27231, 27111, 26990, 26868, 26744,
26620, 26494, 26367, 26239, 26110,
25980, 25849, 25717, 25583, 25449,
25313, 25176, 25038, 24900, 24760,
24619, 24477, 24333, 24189, 24044,
23898, 23751, 23602, 23453, 23303,
23152, 22999, 22846, 22692, 22537,
22380, 22223, 22065, 21906, 21746,
21585, 21423, 21261, 21097, 20933,
20767, 20601, 20434, 20265, 20096,
19927, 19756, 19584, 19412, 19239,
19065, 18890, 18714, 18538, 18361,
18183, 18004, 17824, 17644, 17463,
17281, 17098, 16915, 16731, 16546,
16361, 16175, 15988, 15800, 15612,
15423, 15234, 15043, 14852, 14661,
14469, 14276, 14083, 13889, 13694,
13499, 13303, 13107, 12910, 12713,
12515, 12317, 12118, 11918, 11718,
11517, 11316, 11115, 10913, 10710,
10508, 10304, 10100, 9896, 9691,
9486, 9281, 9075, 8869, 8662,
8455, 8248, 8040, 7832, 7623,
7415, 7206, 6996, 6787, 6577,
6366, 6156, 5945, 5734, 5523,
5311, 5100, 4888, 4675, 4463,
4251, 4038, 3825, 3612, 3399,
3185, 2972, 2758, 2544, 2330,
2116, 1902, 1688, 1474, 1260,
1045, 831, 617, 402, 188,
-27, -241, -456, -670, -885,
-1099, -1313, -1528, -1742, -1956,
-2170, -2384, -2598, -2811, -3025,
-3239, -3452, -3665, -3878, -4091,
-4304, -4516, -4728, -4941, -5153,
-5364, -5576, -5787, -5998, -6209,
-6419, -6629, -6839, -7049, -7258,
-7467, -7676, -7884, -8092, -8300,
-8507, -8714, -8920, -9127, -9332,
-9538, -9743, -9947, -10151, -10355,
-10558, -10761, -10963, -11165, -11367,
-11568, -11768, -11968, -12167, -12366,
-12565, -12762, -12960, -13156, -13352,
-13548, -13743, -13937, -14131, -14324,
-14517, -14709, -14900, -15091, -15281,
-15470, -15659, -15847, -16035, -16221,
-16407, -16593, -16777, -16961, -17144,
-17326, -17508, -17689, -17869, -18049,
-18227, -18405, -18582, -18758, -18934,
-19108, -19282, -19455, -19627, -19799,
-19969, -20139, -20308, -20475, -20642,
-20809, -20974, -21138, -21301, -21464,
-21626, -21786, -21946, -22105, -22263,
-22420, -22575, -22730, -22884, -23037,
-23189, -23340, -23490, -23640, -23788,
-23935, -24080, -24225, -24369, -24512,
-24654, -24795, -24934, -25073, -25211,
-25347, -25482, -25617, -25750, -25882,
-26013, -26143, -26272, -26399, -26526,
-26651, -26775, -26898, -27020, -27141,
-27260, -27379, -27496, -27612, -27727,
-27841, -27953, -28065, -28175, -28284,
-28391, -28498, -28603, -28707, -28810,
-28911, -29012, -29111, -29209, -29305,
-29401, -29495, -29587, -29679, -29769,
-29858, -29946, -30032, -30118, -30201,
-30284, -30365, -30445, -30524, -30601,
-30677, -30752, -30825, -30897, -30968,
-31038, -31106, -31172, -31238, -31302,
-31365, -31426, -31486, -31545, -31602,
-31658, -31713, -31766, -31818, -31869,
-31918, -31966, -32012, -32058, -32101,
-32144, -32185, -32224, -32262, -32299,
-32335, -32369, -32401, -32433, -32463,
-32491, -32518, -32544, -32568, -32591,
-32613, -32633, -32652, -32669, -32685,
-32700, -32713, -32724, -32735, -32744,
-32751, -32757, -32762, -32766, -32767,
32767, 32764, 32755, 32741, 32720,
32694, 32663, 32626, 32583, 32535,
32481, 32421, 32356, 32286, 32209,
32128, 32041, 31948, 31850, 31747,
31638, 31523, 31403, 31278, 31148,
31012, 30871, 30724, 30572, 30415,
30253, 30086, 29913, 29736, 29553,
29365, 29172, 28974, 28771, 28564,
28351, 28134, 27911, 27684, 27452,
27216, 26975, 26729, 26478, 26223,
25964, 25700, 25432, 25159, 24882,
24601, 24315, 24026, 23732, 23434,
23133, 22827, 22517, 22204, 21886,
21565, 21240, 20912, 20580, 20244,
19905, 19563, 19217, 18868, 18516,
18160, 17802, 17440, 17075, 16708,
16338, 15964, 15588, 15210, 14829,
14445, 14059, 13670, 13279, 12886,
12490, 12093, 11693, 11291, 10888,
10482, 10075, 9666, 9255, 8843,
8429, 8014, 7597, 7180, 6760,
6340, 5919, 5496, 5073, 4649,
4224, 3798, 3372, 2945, 2517,
2090, 1661, 1233, 804, 375,
-54, -483, -911, -1340, -1768,
-2197, -2624, -3052, -3479, -3905,
-4330, -4755, -5179, -5602, -6024,
-6445, -6865, -7284, -7702, -8118,
-8533, -8946, -9358, -9768, -10177,
-10584, -10989, -11392, -11793, -12192,
-12589, -12984, -13377, -13767, -14155,
-14541, -14924, -15305, -15683, -16058,
-16430, -16800, -17167, -17531, -17892,
-18249, -18604, -18956, -19304, -19649,
-19990, -20329, -20663, -20994, -21322,
-21646, -21966, -22282, -22595, -22904,
-23208, -23509, -23806, -24099, -24387,
-24672, -24952, -25228, -25499, -25766,
-26029, -26288, -26541, -26791, -27035,
-27275, -27511, -27741, -27967, -28188,
-28405, -28616, -28823, -29024, -29221,
-29412, -29599, -29780, -29957, -30128,
-30294, -30455, -30611, -30761, -30906,
-31046, -31181, -31310, -31434, -31552,
-31665, -31773, -31875, -31972, -32063,
-32149, -32229, -32304, -32373, -32437,
-32495, -32547, -32594, -32635, -32671,
-32701, -32726, -32745, -32758, -32766,
32767, 32754, 32717, 32658, 32577,
32473, 32348, 32200, 32029, 31837,
31624, 31388, 31131, 30853, 30553,
30232, 29891, 29530, 29148, 28746,
28324, 27883, 27423, 26944, 26447,
25931, 25398, 24847, 24279, 23695,
23095, 22478, 21846, 21199, 20538,
19863, 19174, 18472, 17757, 17030,
16291, 15541, 14781, 14010, 13230,
12441, 11643, 10837, 10024, 9204,
8377, 7545, 6708, 5866, 5020,
4171, 3319, 2464, 1608, 751,
-107, -965, -1822, -2678, -3532,
-4383, -5232, -6077, -6918, -7754,
-8585, -9409, -10228, -11039, -11843,
-12639, -13426, -14204, -14972, -15730,
-16477, -17213, -17937, -18648, -19347,
-20033, -20705, -21363, -22006, -22634,
-23246, -23843, -24423, -24986, -25533,
-26062, -26573, -27066, -27540, -27995,
-28431, -28848, -29245, -29622, -29979,
-30315, -30630, -30924, -31197, -31449,
-31679, -31887, -32074, -32239, -32381,
-32501, -32600, -32675, -32729, -32759,
};

#define ROPUS_NBANDS      21
#define ROPUS_OVERLAP     120
#define ROPUS_SHORT_MDCT  120
#define ROPUS_MAXLM       3
#define ROPUS_DECODE_BUFFER_SIZE 2048
#define ROPUS_LPC_ORDER   24
#define ROPUS_MAX_FINE_BITS 8
#define ROPUS_BITRES      3
#define ROPUS_MAX_PERIOD  1024
#define ROPUS_COMBFILTER_MINPERIOD 15

static INLINE int ropus_imin(int a, int b) { return a < b ? a : b; }
static INLINE int ropus_imax(int a, int b) { return a > b ? a : b; }
static INLINE float ropus_minf(float a, float b) { return a < b ? a : b; }
static INLINE float ropus_maxf(float a, float b) { return a > b ? a : b; }

/* ==================================================================== */
/* Laplace decoder (celt/laplace.c).                                    */
/* ==================================================================== */
#define ROPUS_LAPLACE_LOG_MINP 0
#define ROPUS_LAPLACE_MINP (1 << ROPUS_LAPLACE_LOG_MINP)
#define ROPUS_LAPLACE_NMIN 16

static unsigned ropus_laplace_get_freq1(unsigned fs0, int decay)
{
   unsigned ft = 32768 - ROPUS_LAPLACE_MINP * (2 * ROPUS_LAPLACE_NMIN) - fs0;
   return ft * (uint32_t)(16384 - decay) >> 15;
}

static int ropus_ec_laplace_decode(ropus_ec *dec, unsigned fs, int decay)
{
   int val = 0;
   unsigned fl, fm;
   fm = ropus_ec_decode_bin(dec, 15);
   fl = 0;
   if (fm >= fs)
   {
      val++;
      fl = fs;
      fs = ropus_laplace_get_freq1(fs, decay) + ROPUS_LAPLACE_MINP;
      while (fs > ROPUS_LAPLACE_MINP && fm >= fl + 2 * fs)
      {
         fs *= 2;
         fl += fs;
         fs = ((fs - 2 * ROPUS_LAPLACE_MINP) * (uint32_t)decay) >> 15;
         fs += ROPUS_LAPLACE_MINP;
         val++;
      }
      if (fs <= ROPUS_LAPLACE_MINP)
      {
         int di = (fm - fl) >> (ROPUS_LAPLACE_LOG_MINP + 1);
         val += di;
         fl += 2 * di * ROPUS_LAPLACE_MINP;
      }
      if (fm < fl + fs)
         val = -val;
      else
         fl += fs;
   }
   ropus_ec_dec_update(dec, fl,
      fl + fs < 32768 ? fl + fs : 32768, 32768);
   return val;
}

/* ==================================================================== */
/* Energy envelope decode, float pipeline (celt/quant_bands.c).         */
/* ==================================================================== */
static const float ropus_pred_coef[4] =
   { 29440 / 32768.f, 26112 / 32768.f, 21248 / 32768.f, 16384 / 32768.f };
static const float ropus_beta_coef[4] =
   { 30147 / 32768.f, 22282 / 32768.f, 12124 / 32768.f, 6554 / 32768.f };
#define ROPUS_BETA_INTRA (4915 / 32768.f)

static void ropus_unquant_coarse_energy(int start, int end, float *oldEBands,
      int intra, ropus_ec *dec, int C, int LM)
{
   const uint8_t *prob_model = ropus_e_prob_model[LM][intra];
   int i, c;
   float prev[2] = { 0, 0 };
   float coef, beta;
   int32_t budget, tell;
   if (intra)
   {
      coef = 0;
      beta = ROPUS_BETA_INTRA;
   }
   else
   {
      beta = ropus_beta_coef[LM];
      coef = ropus_pred_coef[LM];
   }
   budget = dec->storage * 8;
   for (i = start; i < end; i++)
   {
      c = 0;
      do
      {
         int qi;
         float q, tmp;
         tell = ropus_ec_tell(dec);
         if (budget - tell >= 15)
         {
            int pi = 2 * ropus_imin(i, 20);
            qi = ropus_ec_laplace_decode(dec,
               prob_model[pi] << 7, prob_model[pi + 1] << 6);
         }
         else if (budget - tell >= 2)
         {
            qi = ropus_ec_dec_icdf(dec, ropus_small_energy_icdf, 2);
            qi = (qi >> 1) ^ -(qi & 1);
         }
         else if (budget - tell >= 1)
            qi = -ropus_ec_dec_bit_logp(dec, 1);
         else
            qi = -1;
         q = (float)qi;
         oldEBands[i + c * ROPUS_NBANDS] =
            ropus_maxf(-9.f, oldEBands[i + c * ROPUS_NBANDS]);
         tmp = coef * oldEBands[i + c * ROPUS_NBANDS] + prev[c] + q;
         oldEBands[i + c * ROPUS_NBANDS] = tmp;
         prev[c] = prev[c] + q - beta * q;
      } while (++c < C);
   }
}

static void ropus_unquant_fine_energy(int start, int end, float *oldEBands,
      const int *fine_quant, ropus_ec *dec, int C)
{
   int i, c;
   for (i = start; i < end; i++)
   {
      if (fine_quant[i] <= 0)
         continue;
      c = 0;
      do
      {
         int q2 = (int)ropus_ec_dec_bits(dec, fine_quant[i]);
         float offset = (q2 + .5f) * (1 << (14 - fine_quant[i]))
            * (1.f / 16384) - .5f;
         oldEBands[i + c * ROPUS_NBANDS] += offset;
      } while (++c < C);
   }
}

static void ropus_unquant_energy_finalise(int start, int end,
      float *oldEBands, const int *fine_quant, const int *fine_priority,
      int bits_left, ropus_ec *dec, int C)
{
   int i, prio, c;
   for (prio = 0; prio < 2; prio++)
   {
      for (i = start; i < end && bits_left >= C; i++)
      {
         if (fine_quant[i] >= ROPUS_MAX_FINE_BITS
               || fine_priority[i] != prio)
            continue;
         c = 0;
         do
         {
            int q2 = (int)ropus_ec_dec_bits(dec, 1);
            float offset = (q2 - .5f)
               * (1 << (14 - fine_quant[i] - 1)) * (1.f / 16384);
            oldEBands[i + c * ROPUS_NBANDS] += offset;
            bits_left--;
         } while (++c < C);
      }
   }
}

/* ==================================================================== */
/* Time-frequency resolution decode (celt_decoder.c tf_decode).         */
/* ==================================================================== */
static void ropus_tf_decode(int start, int end, int isTransient,
      int *tf_res, int LM, ropus_ec *dec)
{
   int i, curr, tf_select;
   int tf_select_rsv, tf_changed, logp;
   uint32_t budget, tell;
   budget = dec->storage * 8;
   tell = ropus_ec_tell(dec);
   logp = isTransient ? 2 : 4;
   tf_select_rsv = LM > 0 && tell + logp + 1 <= budget;
   budget -= tf_select_rsv;
   tf_changed = curr = 0;
   for (i = start; i < end; i++)
   {
      if (tell + logp <= budget)
      {
         curr ^= ropus_ec_dec_bit_logp(dec, logp);
         tell = ropus_ec_tell(dec);
         tf_changed |= curr;
      }
      tf_res[i] = curr;
      logp = isTransient ? 4 : 5;
   }
   tf_select = 0;
   if (tf_select_rsv &&
       ropus_tf_select_table[LM][4 * isTransient + 0 + tf_changed] !=
       ropus_tf_select_table[LM][4 * isTransient + 2 + tf_changed])
      tf_select = ropus_ec_dec_bit_logp(dec, 1);
   for (i = start; i < end; i++)
      tf_res[i] = ropus_tf_select_table[LM]
         [4 * isTransient + 2 * tf_select + tf_res[i]];
}

/* init_caps (celt/celt.c) */
static void ropus_init_caps(int *cap, int LM, int C)
{
   int i;
   for (i = 0; i < ROPUS_NBANDS; i++)
   {
      int N = (ropus_eband5ms[i + 1] - ropus_eband5ms[i]) << LM;
      cap[i] = (ropus_cache_caps50[ROPUS_NBANDS * (2 * LM + C - 1) + i]
         + 64) * C * N >> 2;
   }
}

/* ==================================================================== */
/* Bit allocation (celt/rate.c, rate.h).                                */
/* ==================================================================== */
#define ROPUS_ALLOC_STEPS     6
#define ROPUS_FINE_OFFSET     21
#define ROPUS_LOG_MAX_PSEUDO  6

static INLINE int ropus_get_pulses(int i)
{
   return i < 8 ? i : (8 + (i & 7)) << ((i >> 3) - 1);
}

static INLINE int ropus_bits2pulses(int band, int LM, int bits)
{
   int i, lo, hi;
   const uint8_t *cache;
   LM++;
   cache = ropus_cache_bits50
      + ropus_cache_index50[LM * ROPUS_NBANDS + band];
   lo = 0;
   hi = cache[0];
   bits--;
   for (i = 0; i < ROPUS_LOG_MAX_PSEUDO; i++)
   {
      int mid = (lo + hi + 1) >> 1;
      if ((int)cache[mid] >= bits)
         hi = mid;
      else
         lo = mid;
   }
   if (bits - (lo == 0 ? -1 : (int)cache[lo]) <= (int)cache[hi] - bits)
      return lo;
   return hi;
}

static INLINE int ropus_pulses2bits(int band, int LM, int pulses)
{
   const uint8_t *cache;
   LM++;
   cache = ropus_cache_bits50
      + ropus_cache_index50[LM * ROPUS_NBANDS + band];
   return pulses == 0 ? 0 : cache[pulses] + 1;
}

static int ropus_interp_bits2pulses(int start, int end, int skip_start,
      const int *bits1, const int *bits2, const int *thresh, const int *cap,
      int32_t total, int32_t *_balance, int skip_rsv,
      int *intensity, int intensity_rsv, int *dual_stereo,
      int dual_stereo_rsv, int *bits, int *ebits, int *fine_priority,
      int C, int LM, ropus_ec *ec)
{
   int32_t psum;
   int lo, hi, i, j;
   int logM, stereo, codedBands = -1, alloc_floor, done;
   int32_t left, percoeff, balance;
   const int16_t *eBands = ropus_eband5ms;

   alloc_floor = C << ROPUS_BITRES;
   stereo = C > 1;
   logM = LM << ROPUS_BITRES;
   lo = 0;
   hi = 1 << ROPUS_ALLOC_STEPS;
   for (i = 0; i < ROPUS_ALLOC_STEPS; i++)
   {
      int mid = (lo + hi) >> 1;
      psum = 0;
      done = 0;
      for (j = end; j-- > start;)
      {
         int tmp = bits1[j] + (mid * (int32_t)bits2[j] >> ROPUS_ALLOC_STEPS);
         if (tmp >= thresh[j] || done)
         {
            done = 1;
            psum += ropus_imin(tmp, cap[j]);
         }
         else if (tmp >= alloc_floor)
            psum += alloc_floor;
      }
      if (psum > total)
         hi = mid;
      else
         lo = mid;
   }
   psum = 0;
   done = 0;
   for (j = end; j-- > start;)
   {
      int tmp = bits1[j] + ((int32_t)lo * bits2[j] >> ROPUS_ALLOC_STEPS);
      if (tmp < thresh[j] && !done)
      {
         if (tmp >= alloc_floor)
            tmp = alloc_floor;
         else
            tmp = 0;
      }
      else
         done = 1;
      tmp = ropus_imin(tmp, cap[j]);
      bits[j] = tmp;
      psum += tmp;
   }
   for (codedBands = end;; codedBands--)
   {
      int band_width, band_bits, rem;
      j = codedBands - 1;
      if (j <= skip_start)
      {
         total += skip_rsv;
         break;
      }
      left = total - psum;
      percoeff = left / (eBands[codedBands] - eBands[start]);
      left -= (eBands[codedBands] - eBands[start]) * percoeff;
      rem = ropus_imax(left - (eBands[j] - eBands[start]), 0);
      band_width = eBands[codedBands] - eBands[j];
      band_bits = (int)(bits[j] + percoeff * band_width + rem);
      if (band_bits >= ropus_imax(thresh[j],
            alloc_floor + (1 << ROPUS_BITRES)))
      {
         if (ropus_ec_dec_bit_logp(ec, 1))
            break;
         psum += 1 << ROPUS_BITRES;
         band_bits -= 1 << ROPUS_BITRES;
      }
      psum -= bits[j] + intensity_rsv;
      if (intensity_rsv > 0)
         intensity_rsv = ropus_log2_frac_table[j - start];
      psum += intensity_rsv;
      if (band_bits >= alloc_floor)
      {
         psum += alloc_floor;
         bits[j] = alloc_floor;
      }
      else
         bits[j] = 0;
   }

   if (intensity_rsv > 0)
      *intensity = start + ropus_ec_dec_uint(ec, codedBands + 1 - start);
   else
      *intensity = 0;
   if (*intensity <= start)
   {
      total += dual_stereo_rsv;
      dual_stereo_rsv = 0;
   }
   if (dual_stereo_rsv > 0)
      *dual_stereo = ropus_ec_dec_bit_logp(ec, 1);
   else
      *dual_stereo = 0;

   left = total - psum;
   percoeff = left / (eBands[codedBands] - eBands[start]);
   left -= (eBands[codedBands] - eBands[start]) * percoeff;
   for (j = start; j < codedBands; j++)
      bits[j] += (int)percoeff * (eBands[j + 1] - eBands[j]);
   for (j = start; j < codedBands; j++)
   {
      int tmp = (int)ropus_imin(left, eBands[j + 1] - eBands[j]);
      bits[j] += tmp;
      left -= tmp;
   }

   balance = 0;
   for (j = start; j < codedBands; j++)
   {
      int N0, N, den, offset, NClogN;
      int32_t excess, bit;
      N0 = eBands[j + 1] - eBands[j];
      N = N0 << LM;
      bit = (int32_t)bits[j] + balance;
      if (N > 1)
      {
         excess = bit - cap[j] > 0 ? bit - cap[j] : 0;
         bits[j] = bit - excess;
         den = C * N + ((C == 2 && N > 2 && !*dual_stereo
            && j < *intensity) ? 1 : 0);
         NClogN = den * (ropus_logN400[j] + logM);
         offset = (NClogN >> 1) - den * ROPUS_FINE_OFFSET;
         if (N == 2)
            offset += den << ROPUS_BITRES >> 2;
         if (bits[j] + offset < den * 2 << ROPUS_BITRES)
            offset += NClogN >> 2;
         else if (bits[j] + offset < den * 3 << ROPUS_BITRES)
            offset += NClogN >> 3;
         ebits[j] = ropus_imax(0,
            bits[j] + offset + (den << (ROPUS_BITRES - 1)));
         ebits[j] = (int)((uint32_t)ebits[j] / den) >> ROPUS_BITRES;
         if (C * ebits[j] > (bits[j] >> ROPUS_BITRES))
            ebits[j] = bits[j] >> stereo >> ROPUS_BITRES;
         ebits[j] = ropus_imin(ebits[j], ROPUS_MAX_FINE_BITS);
         fine_priority[j] =
            ebits[j] * (den << ROPUS_BITRES) >= bits[j] + offset;
         bits[j] -= C * ebits[j] << ROPUS_BITRES;
      }
      else
      {
         excess = bit - (C << ROPUS_BITRES) > 0
            ? bit - (C << ROPUS_BITRES) : 0;
         bits[j] = bit - excess;
         ebits[j] = 0;
         fine_priority[j] = 1;
      }
      if (excess > 0)
      {
         int extra_fine, extra_bits;
         extra_fine = ropus_imin(excess >> (stereo + ROPUS_BITRES),
            ROPUS_MAX_FINE_BITS - ebits[j]);
         ebits[j] += extra_fine;
         extra_bits = extra_fine * C << ROPUS_BITRES;
         fine_priority[j] = extra_bits >= excess - balance;
         excess -= extra_bits;
      }
      balance = excess;
   }
   *_balance = balance;
   for (; j < end; j++)
   {
      ebits[j] = bits[j] >> stereo >> ROPUS_BITRES;
      bits[j] = 0;
      fine_priority[j] = ebits[j] < 1;
   }
   return codedBands;
}

static int ropus_compute_allocation(int start, int end, const int *offsets,
      const int *cap, int alloc_trim, int *intensity, int *dual_stereo,
      int32_t total, int32_t *balance, int *pulses, int *ebits,
      int *fine_priority, int C, int LM, ropus_ec *ec)
{
   int lo, hi, len, j, codedBands, skip_start;
   int skip_rsv, intensity_rsv, dual_stereo_rsv;
   int bits1[ROPUS_NBANDS], bits2[ROPUS_NBANDS];
   int thresh[ROPUS_NBANDS], trim_offset[ROPUS_NBANDS];
   const int16_t *eBands = ropus_eband5ms;

   total = ropus_imax(total, 0);
   len = ROPUS_NBANDS;
   skip_start = start;
   skip_rsv = total >= 1 << ROPUS_BITRES ? 1 << ROPUS_BITRES : 0;
   total -= skip_rsv;
   intensity_rsv = dual_stereo_rsv = 0;
   if (C == 2)
   {
      intensity_rsv = ropus_log2_frac_table[end - start];
      if (intensity_rsv > total)
         intensity_rsv = 0;
      else
      {
         total -= intensity_rsv;
         dual_stereo_rsv = total >= 1 << ROPUS_BITRES
            ? 1 << ROPUS_BITRES : 0;
         total -= dual_stereo_rsv;
      }
   }

   for (j = start; j < end; j++)
   {
      thresh[j] = ropus_imax(C << ROPUS_BITRES,
         (3 * (eBands[j + 1] - eBands[j]) << LM << ROPUS_BITRES) >> 4);
      trim_offset[j] = C * (eBands[j + 1] - eBands[j])
         * (alloc_trim - 5 - LM) * (end - j - 1)
         * (1 << (LM + ROPUS_BITRES)) >> 6;
      if ((eBands[j + 1] - eBands[j]) << LM == 1)
         trim_offset[j] -= C << ROPUS_BITRES;
   }
   lo = 1;
   hi = 11 - 1;                            /* nbAllocVectors - 1        */
   do
   {
      int done = 0;
      int psum = 0;
      int mid = (lo + hi) >> 1;
      for (j = end; j-- > start;)
      {
         int bitsj;
         int N = eBands[j + 1] - eBands[j];
         bitsj = C * N * ropus_band_allocation[mid * len + j] << LM >> 2;
         if (bitsj > 0)
            bitsj = ropus_imax(0, bitsj + trim_offset[j]);
         bitsj += offsets[j];
         if (bitsj >= thresh[j] || done)
         {
            done = 1;
            psum += ropus_imin(bitsj, cap[j]);
         }
         else if (bitsj >= C << ROPUS_BITRES)
            psum += C << ROPUS_BITRES;
      }
      if (psum > total)
         hi = mid - 1;
      else
         lo = mid + 1;
   } while (lo <= hi);
   hi = lo--;
   for (j = start; j < end; j++)
   {
      int bits1j, bits2j;
      int N = eBands[j + 1] - eBands[j];
      bits1j = C * N * ropus_band_allocation[lo * len + j] << LM >> 2;
      bits2j = hi >= 11 ? cap[j]
         : C * N * ropus_band_allocation[hi * len + j] << LM >> 2;
      if (bits1j > 0)
         bits1j = ropus_imax(0, bits1j + trim_offset[j]);
      if (bits2j > 0)
         bits2j = ropus_imax(0, bits2j + trim_offset[j]);
      if (lo > 0)
         bits1j += offsets[j];
      bits2j += offsets[j];
      if (offsets[j] > 0)
         skip_start = j;
      bits2j = ropus_imax(0, bits2j - bits1j);
      bits1[j] = bits1j;
      bits2[j] = bits2j;
   }
   codedBands = ropus_interp_bits2pulses(start, end, skip_start,
      bits1, bits2, thresh, cap, total, balance, skip_rsv,
      intensity, intensity_rsv, dual_stereo, dual_stereo_rsv,
      pulses, ebits, fine_priority, C, LM, ec);
   return codedBands;
}

/* ==================================================================== */
/* CELT decoder state (float pipeline).                                 */
/* ==================================================================== */
typedef struct
{
   int channels;            /* CC: output channels (1 or 2)             */
   int stream_channels;     /* C: coded channels                        */
   int start, end;          /* band range (0..21 for CELT-only FB)      */
   uint32_t rng;            /* PRNG state carried across frames         */
   int error;
   int postfilter_period, postfilter_period_old;
   float postfilter_gain, postfilter_gain_old;
   int postfilter_tapset, postfilter_tapset_old;
   float preemph_memD[2];
   int loss_duration;
   /* decode_mem[ch]: DECODE_BUFFER_SIZE history + overlap scratch      */
   float decode_mem[2][ROPUS_DECODE_BUFFER_SIZE + ROPUS_OVERLAP];
   float lpc[2 * ROPUS_LPC_ORDER];
   float oldEBands[2 * ROPUS_NBANDS];
   float oldLogE[2 * ROPUS_NBANDS];
   float oldLogE2[2 * ROPUS_NBANDS];
   float backgroundLogE[2 * ROPUS_NBANDS];
} ropus_celt;

static void ropus_celt_init(ropus_celt *st, int channels)
{
   int i;
   memset(st, 0, sizeof(*st));
   st->channels = channels;
   st->stream_channels = channels;
   st->start = 0;
   st->end = ROPUS_NBANDS;
   for (i = 0; i < 2 * ROPUS_NBANDS; i++)
      st->oldLogE[i] = st->oldLogE2[i] = -28.f;
}

/* Per-frame decode context shared between the front-end and synthesis. */
typedef struct
{
   int silence;
   int postfilter_pitch;
   float postfilter_gain;
   int postfilter_tapset;
   int isTransient;
   int intra_ener;
   int spread_decision;
   int alloc_trim;
   int intensity, dual_stereo;
   int codedBands;
   int32_t balance;
   int tf_res[ROPUS_NBANDS];
   int cap[ROPUS_NBANDS];
   int offsets[ROPUS_NBANDS];
   int fine_quant[ROPUS_NBANDS];
   int pulses[ROPUS_NBANDS];
   int fine_priority[ROPUS_NBANDS];
   int anti_collapse_rsv;
   int shortBlocks;
   int LM, N, C, CC, effEnd;
} ropus_celt_frame;

/* The bitstream front-end of celt_decode_with_ec: everything up to and
 * including fine energy.  Returns 0 on success. */
static int ropus_celt_front(ropus_celt *st, ropus_ec *dec, int len,
      int frame_size, ropus_celt_frame *f)
{
   int i, c, LM, M, N, spread_decision;
   int32_t total_bits, tell, bits;
   int start = st->start, end = st->end;
   int C = st->stream_channels;
   int dynalloc_logp;

   for (LM = 0; LM <= ROPUS_MAXLM; LM++)
      if (ROPUS_SHORT_MDCT << LM == frame_size)
         break;
   if (LM > ROPUS_MAXLM)
      return -1;
   M = 1 << LM;
   N = M * ROPUS_SHORT_MDCT;

   f->LM = LM;
   f->N = N;
   f->C = C;
   f->CC = st->channels;
   f->effEnd = end;                        /* effEBands == nbEBands     */

   total_bits = len * 8;
   tell = ropus_ec_tell(dec);
   if (tell >= total_bits)
      f->silence = 1;
   else if (tell == 1)
      f->silence = ropus_ec_dec_bit_logp(dec, 15);
   else
      f->silence = 0;
   if (f->silence)
   {
      tell = len * 8;
      dec->nbits_total += tell - ropus_ec_tell(dec);
   }

   f->postfilter_gain = 0;
   f->postfilter_pitch = 0;
   f->postfilter_tapset = 0;
   if (start == 0 && tell + 16 <= total_bits)
   {
      if (ropus_ec_dec_bit_logp(dec, 1))
      {
         int qg, octave;
         octave = (int)ropus_ec_dec_uint(dec, 6);
         f->postfilter_pitch = (16 << octave)
            + (int)ropus_ec_dec_bits(dec, 4 + octave) - 1;
         qg = (int)ropus_ec_dec_bits(dec, 3);
         if (ropus_ec_tell(dec) + 2 <= total_bits)
            f->postfilter_tapset =
               ropus_ec_dec_icdf(dec, ropus_tapset_icdf, 2);
         f->postfilter_gain = .09375f * (qg + 1);
      }
      tell = ropus_ec_tell(dec);
   }

   if (LM > 0 && tell + 3 <= total_bits)
   {
      f->isTransient = ropus_ec_dec_bit_logp(dec, 3);
      tell = ropus_ec_tell(dec);
   }
   else
      f->isTransient = 0;
   f->shortBlocks = f->isTransient ? M : 0;

   f->intra_ener = tell + 3 <= total_bits
      ? ropus_ec_dec_bit_logp(dec, 3) : 0;

   ropus_unquant_coarse_energy(start, end, st->oldEBands,
      f->intra_ener, dec, C, LM);

   ropus_tf_decode(start, end, f->isTransient, f->tf_res, LM, dec);

   tell = ropus_ec_tell(dec);
   spread_decision = 2;                    /* SPREAD_NORMAL             */
   if (tell + 4 <= total_bits)
      spread_decision = ropus_ec_dec_icdf(dec, ropus_spread_icdf, 5);
   f->spread_decision = spread_decision;

   ropus_init_caps(f->cap, LM, C);

   dynalloc_logp = 6;
   total_bits <<= ROPUS_BITRES;
   tell = ropus_ec_tell_frac(dec);
   for (i = start; i < end; i++)
   {
      int width, quanta, dynalloc_loop_logp, boost;
      width = C * (ropus_eband5ms[i + 1] - ropus_eband5ms[i]) << LM;
      quanta = ropus_imin(width << ROPUS_BITRES,
         ropus_imax(6 << ROPUS_BITRES, width));
      dynalloc_loop_logp = dynalloc_logp;
      boost = 0;
      while (tell + (dynalloc_loop_logp << ROPUS_BITRES) < total_bits
            && boost < f->cap[i])
      {
         int flag = ropus_ec_dec_bit_logp(dec, dynalloc_loop_logp);
         tell = ropus_ec_tell_frac(dec);
         if (!flag)
            break;
         boost += quanta;
         total_bits -= quanta;
         dynalloc_loop_logp = 1;
      }
      f->offsets[i] = boost;
      if (boost > 0)
         dynalloc_logp = ropus_imax(2, dynalloc_logp - 1);
   }

   f->alloc_trim = tell + (6 << ROPUS_BITRES) <= total_bits
      ? ropus_ec_dec_icdf(dec, ropus_trim_icdf, 7) : 5;

   bits = (((int32_t)len * 8) << ROPUS_BITRES)
      - (int32_t)ropus_ec_tell_frac(dec) - 1;
   f->anti_collapse_rsv = f->isTransient && LM >= 2
      && bits >= ((LM + 2) << ROPUS_BITRES) ? (1 << ROPUS_BITRES) : 0;
   bits -= f->anti_collapse_rsv;

   f->codedBands = ropus_compute_allocation(start, end, f->offsets,
      f->cap, f->alloc_trim, &f->intensity, &f->dual_stereo, bits,
      &f->balance, f->pulses, f->fine_quant, f->fine_priority, C, LM, dec);

   ropus_unquant_fine_energy(start, end, st->oldEBands,
      f->fine_quant, dec, C);

   (void)c;
   return 0;
}

/* ==================================================================== */
/* Bit-exact trig helpers (celt/mathops.c, bands.c).                    */
/* ==================================================================== */
#define ROPUS_FRAC_MUL16(a, b) \
   ((16384 + ((int32_t)(int16_t)(a) * (int16_t)(b))) >> 15)

static int16_t ropus_bitexact_cos(int16_t x)
{
   int32_t tmp;
   int16_t x2;
   tmp = (4096 + ((int32_t)(x) * (x))) >> 13;
   x2 = tmp;
   x2 = (32767 - x2) + ROPUS_FRAC_MUL16(x2,
      (-7651 + ROPUS_FRAC_MUL16(x2, (8277 + ROPUS_FRAC_MUL16(-626, x2)))));
   return 1 + x2;
}

static int ropus_bitexact_log2tan(int isin, int icos)
{
   int lc = ropus_ec_ilog(icos);
   int ls = ropus_ec_ilog(isin);
   icos <<= 15 - lc;
   isin <<= 15 - ls;
   return (ls - lc) * (1 << 11)
      + ROPUS_FRAC_MUL16(isin, ROPUS_FRAC_MUL16(isin, -2597) + 7932)
      - ROPUS_FRAC_MUL16(icos, ROPUS_FRAC_MUL16(icos, -2597) + 7932);
}

static unsigned ropus_isqrt32(uint32_t val)
{
   unsigned b, g;
   int bshift;
   g = 0;
   bshift = (ropus_ec_ilog(val) - 1) >> 1;
   b = 1u << bshift;
   do
   {
      uint32_t t = (((uint32_t)g << 1) + b) << bshift;
      if (t <= val)
      {
         g += b;
         val -= t;
      }
      b >>= 1;
      bshift--;
   } while (bshift >= 0);
   return g;
}

static INLINE uint32_t ropus_lcg_rand(uint32_t seed)
{
   return 1664525 * seed + 1013904223;
}

/* ==================================================================== */
/* PVQ codeword decode (celt/cwrs.c, non-custom path).                  */
/* ==================================================================== */
#define ROPUS_PVQ_U(n, k) \
   (ropus_pvq_u_row[ropus_imin(n, k)][ropus_imax(n, k)])
#define ROPUS_PVQ_V(n, k) (ROPUS_PVQ_U(n, k) + ROPUS_PVQ_U(n, (k) + 1))

static float ropus_cwrsi(int n, int k, uint32_t i, int *y)
{
   uint32_t p;
   int s, k0;
   int16_t val;
   float yy = 0;
   while (n > 2)
   {
      uint32_t q;
      if (k >= n)
      {
         const uint32_t *row = ropus_pvq_u_row[n];
         p = row[k + 1];
         s = -(i >= p);
         i -= p & s;
         k0 = k;
         q = row[n];
         if (q > i)
         {
            k = n;
            do
               p = ropus_pvq_u_row[--k][n];
            while (p > i);
         }
         else
            for (p = row[k]; p > i; p = row[k])
               k--;
         i -= p;
         val = (k0 - k + s) ^ s;
         *y++ = val;
         yy += (float)val * val;
      }
      else
      {
         p = ropus_pvq_u_row[k][n];
         q = ropus_pvq_u_row[k + 1][n];
         if (p <= i && i < q)
         {
            i -= p;
            *y++ = 0;
         }
         else
         {
            s = -(i >= q);
            i -= q & s;
            k0 = k;
            do
               p = ropus_pvq_u_row[--k][n];
            while (p > i);
            i -= p;
            val = (k0 - k + s) ^ s;
            *y++ = val;
            yy += (float)val * val;
         }
      }
      n--;
   }
   /* n == 2 */
   p = 2 * k + 1;
   s = -(i >= p);
   i -= p & s;
   k0 = k;
   k = (i + 1) >> 1;
   if (k)
      i -= 2 * k - 1;
   val = (k0 - k + s) ^ s;
   *y++ = val;
   yy += (float)val * val;
   /* n == 1 */
   s = -(int)i;
   val = (k + s) ^ s;
   *y = val;
   yy += (float)val * val;
   return yy;
}

static float ropus_decode_pulses(int *y, int n, int k, ropus_ec *dec)
{
   return ropus_cwrsi(n, k, ropus_ec_dec_uint(dec, ROPUS_PVQ_V(n, k)), y);
}

/* ==================================================================== */
/* PVQ vector reconstruction, float pipeline (celt/vq.c).               */
/* ==================================================================== */
static void ropus_normalise_residual(const int *iy, float *X, int N,
      float Ryy, float gain)
{
   int i;
   float g = (1.f / (float)sqrt(Ryy)) * gain;
   i = 0;
#ifdef ROPUS_SSE2
   {
      __m128 gv = _mm_set1_ps(g);
      for (; i + 4 <= N; i += 4)
         _mm_storeu_ps(&X[i], _mm_mul_ps(gv,
            _mm_cvtepi32_ps(_mm_loadu_si128((const __m128i *)&iy[i]))));
   }
   for (; i < N; i++)
      X[i] = g * iy[i];
#elif defined(ROPUS_NEON)
   {
      float32x4_t gv = vdupq_n_f32(g);
      for (; i + 4 <= N; i += 4)
         vst1q_f32(&X[i], vmulq_f32(gv,
            vcvtq_f32_s32(vld1q_s32(&iy[i]))));
   }
   for (; i < N; i++)
      X[i] = g * iy[i];
#else
   do
      X[i] = g * iy[i];
   while (++i < N);
#endif
}

static void ropus_exp_rotation1(float *X, int len, int stride,
      float c, float s)
{
   int i;
   float ms = -s;
   float *Xptr = X;
   for (i = 0; i < len - stride; i++)
   {
      float x1 = Xptr[0];
      float x2 = Xptr[stride];
      Xptr[stride] = c * x2 + s * x1;
      *Xptr++      = c * x1 + ms * x2;
   }
   Xptr = &X[len - 2 * stride - 1];
   for (i = len - 2 * stride - 1; i >= 0; i--)
   {
      float x1 = Xptr[0];
      float x2 = Xptr[stride];
      Xptr[stride] = c * x2 + s * x1;
      *Xptr--      = c * x1 + ms * x2;
   }
}

static void ropus_exp_rotation(float *X, int len, int dir, int stride,
      int K, int spread)
{
   static const int SPREAD_FACTOR[3] = { 15, 10, 5 };
   int i, stride2 = 0, factor;
   float c, s, gain, theta;
   if (2 * K >= len || spread == 0)
      return;
   factor = SPREAD_FACTOR[spread - 1];
   gain = (float)(1.f * len) / (len + factor * K);
   theta = .5f * (gain * gain);
   c = (float)cos((.5f * 3.141592653f) * theta);
   s = (float)cos((.5f * 3.141592653f) * (1.f - theta));
   if (len >= 8 * stride)
   {
      stride2 = 1;
      while ((stride2 * stride2 + stride2) * stride + (stride >> 2) < len)
         stride2++;
   }
   len = (int)((uint32_t)len / stride);
   for (i = 0; i < stride; i++)
   {
      if (dir < 0)
      {
         if (stride2)
            ropus_exp_rotation1(X + i * len, len, stride2, s, c);
         ropus_exp_rotation1(X + i * len, len, 1, c, s);
      }
      else
      {
         ropus_exp_rotation1(X + i * len, len, 1, c, -s);
         if (stride2)
            ropus_exp_rotation1(X + i * len, len, stride2, s, -c);
      }
   }
}

static unsigned ropus_extract_collapse_mask(const int *iy, int N, int B)
{
   unsigned collapse_mask;
   int N0, i;
   if (B <= 1)
      return 1;
   N0 = (int)((uint32_t)N / B);
   collapse_mask = 0;
   i = 0;
   do
   {
      int j;
      unsigned tmp = 0;
      j = 0;
      do
         tmp |= iy[i * N0 + j];
      while (++j < N0);
      collapse_mask |= (tmp != 0) << i;
   } while (++i < B);
   return collapse_mask;
}

static void ropus_renormalise_vector(float *X, int N, float gain)
{
   int i;
   float E = 1e-15f;
   float g, *xptr;
   for (i = 0; i < N; i++)
      E += X[i] * X[i];
   g = (1.f / (float)sqrt(E)) * gain;
   xptr = X;
   for (i = 0; i < N; i++)
   {
      *xptr = g * *xptr;
      xptr++;
   }
}

static unsigned ropus_alg_unquant(float *X, int N, int K, int spread,
      int B, ropus_ec *dec, float gain)
{
   float Ryy;
   unsigned collapse_mask;
   int iy[176];
   Ryy = ropus_decode_pulses(iy, N, K, dec);
   ropus_normalise_residual(iy, X, N, Ryy, gain);
   ropus_exp_rotation(X, N, -1, B, K, spread);
   collapse_mask = ropus_extract_collapse_mask(iy, N, B);
   return collapse_mask;
}

/* ==================================================================== */
/* Band shaping helpers, float pipeline (celt/bands.c).                 */
/* ==================================================================== */
static void ropus_haar1(float *X, int N0, int stride)
{
   int i, j;
   N0 >>= 1;
   for (i = 0; i < stride; i++)
      for (j = 0; j < N0; j++)
      {
         float tmp1 = .70710678f * X[stride * 2 * j + i];
         float tmp2 = .70710678f * X[stride * (2 * j + 1) + i];
         X[stride * 2 * j + i]       = tmp1 + tmp2;
         X[stride * (2 * j + 1) + i] = tmp1 - tmp2;
      }
}

static const int ropus_ordery_table[] =
{
    1,  0,
    3,  0,  2,  1,
    7,  0,  4,  3,  6,  1,  5,  2,
   15,  0,  8,  7, 12,  3, 11,  4, 14,  1,  9,  6, 13,  2, 10,  5,
};

static void ropus_deinterleave_hadamard(float *tmp, float *X, int N0,
      int stride, int hadamard)
{
   int i, j, N = N0 * stride;
   if (hadamard)
   {
      const int *ordery = ropus_ordery_table + stride - 2;
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[ordery[i] * N0 + j] = X[j * stride + i];
   }
   else
   {
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[i * N0 + j] = X[j * stride + i];
   }
   memcpy(X, tmp, N * sizeof(*X));
}

static void ropus_interleave_hadamard(float *tmp, float *X, int N0,
      int stride, int hadamard)
{
   int i, j, N = N0 * stride;
   if (hadamard)
   {
      const int *ordery = ropus_ordery_table + stride - 2;
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[j * stride + i] = X[ordery[i] * N0 + j];
   }
   else
   {
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[j * stride + i] = X[i * N0 + j];
   }
   memcpy(X, tmp, N * sizeof(*X));
}

static void ropus_stereo_merge(float *X, float *Y, float mid, int N)
{
   int j;
   float xp = 0, side = 0;
   float El, Er, mid2, lgain, rgain;
   for (j = 0; j < N; j++)
   {
      xp += Y[j] * X[j];
      side += Y[j] * Y[j];
   }
   xp = mid * xp;
   mid2 = mid;
   El = mid2 * mid2 + side - 2 * xp;
   Er = mid2 * mid2 + side + 2 * xp;
   if (Er < 6e-4f || El < 6e-4f)
   {
      memcpy(Y, X, N * sizeof(*Y));
      return;
   }
   lgain = 1.f / (float)sqrt(El);
   rgain = 1.f / (float)sqrt(Er);
   for (j = 0; j < N; j++)
   {
      float l = mid * X[j];
      float r = Y[j];
      X[j] = lgain * (l - r);
      Y[j] = rgain * (l + r);
   }
}

/* ==================================================================== */
/* Band decode (celt/bands.c decode paths).                             */
/* ==================================================================== */
#define ROPUS_QTHETA_OFFSET          4
#define ROPUS_QTHETA_OFFSET_TWOPHASE 16

typedef struct
{
   ropus_ec *ec;
   int32_t remaining_bits;
   int i;
   int intensity;
   int spread;
   int tf_change;
   uint32_t seed;
   int avoid_split_noise;   /* unused at decode but kept for parity     */
   int disable_inv;
   /* hadamard (de)interleave scratch, N <= 1024: decoder-owned so the
    * 4 KiB float / 2 KiB Q14 tmp is not a quant_band stack frame on
    * 8 KiB thread stacks.  Purely transient within one call, so one
    * buffer serves the whole band recursion.  had_q is int16_t spelled
    * out because the ropus_norm typedef appears later in the file. */
   float   *had_f;
   int16_t *had_q;
} ropus_band_ctx;

typedef struct
{
   int inv, imid, iside, delta, itheta, qalloc;
} ropus_split_ctx;

static int ropus_compute_qn(int N, int b, int offset, int pulse_cap,
      int stereo)
{
   static const int16_t exp2_table8[8] =
      { 16384, 17866, 19483, 21247, 23170, 25267, 27554, 30048 };
   int qn, qb;
   int N2 = 2 * N - 1;
   if (stereo && N == 2)
      N2--;
   qb = (b + N2 * offset) / N2;
   qb = ropus_imin(b - pulse_cap - (4 << ROPUS_BITRES), qb);
   qb = ropus_imin(8 << ROPUS_BITRES, qb);
   if (qb < (1 << ROPUS_BITRES >> 1))
      qn = 1;
   else
   {
      qn = exp2_table8[qb & 0x7] >> (14 - (qb >> ROPUS_BITRES));
      qn = (qn + 1) >> 1 << 1;
   }
   return qn;
}

static void ropus_compute_theta(ropus_band_ctx *ctx, ropus_split_ctx *sctx,
      float *X, float *Y, int N, int *b, int B, int rp_B0, int LM,
      int stereo, int *fill)
{
   int qn, itheta = 0, delta, imid, iside, qalloc;
   int pulse_cap, offset, inv = 0;
   int32_t tell;
   int i = ctx->i;
   int intensity = ctx->intensity;
   ropus_ec *ec = ctx->ec;

   pulse_cap = ropus_logN400[i] + LM * (1 << ROPUS_BITRES);
   offset = (pulse_cap >> 1) - (stereo && N == 2
      ? ROPUS_QTHETA_OFFSET_TWOPHASE : ROPUS_QTHETA_OFFSET);
   qn = ropus_compute_qn(N, *b, offset, pulse_cap, stereo);
   if (stereo && i >= intensity)
      qn = 1;
   tell = ropus_ec_tell_frac(ec);
   if (qn != 1)
   {
      if (stereo && N > 2)
      {
         int p0 = 3;
         int x;
         int x0 = qn / 2;
         int ft = p0 * (x0 + 1) + x0;
         int fs = (int)ropus_ec_decode(ec, ft);
         if (fs < (x0 + 1) * p0)
            x = fs / p0;
         else
            x = x0 + 1 + (fs - (x0 + 1) * p0);
         ropus_ec_dec_update(ec,
            x <= x0 ? p0 * x : (x - 1 - x0) + (x0 + 1) * p0,
            x <= x0 ? p0 * (x + 1) : (x - x0) + (x0 + 1) * p0, ft);
         itheta = x;
      }
      else if (rp_B0 > 1 || stereo)
         itheta = (int)ropus_ec_dec_uint(ec, qn + 1);
      else
      {
         int fs = 1, ft, fl = 0, fm;
         ft = ((qn >> 1) + 1) * ((qn >> 1) + 1);
         fm = (int)ropus_ec_decode(ec, ft);
         if (fm < ((qn >> 1) * ((qn >> 1) + 1) >> 1))
         {
            itheta = (int)((ropus_isqrt32(8 * (uint32_t)fm + 1) - 1) >> 1);
            fs = itheta + 1;
            fl = itheta * (itheta + 1) >> 1;
         }
         else
         {
            itheta = (int)((2 * (qn + 1)
               - ropus_isqrt32(8 * (uint32_t)(ft - fm - 1) + 1)) >> 1);
            fs = qn + 1 - itheta;
            fl = ft - ((qn + 1 - itheta) * (qn + 2 - itheta) >> 1);
         }
         ropus_ec_dec_update(ec, fl, fl + fs, ft);
      }
      itheta = (int)((int32_t)itheta * 16384 / qn);
   }
   else if (stereo)
   {
      if (*b > 2 << ROPUS_BITRES
            && ctx->remaining_bits > 2 << ROPUS_BITRES)
         inv = ropus_ec_dec_bit_logp(ec, 2);
      else
         inv = 0;
      if (ctx->disable_inv)
         inv = 0;
      itheta = 0;
   }
   qalloc = ropus_ec_tell_frac(ec) - tell;
   *b -= qalloc;
   if (itheta == 0)
   {
      imid = 32767;
      iside = 0;
      *fill &= (1 << B) - 1;
      delta = -16384;
   }
   else if (itheta == 16384)
   {
      imid = 0;
      iside = 32767;
      *fill &= ((1 << B) - 1) << B;
      delta = 16384;
   }
   else
   {
      imid = ropus_bitexact_cos((int16_t)itheta);
      iside = ropus_bitexact_cos((int16_t)(16384 - itheta));
      delta = ROPUS_FRAC_MUL16((N - 1) << 7,
         ropus_bitexact_log2tan(iside, imid));
   }
   sctx->inv = inv;
   sctx->imid = imid;
   sctx->iside = iside;
   sctx->delta = delta;
   sctx->itheta = itheta;
   sctx->qalloc = qalloc;
   (void)X;
   (void)Y;
}

static unsigned ropus_quant_band_n1(ropus_band_ctx *ctx, float *X,
      float *Y, float *lowband_out)
{
   int c, stereo;
   float *x = X;
   ropus_ec *ec = ctx->ec;
   stereo = Y != NULL;
   c = 0;
   do
   {
      int sign = 0;
      if (ctx->remaining_bits >= 1 << ROPUS_BITRES)
      {
         sign = (int)ropus_ec_dec_bits(ec, 1);
         ctx->remaining_bits -= 1 << ROPUS_BITRES;
      }
      x[0] = sign ? -1.f : 1.f;
      x = Y;
   } while (++c < 1 + stereo);
   if (lowband_out)
      lowband_out[0] = X[0];
   return 1;
}

static unsigned ropus_quant_partition(ropus_band_ctx *ctx, float *X,
      int N, int b, int B, float *lowband, int LM, float gain, int fill)
{
   const uint8_t *cache;
   int q, curr_bits;
   int imid = 0, iside = 0;
   int rp_B0 = B;
   float mid = 0, side = 0;
   unsigned cm = 0;
   float *Y = NULL;
   int i = ctx->i;
   int spread = ctx->spread;
   ropus_ec *ec = ctx->ec;

   cache = ropus_cache_bits50
      + ropus_cache_index50[(LM + 1) * ROPUS_NBANDS + i];
   if (LM != -1 && b > cache[cache[0]] + 12 && N > 2)
   {
      int mbits, sbits, delta, itheta, qalloc;
      ropus_split_ctx sctx;
      float *next_lowband2 = NULL;
      int32_t rebalance;
      N >>= 1;
      Y = X + N;
      LM -= 1;
      if (B == 1)
         fill = (fill & 1) | (fill << 1);
      B = (B + 1) >> 1;
      ropus_compute_theta(ctx, &sctx, X, Y, N, &b, B, rp_B0, LM, 0, &fill);
      imid = sctx.imid;
      iside = sctx.iside;
      delta = sctx.delta;
      itheta = sctx.itheta;
      qalloc = sctx.qalloc;
      (void)qalloc;
      mid = (1.f / 32768) * imid;
      side = (1.f / 32768) * iside;
      if (rp_B0 > 1 && (itheta & 0x3fff))
      {
         if (itheta > 8192)
            delta -= delta >> (4 - LM);
         else
            delta = ropus_imin(0,
               delta + (N << ROPUS_BITRES >> (5 - LM)));
      }
      mbits = ropus_imax(0, ropus_imin(b, (b - delta) / 2));
      sbits = b - mbits;
      ctx->remaining_bits -= qalloc;
      if (lowband)
         next_lowband2 = lowband + N;
      rebalance = ctx->remaining_bits;
      if (mbits >= sbits)
      {
         cm = ropus_quant_partition(ctx, X, N, mbits, B, lowband, LM,
            gain * mid, fill);
         rebalance = mbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 0)
            sbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_partition(ctx, Y, N, sbits, B, next_lowband2,
            LM, gain * side, fill >> B) << (rp_B0 >> 1);
      }
      else
      {
         cm = ropus_quant_partition(ctx, Y, N, sbits, B, next_lowband2,
            LM, gain * side, fill >> B) << (rp_B0 >> 1);
         rebalance = sbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 16384)
            mbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_partition(ctx, X, N, mbits, B, lowband, LM,
            gain * mid, fill);
      }
   }
   else
   {
      q = ropus_bits2pulses(i, LM, b);
      curr_bits = ropus_pulses2bits(i, LM, q);
      ctx->remaining_bits -= curr_bits;
      while (ctx->remaining_bits < 0 && q > 0)
      {
         ctx->remaining_bits += curr_bits;
         q--;
         curr_bits = ropus_pulses2bits(i, LM, q);
         ctx->remaining_bits -= curr_bits;
      }
      if (q != 0)
      {
         int K = ropus_get_pulses(q);
         cm = ropus_alg_unquant(X, N, K, spread, B, ec, gain);
      }
      else
      {
         int j;
         unsigned cm_mask = (unsigned)(1UL << B) - 1;
         fill &= cm_mask;
         if (!fill)
            memset(X, 0, N * sizeof(*X));
         else
         {
            if (lowband == NULL)
            {
               for (j = 0; j < N; j++)
               {
                  ctx->seed = ropus_lcg_rand(ctx->seed);
                  X[j] = (float)((int32_t)ctx->seed >> 20);
               }
               cm = cm_mask;
            }
            else
            {
               for (j = 0; j < N; j++)
               {
                  float tmp;
                  ctx->seed = ropus_lcg_rand(ctx->seed);
                  tmp = 1.f / 256;
                  tmp = (ctx->seed) & 0x8000 ? tmp : -tmp;
                  X[j] = lowband[j] + tmp;
               }
               cm = fill;
            }
            ropus_renormalise_vector(X, N, gain);
         }
      }
   }
   return cm;
}

static unsigned ropus_quant_band(ropus_band_ctx *ctx, float *X,
      int N, int b, int B, float *lowband, int LM, float *lowband_out,
      float gain, float *lowband_scratch, int fill)
{
   int N0 = N;
   int N_B = N;
   int N_B0;
   int rp_B0 = B;
   int time_divide = 0;
   int recombine = 0;
   int longBlocks;
   unsigned cm = 0;
   int k, tf_change;
   tf_change = ctx->tf_change;
   longBlocks = rp_B0 == 1;
   N_B = (int)((uint32_t)N_B / B);
   if (N == 1)
      return ropus_quant_band_n1(ctx, X, NULL, lowband_out);
   if (tf_change > 0)
      recombine = tf_change;
   if (lowband_scratch && lowband
         && (recombine || ((N_B & 1) == 0 && tf_change < 0) || rp_B0 > 1))
   {
      memcpy(lowband_scratch, lowband, N * sizeof(*lowband));
      lowband = lowband_scratch;
   }
   for (k = 0; k < recombine; k++)
   {
      static const uint8_t bit_interleave_table[16] =
         { 0, 1, 1, 1, 2, 3, 3, 3, 2, 3, 3, 3, 2, 3, 3, 3 };
      if (lowband)
         ropus_haar1(lowband, N >> k, 1 << k);
      fill = bit_interleave_table[fill & 0xF]
         | bit_interleave_table[fill >> 4] << 2;
   }
   B >>= recombine;
   N_B <<= recombine;
   while ((N_B & 1) == 0 && tf_change < 0)
   {
      if (lowband)
         ropus_haar1(lowband, N_B, B);
      fill |= fill << B;
      B <<= 1;
      N_B >>= 1;
      time_divide++;
      tf_change++;
   }
   rp_B0 = B;
   N_B0 = N_B;
   if (rp_B0 > 1 && lowband)
      ropus_deinterleave_hadamard(ctx->had_f, lowband,
         N_B >> recombine, rp_B0 << recombine, longBlocks);

   cm = ropus_quant_partition(ctx, X, N, b, B, lowband, LM, gain, fill);

   /* resynthesis (always on for the decoder) */
   if (rp_B0 > 1)
      ropus_interleave_hadamard(ctx->had_f, X, N_B >> recombine,
         rp_B0 << recombine, longBlocks);
   N_B = N_B0;
   B = rp_B0;
   for (k = 0; k < time_divide; k++)
   {
      B >>= 1;
      N_B <<= 1;
      cm |= cm >> B;
      ropus_haar1(X, N_B, B);
   }
   for (k = 0; k < recombine; k++)
   {
      static const uint8_t bit_deinterleave_table[16] =
      {
         0x00, 0x03, 0x0C, 0x0F, 0x30, 0x33, 0x3C, 0x3F,
         0xC0, 0xC3, 0xCC, 0xCF, 0xF0, 0xF3, 0xFC, 0xFF
      };
      cm = bit_deinterleave_table[cm];
      ropus_haar1(X, N0 >> k, 1 << k);
   }
   B <<= recombine;
   if (lowband_out)
   {
      int j;
      float n = (float)sqrt((float)N0);
      for (j = 0; j < N0; j++)
         lowband_out[j] = n * X[j];
   }
   cm &= (1 << B) - 1;
   return cm;
}

static unsigned ropus_quant_band_stereo(ropus_band_ctx *ctx, float *X,
      float *Y, int N, int b, int B, float *lowband, int LM,
      float *lowband_out, float *lowband_scratch, int fill)
{
   int imid = 0, iside = 0;
   int inv = 0;
   float mid = 0, side = 0;
   unsigned cm = 0;
   int mbits, sbits, delta, itheta, qalloc;
   ropus_split_ctx sctx;
   int orig_fill;
   ropus_ec *ec = ctx->ec;

   if (N == 1)
      return ropus_quant_band_n1(ctx, X, Y, lowband_out);
   orig_fill = fill;
   ropus_compute_theta(ctx, &sctx, X, Y, N, &b, B, B, LM, 1, &fill);
   inv = sctx.inv;
   imid = sctx.imid;
   iside = sctx.iside;
   delta = sctx.delta;
   itheta = sctx.itheta;
   qalloc = sctx.qalloc;
   mid = (1.f / 32768) * imid;
   side = (1.f / 32768) * iside;

   if (N == 2)
   {
      int c, sign = 0;
      float *x2, *y2;
      mbits = b;
      sbits = 0;
      if (itheta != 0 && itheta != 16384)
         sbits = 1 << ROPUS_BITRES;
      mbits -= sbits;
      c = itheta > 8192;
      ctx->remaining_bits -= qalloc + sbits;
      x2 = c ? Y : X;
      y2 = c ? X : Y;
      if (sbits)
         sign = (int)ropus_ec_dec_bits(ec, 1);
      sign = 1 - 2 * sign;
      cm = ropus_quant_band(ctx, x2, N, mbits, B, lowband, LM,
         lowband_out, 1.f, lowband_scratch, orig_fill);
      y2[0] = -sign * x2[1];
      y2[1] = sign * x2[0];
      {
         float tmp;
         X[0] = mid * X[0];
         X[1] = mid * X[1];
         Y[0] = side * Y[0];
         Y[1] = side * Y[1];
         tmp = X[0];
         X[0] = tmp - Y[0];
         Y[0] = tmp + Y[0];
         tmp = X[1];
         X[1] = tmp - Y[1];
         Y[1] = tmp + Y[1];
      }
   }
   else
   {
      int32_t rebalance;
      mbits = ropus_imax(0, ropus_imin(b, (b - delta) / 2));
      sbits = b - mbits;
      ctx->remaining_bits -= qalloc;
      rebalance = ctx->remaining_bits;
      if (mbits >= sbits)
      {
         cm = ropus_quant_band(ctx, X, N, mbits, B, lowband, LM,
            lowband_out, 1.f, lowband_scratch, fill);
         rebalance = mbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 0)
            sbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_band(ctx, Y, N, sbits, B, NULL, LM, NULL,
            side, NULL, fill >> B);
      }
      else
      {
         cm = ropus_quant_band(ctx, Y, N, sbits, B, NULL, LM, NULL,
            side, NULL, fill >> B);
         rebalance = sbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 16384)
            mbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_band(ctx, X, N, mbits, B, lowband, LM,
            lowband_out, 1.f, lowband_scratch, fill);
      }
   }
   if (N != 2)
      ropus_stereo_merge(X, Y, mid, N);
   if (inv)
   {
      int j;
      for (j = 0; j < N; j++)
         Y[j] = -Y[j];
   }
   return cm;
}

static void ropus_special_hybrid_folding(float *norm, float *norm2,
      int start, int M, int dual_stereo)
{
   int n1, n2;
   const int16_t *eBands = ropus_eband5ms;
   n1 = M * (eBands[start + 1] - eBands[start]);
   n2 = M * (eBands[start + 2] - eBands[start + 1]);
   memmove(&norm[n1], &norm[2 * n1 - n2], (n2 - n1) * sizeof(*norm));
   if (dual_stereo)
      memmove(&norm2[n1], &norm2[2 * n1 - n2], (n2 - n1) * sizeof(*norm2));
}

/* quant_all_bands, decode specialization (encode=0, resynth=1).
 * X_ and Y_ are the per-channel normalized spectra (M*eBands[end] each).
 * _norm needs C * (M*eBands[nbEBands-1] - norm_offset) floats; caller
 * provides a buffer big enough for the worst case.                     */
static void ropus_quant_all_bands(int start, int end, float *X_, float *Y_,
      uint8_t *collapse_masks, const int *pulses, int shortBlocks,
      int spread, int dual_stereo, int intensity, const int *tf_res,
      int32_t total_bits, int32_t balance, ropus_ec *ec, int LM,
      int codedBands, uint32_t *seed, int disable_inv, float *_norm,
      float *_had)
{
   int i;
   int32_t remaining_bits;
   const int16_t *eBands = ropus_eband5ms;
   float *norm, *norm2;
   float *lowband_scratch;
   int B, M, lowband_offset;
   int update_lowband = 1;
   int C = Y_ != NULL ? 2 : 1;
   int norm_offset;
   ropus_band_ctx ctx;

   M = 1 << LM;
   B = shortBlocks ? M : 1;
   norm_offset = M * eBands[start];
   norm = _norm;
   norm2 = norm + M * eBands[ROPUS_NBANDS - 1] - norm_offset;
   /* decode: use the last band of X_ as scratch (libopus trick) */
   lowband_scratch = X_ + M * eBands[ROPUS_NBANDS - 1];

   lowband_offset = 0;
   ctx.ec = ec;
   ctx.intensity = intensity;
   ctx.seed = *seed;
   ctx.spread = spread;
   ctx.disable_inv = disable_inv;
   ctx.had_f = _had;
   ctx.had_q = NULL;
   ctx.avoid_split_noise = B > 1;
   for (i = start; i < end; i++)
   {
      int32_t tell;
      int b, N;
      int32_t curr_balance;
      int effective_lowband = -1;
      float *X, *Y;
      int tf_change = 0;
      unsigned x_cm, y_cm;
      int last;

      ctx.i = i;
      last = (i == end - 1);
      X = X_ + M * eBands[i];
      if (Y_ != NULL)
         Y = Y_ + M * eBands[i];
      else
         Y = NULL;
      N = M * eBands[i + 1] - M * eBands[i];
      tell = (int32_t)ropus_ec_tell_frac(ec);
      if (i != start)
         balance -= tell;
      remaining_bits = total_bits - tell - 1;
      ctx.remaining_bits = remaining_bits;
      if (i <= codedBands - 1)
      {
         curr_balance = balance / ropus_imin(3, codedBands - i);
         b = ropus_imax(0, ropus_imin(16383,
            ropus_imin(remaining_bits + 1, pulses[i] + curr_balance)));
      }
      else
         b = 0;

      if ((M * eBands[i] - N >= M * eBands[start] || i == start + 1)
            && (update_lowband || lowband_offset == 0))
         lowband_offset = i;
      if (i == start + 1)
         ropus_special_hybrid_folding(norm, norm2, start, M, dual_stereo);

      tf_change = tf_res[i];
      ctx.tf_change = tf_change;
      if (last)
         lowband_scratch = NULL;

      if (lowband_offset != 0
            && (spread != 3 || B > 1 || tf_change < 0))
      {
         int fold_start, fold_end, fold_i;
         effective_lowband = ropus_imax(0,
            M * eBands[lowband_offset] - norm_offset - N);
         fold_start = lowband_offset;
         while (M * eBands[--fold_start] > effective_lowband + norm_offset)
            ;
         fold_end = lowband_offset - 1;
         while (++fold_end < i
               && M * eBands[fold_end] < effective_lowband + norm_offset + N)
            ;
         x_cm = y_cm = 0;
         fold_i = fold_start;
         do
         {
            x_cm |= collapse_masks[fold_i * C + 0];
            y_cm |= collapse_masks[fold_i * C + C - 1];
         } while (++fold_i < fold_end);
      }
      else
         x_cm = y_cm = (1 << B) - 1;

      if (dual_stereo && i == intensity)
      {
         int j;
         dual_stereo = 0;
         for (j = 0; j < M * eBands[i] - norm_offset; j++)
            norm[j] = .5f * (norm[j] + norm2[j]);
      }
      if (dual_stereo)
      {
         x_cm = ropus_quant_band(&ctx, X, N, b / 2, B,
            effective_lowband != -1 ? norm + effective_lowband : NULL, LM,
            last ? NULL : norm + M * eBands[i] - norm_offset, 1.f,
            lowband_scratch, x_cm);
         y_cm = ropus_quant_band(&ctx, Y, N, b / 2, B,
            effective_lowband != -1 ? norm2 + effective_lowband : NULL, LM,
            last ? NULL : norm2 + M * eBands[i] - norm_offset, 1.f,
            lowband_scratch, y_cm);
      }
      else
      {
         if (Y != NULL)
            x_cm = ropus_quant_band_stereo(&ctx, X, Y, N, b, B,
               effective_lowband != -1 ? norm + effective_lowband : NULL,
               LM, last ? NULL : norm + M * eBands[i] - norm_offset,
               lowband_scratch, x_cm | y_cm);
         else
            x_cm = ropus_quant_band(&ctx, X, N, b, B,
               effective_lowband != -1 ? norm + effective_lowband : NULL,
               LM, last ? NULL : norm + M * eBands[i] - norm_offset, 1.f,
               lowband_scratch, x_cm | y_cm);
         y_cm = x_cm;
      }
      collapse_masks[i * C + 0] = (uint8_t)x_cm;
      collapse_masks[i * C + C - 1] = (uint8_t)y_cm;
      balance += pulses[i] + tell;
      update_lowband = b > (N << ROPUS_BITRES);
      ctx.avoid_split_noise = 0;
   }
   *seed = ctx.seed;
}

/* ==================================================================== */
/* Synthesis, float pipeline.                                           */
/* ==================================================================== */
#define ROPUS_CELT_SIG_SCALE 32768.f
#define ROPUS_VERY_SMALL 1e-30f
#define ROPUS_PREEMPH_COEF0 0.85000610f

static INLINE float ropus_exp2f(float x)
{
   return (float)exp(0.6931471805599453094 * (x));
}

static const float ropus_e_means[25] =
{
   6.437500f, 6.250000f, 5.750000f, 5.312500f, 5.062500f,
   4.812500f, 4.500000f, 4.375000f, 4.875000f, 4.687500f,
   4.562500f, 4.437500f, 4.875000f, 4.625000f, 4.312500f,
   4.500000f, 4.375000f, 4.625000f, 4.750000f, 4.437500f,
   3.750000f, 3.750000f, 3.750000f, 3.750000f, 3.750000f
};

static void ropus_denormalise_bands(const float *X, float *freq,
      const float *bandLogE, int start, int end, int M, int silence)
{
   int i, N, bound;
   float *f;
   const float *x;
   const int16_t *eBands = ropus_eband5ms;
   N = M * ROPUS_SHORT_MDCT;
   bound = M * eBands[end];
   if (silence)
   {
      bound = 0;
      start = end = 0;
   }
   f = freq;
   x = X + M * eBands[start];
   for (i = 0; i < M * eBands[start]; i++)
      *f++ = 0;
   for (i = start; i < end; i++)
   {
      int j, band_end;
      float g, lg;
      j = M * eBands[i];
      band_end = M * eBands[i + 1];
      lg = bandLogE[i] + ropus_e_means[i];
      g = ropus_exp2f(ropus_minf(32.f, lg));
#ifdef ROPUS_SSE2
      {
         __m128 gv = _mm_set1_ps(g);
         for (; j + 4 <= band_end; j += 4)
         {
            _mm_storeu_ps(f, _mm_mul_ps(_mm_loadu_ps(x), gv));
            f += 4;
            x += 4;
         }
      }
      for (; j < band_end; j++)
         *f++ = *x++ * g;
#elif defined(ROPUS_NEON)
      {
         float32x4_t gv = vdupq_n_f32(g);
         for (; j + 4 <= band_end; j += 4)
         {
            vst1q_f32(f, vmulq_f32(vld1q_f32(x), gv));
            f += 4;
            x += 4;
         }
      }
      for (; j < band_end; j++)
         *f++ = *x++ * g;
#else
      do
         *f++ = *x++ * g;
      while (++j < band_end);
#endif
   }
   memset(&freq[bound], 0, (N - bound) * sizeof(*freq));
}

static void ropus_anti_collapse(float *X_, const uint8_t *collapse_masks,
      int LM, int C, int size, int start, int end, const float *logE,
      const float *prev1logE, const float *prev2logE, const int *pulses,
      uint32_t seed)
{
   int c, i, j, k;
   for (i = start; i < end; i++)
   {
      int N0, depth;
      float thresh, sqrt_1;
      N0 = ropus_eband5ms[i + 1] - ropus_eband5ms[i];
      depth = (int)((uint32_t)(1 + pulses[i])
         / (ropus_eband5ms[i + 1] - ropus_eband5ms[i])) >> LM;
      thresh = .5f * ropus_exp2f(-.125f * depth);
      sqrt_1 = 1.f / (float)sqrt((float)(N0 << LM));
      c = 0;
      do
      {
         float *X;
         float prev1, prev2, Ediff, r;
         int renormalize = 0;
         prev1 = prev1logE[c * ROPUS_NBANDS + i];
         prev2 = prev2logE[c * ROPUS_NBANDS + i];
         if (C == 1)
         {
            prev1 = ropus_maxf(prev1, prev1logE[ROPUS_NBANDS + i]);
            prev2 = ropus_maxf(prev2, prev2logE[ROPUS_NBANDS + i]);
         }
         Ediff = logE[c * ROPUS_NBANDS + i] - ropus_minf(prev1, prev2);
         Ediff = ropus_maxf(0, Ediff);
         r = 2.f * ropus_exp2f(-Ediff);
         if (LM == 3)
            r *= 1.41421356f;
         r = ropus_minf(thresh, r);
         r = r * sqrt_1;
         X = X_ + c * size + (ropus_eband5ms[i] << LM);
         for (k = 0; k < 1 << LM; k++)
         {
            if (!(collapse_masks[i * C + c] & 1 << k))
            {
               for (j = 0; j < N0; j++)
               {
                  seed = ropus_lcg_rand(seed);
                  X[(j << LM) + k] = (seed & 0x8000 ? r : -r);
               }
               renormalize = 1;
            }
         }
         if (renormalize)
            ropus_renormalise_vector(X, N0 << LM, 1.f);
      } while (++c < C);
   }
}

/* kiss FFT, float, radix 2/3/4/5 (celt/kiss_fft.c forward transform,
 * used as an IFFT by swapping re/im in the MDCT wrapper).              */
#define ROPUS_C_MUL(m, a, b) \
   do { (m).r = (a).r * (b).r - (a).i * (b).i; \
        (m).i = (a).r * (b).i + (a).i * (b).r; } while (0)
#define ROPUS_C_ADD(res, a, b) \
   do { (res).r = (a).r + (b).r; (res).i = (a).i + (b).i; } while (0)
#define ROPUS_C_SUB(res, a, b) \
   do { (res).r = (a).r - (b).r; (res).i = (a).i - (b).i; } while (0)
#define ROPUS_C_ADDTO(res, a) \
   do { (res).r += (a).r; (res).i += (a).i; } while (0)
#define ROPUS_C_MULBYSCALAR(c, s) \
   do { (c).r *= (s); (c).i *= (s); } while (0)

typedef struct
{
   int nfft;
   int shift;               /* twiddle stride log2 (0 for the 480 fft)  */
   const int16_t *factors;
   const int16_t *bitrev;
} ropus_fft_state;

static const ropus_fft_state ropus_fft_states[4] =
{
   { 480, 0, ropus_fft_factors480, ropus_fft_bitrev480 },
   { 240, 1, ropus_fft_factors240, ropus_fft_bitrev240 },
   { 120, 2, ropus_fft_factors120, ropus_fft_bitrev120 },
   {  60, 3, ropus_fft_factors60,  ropus_fft_bitrev60  },
};


#ifdef ROPUS_SSE2
/* Two interleaved complexes per __m128: (r0, i0, r1, i1).
 * ropus_mm_cmul performs the scalar ROPUS_C_MUL per lane pair:
 *   m.r = a.r*b.r - a.i*b.i;  m.i = a.r*b.i + a.i*b.r
 * using a + (-x) for the subtraction, which is IEEE-exact. */
static INLINE __m128 ropus_mm_cmul(__m128 a, __m128 b)
{
   const __m128 signri = _mm_castsi128_ps(
      _mm_set_epi32(0, (int)0x80000000, 0, (int)0x80000000));
   __m128 brr = _mm_shuffle_ps(b, b, _MM_SHUFFLE(2, 2, 0, 0));
   __m128 bii = _mm_shuffle_ps(b, b, _MM_SHUFFLE(3, 3, 1, 1));
   __m128 air = _mm_shuffle_ps(a, a, _MM_SHUFFLE(2, 3, 0, 1));
   __m128 m1 = _mm_mul_ps(a, brr);
   __m128 m2 = _mm_mul_ps(air, bii);
   return _mm_add_ps(m1, _mm_xor_ps(m2, signri));
}

/* Load complexes t[0*step] and t[1*step] into one vector. */
static INLINE __m128 ropus_mm_ld2c(const ropus_cpx *t, size_t step)
{
   /* 64-bit lane loads through __m128i, whose gcc/clang definition
    * carries may_alias; loading through a plain double* would violate
    * strict aliasing (the storage is float). */
   __m128i lo = _mm_loadl_epi64((const __m128i *)t);
   __m128i hi = _mm_loadl_epi64((const __m128i *)(t + step));
   return _mm_castsi128_ps(_mm_unpacklo_epi64(lo, hi));
}

/* (r, i) -> (i, r) per complex lane. */
#define ROPUS_MM_SWAPRI(x) _mm_shuffle_ps(x, x, _MM_SHUFFLE(2, 3, 0, 1))
#endif

#ifdef ROPUS_NEON
/* NEON mirrors of the SSE2 helpers; same layout (two interleaved
 * complexes per float32x4_t) and the same per-lane IEEE operation
 * order, so the results stay bit-identical to the scalar code.
 * vmulq/vaddq/vsubq are used explicitly -- never vfmaq -- to avoid
 * fused multiply-add changing the rounding. */
static INLINE float32x4_t ropus_vq_xor(float32x4_t x, uint32x4_t m)
{
   return vreinterpretq_f32_u32(veorq_u32(vreinterpretq_u32_f32(x), m));
}

#define ROPUS_VQ_SWAPRI(x) vrev64q_f32(x)

/* Full four-lane reversal: (a,b,c,d) -> (d,c,b,a). */
static INLINE float32x4_t ropus_vq_rev4(float32x4_t x)
{
   float32x4_t r = vrev64q_f32(x);
   return vcombine_f32(vget_high_f32(r), vget_low_f32(r));
}

static INLINE float32x4_t ropus_vq_cmul(float32x4_t a, float32x4_t b)
{
   const uint32x4_t signri =
      { 0x80000000u, 0, 0x80000000u, 0 };
   float32x4_t brr = vtrn1q_f32(b, b);      /* (br0,br0,br1,br1)       */
   float32x4_t bii = vtrn2q_f32(b, b);      /* (bi0,bi0,bi1,bi1)       */
   float32x4_t air = vrev64q_f32(a);        /* (ai0,ar0,ai1,ar1)       */
   float32x4_t m1 = vmulq_f32(a, brr);
   float32x4_t m2 = vmulq_f32(air, bii);
   return vaddq_f32(m1, ropus_vq_xor(m2, signri));
}

static INLINE float32x4_t ropus_vq_ld2c(const ropus_cpx *t, size_t step)
{
   return vcombine_f32(vld1_f32(&t->r), vld1_f32(&t[step].r));
}
#endif

static void ropus_kf_bfly2(ropus_cpx *Fout, int m, int N)
{
   ropus_cpx *Fout2;
   int i;
   float tw = 0.7071067812f;
   (void)m;
#ifdef ROPUS_SSE2
   {
      /* Twiddle application per group of eight complexes.  Each lane
       * reproduces the scalar expression exactly: subtraction is done
       * as a + (-b) via sign-mask XOR (IEEE-exact), and the negated
       * sum -(x + y) is computed as (-x) + (-y), which is likewise
       * bit-identical. */
      const __m128 twv = _mm_set1_ps(tw);
      const __m128 m3 = _mm_castsi128_ps(_mm_set_epi32(
         (int)0x80000000, 0, 0, 0));               /* flip lane 3      */
      const __m128 m1_ = _mm_castsi128_ps(_mm_set_epi32(
         0, 0, (int)0x80000000, 0));               /* flip lane 1      */
      const __m128 m13 = _mm_castsi128_ps(_mm_set_epi32(
         (int)0x80000000, 0, (int)0x80000000, 0)); /* flip lanes 1,3   */
      const __m128 m23 = _mm_castsi128_ps(_mm_set_epi32(
         (int)0x80000000, (int)0x80000000, 0, 0)); /* flip lanes 2,3   */
      for (i = 0; i < N; i++)
      {
         __m128 f01, f23, g01, g23, gs, ga, t01, t23;
         Fout2 = Fout + 4;
         f01 = _mm_loadu_ps(&Fout[0].r);
         f23 = _mm_loadu_ps(&Fout[2].r);
         g01 = _mm_loadu_ps(&Fout2[0].r);
         g23 = _mm_loadu_ps(&Fout2[2].r);
         /* t0 = G0; t1 = ((G1.r+G1.i)*tw, (G1.i-G1.r)*tw)             */
         gs = ROPUS_MM_SWAPRI(g01);
         ga = _mm_mul_ps(_mm_add_ps(g01, _mm_xor_ps(gs, m13)), twv);
         t01 = _mm_movelh_ps(g01, _mm_movehl_ps(ga, ga));
         /* t2 = (G2.i, -G2.r);
          * t3 = ((G3.i-G3.r)*tw, (-(G3.i)-(G3.r))*tw)                 */
         gs = ROPUS_MM_SWAPRI(g23);
         ga = _mm_mul_ps(_mm_add_ps(_mm_xor_ps(gs, m3),
            _mm_xor_ps(g23, m23)), twv);
         t23 = _mm_movelh_ps(_mm_xor_ps(gs, m1_),
            _mm_movehl_ps(ga, ga));
         _mm_storeu_ps(&Fout2[0].r, _mm_sub_ps(f01, t01));
         _mm_storeu_ps(&Fout[0].r, _mm_add_ps(f01, t01));
         _mm_storeu_ps(&Fout2[2].r, _mm_sub_ps(f23, t23));
         _mm_storeu_ps(&Fout[2].r, _mm_add_ps(f23, t23));
         Fout += 8;
      }
   }
#elif defined(ROPUS_NEON)
   {
      const float32x4_t twv = vdupq_n_f32(tw);
      const uint32x4_t m3 = { 0, 0, 0, 0x80000000u };
      const uint32x4_t m1_ = { 0, 0x80000000u, 0, 0 };
      const uint32x4_t m13 = { 0, 0x80000000u, 0, 0x80000000u };
      const uint32x4_t m23 = { 0, 0, 0x80000000u, 0x80000000u };
      for (i = 0; i < N; i++)
      {
         float32x4_t f01, f23, g01, g23, gs, ga, t01, t23;
         Fout2 = Fout + 4;
         f01 = vld1q_f32(&Fout[0].r);
         f23 = vld1q_f32(&Fout[2].r);
         g01 = vld1q_f32(&Fout2[0].r);
         g23 = vld1q_f32(&Fout2[2].r);
         gs = ROPUS_VQ_SWAPRI(g01);
         ga = vmulq_f32(vaddq_f32(g01, ropus_vq_xor(gs, m13)), twv);
         t01 = vcombine_f32(vget_low_f32(g01), vget_high_f32(ga));
         gs = ROPUS_VQ_SWAPRI(g23);
         ga = vmulq_f32(vaddq_f32(ropus_vq_xor(gs, m3),
            ropus_vq_xor(g23, m23)), twv);
         t23 = vcombine_f32(vget_low_f32(ropus_vq_xor(gs, m1_)),
            vget_high_f32(ga));
         vst1q_f32(&Fout2[0].r, vsubq_f32(f01, t01));
         vst1q_f32(&Fout[0].r, vaddq_f32(f01, t01));
         vst1q_f32(&Fout2[2].r, vsubq_f32(f23, t23));
         vst1q_f32(&Fout[2].r, vaddq_f32(f23, t23));
         Fout += 8;
      }
   }
#else
   for (i = 0; i < N; i++)
   {
      ropus_cpx t;
      Fout2 = Fout + 4;
      t = Fout2[0];
      ROPUS_C_SUB(Fout2[0], Fout[0], t);
      ROPUS_C_ADDTO(Fout[0], t);
      t.r = (Fout2[1].r + Fout2[1].i) * tw;
      t.i = (Fout2[1].i - Fout2[1].r) * tw;
      ROPUS_C_SUB(Fout2[1], Fout[1], t);
      ROPUS_C_ADDTO(Fout[1], t);
      t.r = Fout2[2].i;
      t.i = -Fout2[2].r;
      ROPUS_C_SUB(Fout2[2], Fout[2], t);
      ROPUS_C_ADDTO(Fout[2], t);
      t.r = (Fout2[3].i - Fout2[3].r) * tw;
      t.i = -(Fout2[3].i + Fout2[3].r) * tw;
      ROPUS_C_SUB(Fout2[3], Fout[3], t);
      ROPUS_C_ADDTO(Fout[3], t);
      Fout += 8;
   }
#endif
}

static void ropus_kf_bfly4(ropus_cpx *Fout, size_t fstride,
      const ropus_fft_state *st, int m, int N, int mm)
{
   int i;
   if (m == 1)
   {
#ifdef ROPUS_SSE2
      const __m128 sri = _mm_castsi128_ps(
         _mm_set_epi32(0, (int)0x80000000, 0, (int)0x80000000));
      const __m128 sir = _mm_castsi128_ps(
         _mm_set_epi32((int)0x80000000, 0, (int)0x80000000, 0));
      for (i = 0; i < N; i++)
      {
         /* Lane pairs: v01 = (F0, F1), v23 = (F2, F3).  The vector ops
          * mirror the scalar butterfly per element exactly. */
         __m128 v01 = _mm_loadu_ps(&Fout[0].r);
         __m128 v23 = _mm_loadu_ps(&Fout[2].r);
         __m128 sub = _mm_sub_ps(v01, v23);   /* (F0-F2, F1-F3)        */
         __m128 add = _mm_add_ps(v01, v23);   /* (F0+F2, F1+F3)        */
         __m128 s1a = _mm_movehl_ps(add, add);/* (F1+F3, F1+F3)        */
         __m128 f0n = _mm_add_ps(add, s1a);   /* lanes 0,1: new F0     */
         __m128 f2n = _mm_sub_ps(add, s1a);   /* lanes 0,1: new F2     */
         __m128 s1b = _mm_movehl_ps(sub, sub);/* (F1-F3, F1-F3)        */
         __m128 s1s = ROPUS_MM_SWAPRI(s1b);   /* (i, r) of F1-F3       */
         /* F1 = s0 + ( s1.i, -s1.r); F3 = s0 + (-s1.i,  s1.r) */
         __m128 f1n = _mm_add_ps(sub, _mm_xor_ps(s1s, sir));
         __m128 f3n = _mm_add_ps(sub, _mm_xor_ps(s1s, sri));
         _mm_storeu_ps(&Fout[0].r, _mm_movelh_ps(f0n, f1n));
         _mm_storeu_ps(&Fout[2].r, _mm_movelh_ps(f2n, f3n));
         Fout += 4;
      }
#elif defined(ROPUS_NEON)
      const uint32x4_t sri = { 0x80000000u, 0, 0x80000000u, 0 };
      const uint32x4_t sir = { 0, 0x80000000u, 0, 0x80000000u };
      for (i = 0; i < N; i++)
      {
         float32x4_t v01 = vld1q_f32(&Fout[0].r);
         float32x4_t v23 = vld1q_f32(&Fout[2].r);
         float32x4_t sub = vsubq_f32(v01, v23);
         float32x4_t add = vaddq_f32(v01, v23);
         float32x2_t s1a = vget_high_f32(add);
         float32x2_t f0n = vadd_f32(vget_low_f32(add), s1a);
         float32x2_t f2n = vsub_f32(vget_low_f32(add), s1a);
         float32x4_t s1s4 = vrev64q_f32(sub);   /* swap r/i per pair   */
         float32x2_t s0 = vget_low_f32(sub);
         float32x2_t s1s = vget_high_f32(s1s4);
         float32x2_t f1n = vadd_f32(s0, vreinterpret_f32_u32(veor_u32(
            vreinterpret_u32_f32(s1s), vget_low_u32(sir))));
         float32x2_t f3n = vadd_f32(s0, vreinterpret_f32_u32(veor_u32(
            vreinterpret_u32_f32(s1s), vget_low_u32(sri))));
         vst1q_f32(&Fout[0].r, vcombine_f32(f0n, f1n));
         vst1q_f32(&Fout[2].r, vcombine_f32(f2n, f3n));
         Fout += 4;
      }
#else
      for (i = 0; i < N; i++)
      {
         ropus_cpx scratch0, scratch1;
         ROPUS_C_SUB(scratch0, *Fout, Fout[2]);
         ROPUS_C_ADDTO(*Fout, Fout[2]);
         ROPUS_C_ADD(scratch1, Fout[1], Fout[3]);
         ROPUS_C_SUB(Fout[2], *Fout, scratch1);
         ROPUS_C_ADDTO(*Fout, scratch1);
         ROPUS_C_SUB(scratch1, Fout[1], Fout[3]);
         Fout[1].r = scratch0.r + scratch1.i;
         Fout[1].i = scratch0.i - scratch1.r;
         Fout[3].r = scratch0.r - scratch1.i;
         Fout[3].i = scratch0.i + scratch1.r;
         Fout += 4;
      }
#endif
   }
   else
   {
      int j;
      ropus_cpx scratch[6];
      const ropus_cpx *tw1, *tw2, *tw3;
      const int m2 = 2 * m;
      const int m3 = 3 * m;
      ropus_cpx *Fout_beg = Fout;
      for (i = 0; i < N; i++)
      {
         Fout = Fout_beg + i * mm;
         tw3 = tw2 = tw1 = ropus_fft_twiddles;
         j = 0;
#ifdef ROPUS_SSE2
         {
            const __m128 sri = _mm_castsi128_ps(_mm_set_epi32(
               0, (int)0x80000000, 0, (int)0x80000000));
            const __m128 sir = _mm_castsi128_ps(_mm_set_epi32(
               (int)0x80000000, 0, (int)0x80000000, 0));
            for (; j + 2 <= m; j += 2)
            {
               __m128 f0 = _mm_loadu_ps(&Fout[0].r);
               __m128 s0 = ropus_mm_cmul(_mm_loadu_ps(&Fout[m].r),
                  ropus_mm_ld2c(tw1, fstride));
               __m128 s1 = ropus_mm_cmul(_mm_loadu_ps(&Fout[m2].r),
                  ropus_mm_ld2c(tw2, fstride * 2));
               __m128 s2 = ropus_mm_cmul(_mm_loadu_ps(&Fout[m3].r),
                  ropus_mm_ld2c(tw3, fstride * 3));
               __m128 s5 = _mm_sub_ps(f0, s1);
               __m128 s3, s4, s4s;
               f0 = _mm_add_ps(f0, s1);
               s3 = _mm_add_ps(s0, s2);
               s4 = _mm_sub_ps(s0, s2);
               _mm_storeu_ps(&Fout[m2].r, _mm_sub_ps(f0, s3));
               _mm_storeu_ps(&Fout[0].r, _mm_add_ps(f0, s3));
               s4s = ROPUS_MM_SWAPRI(s4);
               _mm_storeu_ps(&Fout[m].r,
                  _mm_add_ps(s5, _mm_xor_ps(s4s, sir)));
               _mm_storeu_ps(&Fout[m3].r,
                  _mm_add_ps(s5, _mm_xor_ps(s4s, sri)));
               tw1 += fstride * 2;
               tw2 += fstride * 4;
               tw3 += fstride * 6;
               Fout += 2;
            }
         }
#elif defined(ROPUS_NEON)
         {
            const uint32x4_t sri = { 0x80000000u, 0, 0x80000000u, 0 };
            const uint32x4_t sir = { 0, 0x80000000u, 0, 0x80000000u };
            for (; j + 2 <= m; j += 2)
            {
               float32x4_t f0 = vld1q_f32(&Fout[0].r);
               float32x4_t s0 = ropus_vq_cmul(vld1q_f32(&Fout[m].r),
                  ropus_vq_ld2c(tw1, fstride));
               float32x4_t s1 = ropus_vq_cmul(vld1q_f32(&Fout[m2].r),
                  ropus_vq_ld2c(tw2, fstride * 2));
               float32x4_t s2 = ropus_vq_cmul(vld1q_f32(&Fout[m3].r),
                  ropus_vq_ld2c(tw3, fstride * 3));
               float32x4_t s5 = vsubq_f32(f0, s1);
               float32x4_t s3, s4, s4s;
               f0 = vaddq_f32(f0, s1);
               s3 = vaddq_f32(s0, s2);
               s4 = vsubq_f32(s0, s2);
               vst1q_f32(&Fout[m2].r, vsubq_f32(f0, s3));
               vst1q_f32(&Fout[0].r, vaddq_f32(f0, s3));
               s4s = ROPUS_VQ_SWAPRI(s4);
               vst1q_f32(&Fout[m].r,
                  vaddq_f32(s5, ropus_vq_xor(s4s, sir)));
               vst1q_f32(&Fout[m3].r,
                  vaddq_f32(s5, ropus_vq_xor(s4s, sri)));
               tw1 += fstride * 2;
               tw2 += fstride * 4;
               tw3 += fstride * 6;
               Fout += 2;
            }
         }
#endif
         for (; j < m; j++)
         {
            ROPUS_C_MUL(scratch[0], Fout[m], *tw1);
            ROPUS_C_MUL(scratch[1], Fout[m2], *tw2);
            ROPUS_C_MUL(scratch[2], Fout[m3], *tw3);
            ROPUS_C_SUB(scratch[5], *Fout, scratch[1]);
            ROPUS_C_ADDTO(*Fout, scratch[1]);
            ROPUS_C_ADD(scratch[3], scratch[0], scratch[2]);
            ROPUS_C_SUB(scratch[4], scratch[0], scratch[2]);
            ROPUS_C_SUB(Fout[m2], *Fout, scratch[3]);
            tw1 += fstride;
            tw2 += fstride * 2;
            tw3 += fstride * 3;
            ROPUS_C_ADDTO(*Fout, scratch[3]);
            Fout[m].r = scratch[5].r + scratch[4].i;
            Fout[m].i = scratch[5].i - scratch[4].r;
            Fout[m3].r = scratch[5].r - scratch[4].i;
            Fout[m3].i = scratch[5].i + scratch[4].r;
            ++Fout;
         }
      }
   }
   (void)st;
}

static void ropus_kf_bfly3(ropus_cpx *Fout, size_t fstride,
      const ropus_fft_state *st, int m, int N, int mm)
{
   int i;
   size_t k;
   const size_t m2 = 2 * m;
   const ropus_cpx *tw1, *tw2;
   ropus_cpx scratch[5];
   ropus_cpx epi3;
   ropus_cpx *Fout_beg = Fout;
   epi3 = ropus_fft_twiddles[fstride * m];
   for (i = 0; i < N; i++)
   {
      Fout = Fout_beg + i * mm;
      tw1 = tw2 = ropus_fft_twiddles;
      k = m;
#ifdef ROPUS_SSE2
      {
         const __m128 half = _mm_set1_ps(.5f);
         const __m128 e3i = _mm_set1_ps(epi3.i);
         const __m128 sri = _mm_castsi128_ps(_mm_set_epi32(
            0, (int)0x80000000, 0, (int)0x80000000));
         const __m128 sir = _mm_castsi128_ps(_mm_set_epi32(
            (int)0x80000000, 0, (int)0x80000000, 0));
         for (; k >= 2; k -= 2)
         {
            __m128 f0 = _mm_loadu_ps(&Fout[0].r);
            __m128 s1 = ropus_mm_cmul(_mm_loadu_ps(&Fout[m].r),
               ropus_mm_ld2c(tw1, fstride));
            __m128 s2 = ropus_mm_cmul(_mm_loadu_ps(&Fout[m2].r),
               ropus_mm_ld2c(tw2, fstride * 2));
            __m128 s3 = _mm_add_ps(s1, s2);
            __m128 s0 = _mm_sub_ps(s1, s2);
            __m128 fm, s0s;
            fm = _mm_sub_ps(f0, _mm_mul_ps(half, s3));
            s0 = _mm_mul_ps(s0, e3i);
            _mm_storeu_ps(&Fout[0].r, _mm_add_ps(f0, s3));
            s0s = ROPUS_MM_SWAPRI(s0);
            _mm_storeu_ps(&Fout[m2].r,
               _mm_add_ps(fm, _mm_xor_ps(s0s, sir)));
            _mm_storeu_ps(&Fout[m].r,
               _mm_add_ps(fm, _mm_xor_ps(s0s, sri)));
            tw1 += fstride * 2;
            tw2 += fstride * 4;
            Fout += 2;
         }
      }
#elif defined(ROPUS_NEON)
      {
         const float32x4_t half = vdupq_n_f32(.5f);
         const float32x4_t e3i = vdupq_n_f32(epi3.i);
         const uint32x4_t sri = { 0x80000000u, 0, 0x80000000u, 0 };
         const uint32x4_t sir = { 0, 0x80000000u, 0, 0x80000000u };
         for (; k >= 2; k -= 2)
         {
            float32x4_t f0 = vld1q_f32(&Fout[0].r);
            float32x4_t s1 = ropus_vq_cmul(vld1q_f32(&Fout[m].r),
               ropus_vq_ld2c(tw1, fstride));
            float32x4_t s2 = ropus_vq_cmul(vld1q_f32(&Fout[m2].r),
               ropus_vq_ld2c(tw2, fstride * 2));
            float32x4_t s3 = vaddq_f32(s1, s2);
            float32x4_t s0 = vsubq_f32(s1, s2);
            float32x4_t fm, s0s;
            fm = vsubq_f32(f0, vmulq_f32(half, s3));
            s0 = vmulq_f32(s0, e3i);
            vst1q_f32(&Fout[0].r, vaddq_f32(f0, s3));
            s0s = ROPUS_VQ_SWAPRI(s0);
            vst1q_f32(&Fout[m2].r,
               vaddq_f32(fm, ropus_vq_xor(s0s, sir)));
            vst1q_f32(&Fout[m].r,
               vaddq_f32(fm, ropus_vq_xor(s0s, sri)));
            tw1 += fstride * 2;
            tw2 += fstride * 4;
            Fout += 2;
         }
      }
#endif
      for (; k; k--)
      {
         ROPUS_C_MUL(scratch[1], Fout[m], *tw1);
         ROPUS_C_MUL(scratch[2], Fout[m2], *tw2);
         ROPUS_C_ADD(scratch[3], scratch[1], scratch[2]);
         ROPUS_C_SUB(scratch[0], scratch[1], scratch[2]);
         tw1 += fstride;
         tw2 += fstride * 2;
         Fout[m].r = Fout->r - .5f * scratch[3].r;
         Fout[m].i = Fout->i - .5f * scratch[3].i;
         ROPUS_C_MULBYSCALAR(scratch[0], epi3.i);
         ROPUS_C_ADDTO(*Fout, scratch[3]);
         Fout[m2].r = Fout[m].r + scratch[0].i;
         Fout[m2].i = Fout[m].i - scratch[0].r;
         Fout[m].r = Fout[m].r - scratch[0].i;
         Fout[m].i = Fout[m].i + scratch[0].r;
         ++Fout;
      }
   }
   (void)st;
}

static void ropus_kf_bfly5(ropus_cpx *Fout, size_t fstride,
      const ropus_fft_state *st, int m, int N, int mm)
{
   ropus_cpx *Fout0, *Fout1, *Fout2, *Fout3, *Fout4;
   int i, u;
   ropus_cpx scratch[13];
   const ropus_cpx *tw;
   ropus_cpx ya, yb;
   ropus_cpx *Fout_beg = Fout;
   ya = ropus_fft_twiddles[fstride * m];
   yb = ropus_fft_twiddles[fstride * 2 * m];
   tw = ropus_fft_twiddles;
   for (i = 0; i < N; i++)
   {
      Fout = Fout_beg + i * mm;
      Fout0 = Fout;
      Fout1 = Fout0 + m;
      Fout2 = Fout0 + 2 * m;
      Fout3 = Fout0 + 3 * m;
      Fout4 = Fout0 + 4 * m;
      u = 0;
#ifdef ROPUS_SSE2
      {
         const __m128 yar = _mm_set1_ps(ya.r);
         const __m128 yai = _mm_set1_ps(ya.i);
         const __m128 ybr = _mm_set1_ps(yb.r);
         const __m128 ybi = _mm_set1_ps(yb.i);
         const __m128 sri = _mm_castsi128_ps(_mm_set_epi32(
            0, (int)0x80000000, 0, (int)0x80000000));
         const __m128 sir = _mm_castsi128_ps(_mm_set_epi32(
            (int)0x80000000, 0, (int)0x80000000, 0));
         for (; u + 2 <= m; u += 2)
         {
            const ropus_cpx *twu = tw + (size_t)u * fstride;
            __m128 s0 = _mm_loadu_ps(&Fout0->r);
            __m128 s1 = ropus_mm_cmul(_mm_loadu_ps(&Fout1->r),
               ropus_mm_ld2c(twu, fstride));
            __m128 s2 = ropus_mm_cmul(_mm_loadu_ps(&Fout2->r),
               ropus_mm_ld2c(tw + 2 * (size_t)u * fstride,
                  2 * fstride));
            __m128 s3 = ropus_mm_cmul(_mm_loadu_ps(&Fout3->r),
               ropus_mm_ld2c(tw + 3 * (size_t)u * fstride,
                  3 * fstride));
            __m128 s4 = ropus_mm_cmul(_mm_loadu_ps(&Fout4->r),
               ropus_mm_ld2c(tw + 4 * (size_t)u * fstride,
                  4 * fstride));
            __m128 s7 = _mm_add_ps(s1, s4);
            __m128 s10 = _mm_sub_ps(s1, s4);
            __m128 s8 = _mm_add_ps(s2, s3);
            __m128 s9 = _mm_sub_ps(s2, s3);
            __m128 s5, s6, s11, s12, s9s, s10s;
            _mm_storeu_ps(&Fout0->r,
               _mm_add_ps(s0, _mm_add_ps(s7, s8)));
            s5 = _mm_add_ps(s0, _mm_add_ps(_mm_mul_ps(s7, yar),
               _mm_mul_ps(s8, ybr)));
            s10s = ROPUS_MM_SWAPRI(s10);
            s9s = ROPUS_MM_SWAPRI(s9);
            /* s6 = (s10.i*ya.i + s9.i*yb.i,
             *       -(s10.r*ya.i + s9.r*yb.i))                         */
            s6 = _mm_add_ps(_mm_mul_ps(s10s, yai),
               _mm_mul_ps(s9s, ybi));
            s6 = _mm_xor_ps(s6, sir);
            _mm_storeu_ps(&Fout1->r, _mm_sub_ps(s5, s6));
            _mm_storeu_ps(&Fout4->r, _mm_add_ps(s5, s6));
            s11 = _mm_add_ps(s0, _mm_add_ps(_mm_mul_ps(s7, ybr),
               _mm_mul_ps(s8, yar)));
            /* s12 = ( s9.i*ya.i - s10.i*yb.i,
             *         s10.r*yb.i - s9.r*ya.i )                         */
            s12 = _mm_add_ps(_mm_xor_ps(_mm_mul_ps(s9s, yai), sir),
               _mm_xor_ps(_mm_mul_ps(s10s, ybi), sri));
            _mm_storeu_ps(&Fout2->r, _mm_add_ps(s11, s12));
            _mm_storeu_ps(&Fout3->r, _mm_sub_ps(s11, s12));
            Fout0 += 2;
            Fout1 += 2;
            Fout2 += 2;
            Fout3 += 2;
            Fout4 += 2;
         }
      }
#elif defined(ROPUS_NEON)
      {
         const float32x4_t yar = vdupq_n_f32(ya.r);
         const float32x4_t yai = vdupq_n_f32(ya.i);
         const float32x4_t ybr = vdupq_n_f32(yb.r);
         const float32x4_t ybi = vdupq_n_f32(yb.i);
         const uint32x4_t sri = { 0x80000000u, 0, 0x80000000u, 0 };
         const uint32x4_t sir = { 0, 0x80000000u, 0, 0x80000000u };
         for (; u + 2 <= m; u += 2)
         {
            const ropus_cpx *twu = tw + (size_t)u * fstride;
            float32x4_t s0 = vld1q_f32(&Fout0->r);
            float32x4_t s1 = ropus_vq_cmul(vld1q_f32(&Fout1->r),
               ropus_vq_ld2c(twu, fstride));
            float32x4_t s2 = ropus_vq_cmul(vld1q_f32(&Fout2->r),
               ropus_vq_ld2c(tw + 2 * (size_t)u * fstride,
                  2 * fstride));
            float32x4_t s3 = ropus_vq_cmul(vld1q_f32(&Fout3->r),
               ropus_vq_ld2c(tw + 3 * (size_t)u * fstride,
                  3 * fstride));
            float32x4_t s4 = ropus_vq_cmul(vld1q_f32(&Fout4->r),
               ropus_vq_ld2c(tw + 4 * (size_t)u * fstride,
                  4 * fstride));
            float32x4_t s7 = vaddq_f32(s1, s4);
            float32x4_t s10 = vsubq_f32(s1, s4);
            float32x4_t s8 = vaddq_f32(s2, s3);
            float32x4_t s9 = vsubq_f32(s2, s3);
            float32x4_t s5, s6, s11, s12, s9s, s10s;
            vst1q_f32(&Fout0->r, vaddq_f32(s0, vaddq_f32(s7, s8)));
            s5 = vaddq_f32(s0, vaddq_f32(vmulq_f32(s7, yar),
               vmulq_f32(s8, ybr)));
            s10s = ROPUS_VQ_SWAPRI(s10);
            s9s = ROPUS_VQ_SWAPRI(s9);
            s6 = vaddq_f32(vmulq_f32(s10s, yai), vmulq_f32(s9s, ybi));
            s6 = ropus_vq_xor(s6, sir);
            vst1q_f32(&Fout1->r, vsubq_f32(s5, s6));
            vst1q_f32(&Fout4->r, vaddq_f32(s5, s6));
            s11 = vaddq_f32(s0, vaddq_f32(vmulq_f32(s7, ybr),
               vmulq_f32(s8, yar)));
            s12 = vaddq_f32(ropus_vq_xor(vmulq_f32(s9s, yai), sir),
               ropus_vq_xor(vmulq_f32(s10s, ybi), sri));
            vst1q_f32(&Fout2->r, vaddq_f32(s11, s12));
            vst1q_f32(&Fout3->r, vsubq_f32(s11, s12));
            Fout0 += 2;
            Fout1 += 2;
            Fout2 += 2;
            Fout3 += 2;
            Fout4 += 2;
         }
      }
#endif
      for (; u < m; ++u)
      {
         scratch[0] = *Fout0;
         ROPUS_C_MUL(scratch[1], *Fout1, tw[u * fstride]);
         ROPUS_C_MUL(scratch[2], *Fout2, tw[2 * u * fstride]);
         ROPUS_C_MUL(scratch[3], *Fout3, tw[3 * u * fstride]);
         ROPUS_C_MUL(scratch[4], *Fout4, tw[4 * u * fstride]);
         ROPUS_C_ADD(scratch[7], scratch[1], scratch[4]);
         ROPUS_C_SUB(scratch[10], scratch[1], scratch[4]);
         ROPUS_C_ADD(scratch[8], scratch[2], scratch[3]);
         ROPUS_C_SUB(scratch[9], scratch[2], scratch[3]);
         Fout0->r = Fout0->r + (scratch[7].r + scratch[8].r);
         Fout0->i = Fout0->i + (scratch[7].i + scratch[8].i);
         scratch[5].r = scratch[0].r
            + (scratch[7].r * ya.r + scratch[8].r * yb.r);
         scratch[5].i = scratch[0].i
            + (scratch[7].i * ya.r + scratch[8].i * yb.r);
         scratch[6].r = scratch[10].i * ya.i + scratch[9].i * yb.i;
         scratch[6].i = -(scratch[10].r * ya.i + scratch[9].r * yb.i);
         ROPUS_C_SUB(*Fout1, scratch[5], scratch[6]);
         ROPUS_C_ADD(*Fout4, scratch[5], scratch[6]);
         scratch[11].r = scratch[0].r
            + (scratch[7].r * yb.r + scratch[8].r * ya.r);
         scratch[11].i = scratch[0].i
            + (scratch[7].i * yb.r + scratch[8].i * ya.r);
         scratch[12].r = scratch[9].i * ya.i - scratch[10].i * yb.i;
         scratch[12].i = scratch[10].r * yb.i - scratch[9].r * ya.i;
         ROPUS_C_ADD(*Fout2, scratch[11], scratch[12]);
         ROPUS_C_SUB(*Fout3, scratch[11], scratch[12]);
         ++Fout0;
         ++Fout1;
         ++Fout2;
         ++Fout3;
         ++Fout4;
      }
   }
   (void)st;
}

#define ROPUS_MAXFACTORS 8

static void ropus_fft_impl(const ropus_fft_state *st, ropus_cpx *fout)
{
   int m2, m, p, L, i;
   int fstride[ROPUS_MAXFACTORS];
   int shift = st->shift > 0 ? st->shift : 0;
   fstride[0] = 1;
   L = 0;
   do
   {
      p = st->factors[2 * L];
      m = st->factors[2 * L + 1];
      fstride[L + 1] = fstride[L] * p;
      L++;
   } while (m != 1);
   m = st->factors[2 * L - 1];
   for (i = L - 1; i >= 0; i--)
   {
      if (i != 0)
         m2 = st->factors[2 * i - 1];
      else
         m2 = 1;
      switch (st->factors[2 * i])
      {
         case 2:
            ropus_kf_bfly2(fout, m, fstride[i]);
            break;
         case 4:
            ropus_kf_bfly4(fout, fstride[i] << shift, st, m,
               fstride[i], m2);
            break;
         case 3:
            ropus_kf_bfly3(fout, fstride[i] << shift, st, m,
               fstride[i], m2);
            break;
         case 5:
            ropus_kf_bfly5(fout, fstride[i] << shift, st, m,
               fstride[i], m2);
            break;
      }
      m = m2;
   }
}

/* clt_mdct_backward (celt/mdct.c), float.  The 1920-point lookup with
 * per-shift trig subsampling; 'shift' selects the block size, 'stride'
 * is the interleave factor B.                                          */
static void ropus_mdct_backward(const float *in, float *out,
      const float *window, int overlap, int shift, int stride)
{
   int i;
   int N, N2, N4;
   const float *trig = ropus_mdct_twiddles;
   N = 1920;
   for (i = 0; i < shift; i++)
   {
      N >>= 1;
      trig += N;
   }
   N2 = N >> 1;
   N4 = N >> 2;
   /* Pre-rotate */
   {
      const float *xp1 = in;
      const float *xp2 = in + stride * (N2 - 1);
      float *yp = out + (overlap >> 1);
      const float *t = &trig[0];
      const int16_t *bitrev = ropus_fft_states[shift].bitrev;
      for (i = 0; i < N4; i++)
      {
         int rev = *bitrev++;
         float yr = *xp2 * t[i] + *xp1 * t[N4 + i];
         float yi = *xp1 * t[i] - *xp2 * t[N4 + i];
         yp[2 * rev + 1] = yr;
         yp[2 * rev] = yi;
         xp1 += 2 * stride;
         xp2 -= 2 * stride;
      }
   }
   ropus_fft_impl(&ropus_fft_states[shift],
      (ropus_cpx *)(out + (overlap >> 1)));
   /* Post-rotate and de-shuffle */
   {
      float *yp0 = out + (overlap >> 1);
      float *yp1 = out + (overlap >> 1) + N2 - 2;
      const float *t = &trig[0];
      int half = (N4 + 1) >> 1;
      i = 0;
#ifdef ROPUS_SSE2
      {
         /* Two iterations per step: the ascending stream (yp0) and the
          * descending stream (yp1) are processed as four independent
          * rotations; per lane, yr = re*t0 + im*t1 and
          * yi = re*t1 + (-(im*t0)) reproduce the scalar ops exactly.
          * Steps run only while the two 4-float windows are disjoint,
          * so the scalar read/write interleaving at the centre is
          * preserved by the scalar tail. */
         const __m128 sgn = _mm_castsi128_ps(_mm_set1_epi32(
            (int)0x80000000));
         while (i + 2 <= half && yp1 - yp0 >= 8)
         {
            __m128 A = _mm_loadu_ps(yp0);          /* imA0 reA0 imA1 reA1 */
            __m128 B = _mm_loadu_ps(yp1 - 2);      /* imB1 reB1 imB0 reB0 */
            __m128 re4 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(1, 3, 3, 1));
            __m128 im4 = _mm_shuffle_ps(A, B, _MM_SHUFFLE(0, 2, 2, 0));
            __m128 t0v, t1v, yr, yi, u, v;
            t0v = _mm_loadl_pi(_mm_setzero_ps(),
               (const __m64 *)(t + i));
            t0v = _mm_loadh_pi(t0v, (const __m64 *)(t + N4 - i - 2));
            t0v = _mm_shuffle_ps(t0v, t0v, _MM_SHUFFLE(2, 3, 1, 0));
            t1v = _mm_loadl_pi(_mm_setzero_ps(),
               (const __m64 *)(t + N4 + i));
            t1v = _mm_loadh_pi(t1v, (const __m64 *)(t + N2 - i - 2));
            t1v = _mm_shuffle_ps(t1v, t1v, _MM_SHUFFLE(2, 3, 1, 0));
            yr = _mm_add_ps(_mm_mul_ps(re4, t0v),
               _mm_mul_ps(im4, t1v));
            yi = _mm_add_ps(_mm_mul_ps(re4, t1v),
               _mm_xor_ps(_mm_mul_ps(im4, t0v), sgn));
            /* yp0 <- (yrA0, yiB0, yrA1, yiB1);
             * yp1-2 <- (yrB1, yiA1, yrB0, yiA0)                        */
            u = _mm_shuffle_ps(yr, yi, _MM_SHUFFLE(3, 2, 1, 0));
            v = _mm_shuffle_ps(yr, yi, _MM_SHUFFLE(0, 1, 2, 3));
            _mm_storeu_ps(yp0,
               _mm_shuffle_ps(u, u, _MM_SHUFFLE(3, 1, 2, 0)));
            _mm_storeu_ps(yp1 - 2,
               _mm_shuffle_ps(v, v, _MM_SHUFFLE(3, 1, 2, 0)));
            yp0 += 4;
            yp1 -= 4;
            i += 2;
         }
      }
#elif defined(ROPUS_NEON)
      {
         const uint32x4_t sgn = vdupq_n_u32(0x80000000u);
         while (i + 2 <= half && yp1 - yp0 >= 8)
         {
            float32x4_t A = vld1q_f32(yp0);
            float32x4_t B = vld1q_f32(yp1 - 2);
            float32x4_t Bs = vcombine_f32(vget_high_f32(B),
               vget_low_f32(B));
            float32x4_t re4 = vuzp2q_f32(A, Bs);
            float32x4_t im4 = vuzp1q_f32(A, Bs);
            float32x4_t t0v = vcombine_f32(vld1_f32(t + i),
               vrev64_f32(vld1_f32(t + N4 - i - 2)));
            float32x4_t t1v = vcombine_f32(vld1_f32(t + N4 + i),
               vrev64_f32(vld1_f32(t + N2 - i - 2)));
            float32x4_t yr = vaddq_f32(vmulq_f32(re4, t0v),
               vmulq_f32(im4, t1v));
            float32x4_t yi = vaddq_f32(vmulq_f32(re4, t1v),
               ropus_vq_xor(vmulq_f32(im4, t0v), sgn));
            vst1q_f32(yp0, vzip1q_f32(yr, vextq_f32(yi, yi, 2)));
            vst1q_f32(yp1 - 2,
               vzip1q_f32(ropus_vq_rev4(yr), vrev64q_f32(yi)));
            yp0 += 4;
            yp1 -= 4;
            i += 2;
         }
      }
#endif
      for (; i < half; i++)
      {
         float re, im, yr, yi, t0, t1;
         re = yp0[1];
         im = yp0[0];
         t0 = t[i];
         t1 = t[N4 + i];
         yr = re * t0 + im * t1;
         yi = re * t1 - im * t0;
         re = yp1[1];
         im = yp1[0];
         yp0[0] = yr;
         yp1[1] = yi;
         t0 = t[N4 - i - 1];
         t1 = t[N2 - i - 1];
         yr = re * t0 + im * t1;
         yi = re * t1 - im * t0;
         yp1[0] = yr;
         yp0[1] = yi;
         yp0 += 2;
         yp1 -= 2;
      }
   }
   /* Mirror on both sides for TDAC */
   {
      float *xp1 = out + overlap - 1;
      float *yp1 = out;
      const float *wp1 = window;
      const float *wp2 = window + overlap - 1;
      i = 0;
#ifdef ROPUS_SSE2
      {
         /* Forward stream: yp1/wp1; backward stream: xp1/wp2, loaded
          * reversed.  Per lane: y = w2*x2 + (-(w1*x1)); the negated
          * product equals the scalar subtraction bit-exactly. */
         const __m128 sgn = _mm_castsi128_ps(_mm_set1_epi32(
            (int)0x80000000));
         for (; i + 4 <= overlap / 2; i += 4)
         {
            __m128 x2 = _mm_loadu_ps(yp1);
            __m128 w1 = _mm_loadu_ps(wp1);
            __m128 x1 = _mm_loadu_ps(xp1 - 3);
            __m128 w2 = _mm_loadu_ps(wp2 - 3);
            __m128 yv, xv;
            x1 = _mm_shuffle_ps(x1, x1, _MM_SHUFFLE(0, 1, 2, 3));
            w2 = _mm_shuffle_ps(w2, w2, _MM_SHUFFLE(0, 1, 2, 3));
            yv = _mm_add_ps(_mm_mul_ps(w2, x2),
               _mm_xor_ps(_mm_mul_ps(w1, x1), sgn));
            xv = _mm_add_ps(_mm_mul_ps(w1, x2), _mm_mul_ps(w2, x1));
            _mm_storeu_ps(yp1, yv);
            xv = _mm_shuffle_ps(xv, xv, _MM_SHUFFLE(0, 1, 2, 3));
            _mm_storeu_ps(xp1 - 3, xv);
            yp1 += 4;
            xp1 -= 4;
            wp1 += 4;
            wp2 -= 4;
         }
      }
#elif defined(ROPUS_NEON)
      {
         const uint32x4_t sgn = vdupq_n_u32(0x80000000u);
         for (; i + 4 <= overlap / 2; i += 4)
         {
            float32x4_t x2 = vld1q_f32(yp1);
            float32x4_t w1 = vld1q_f32(wp1);
            float32x4_t x1 = ropus_vq_rev4(vld1q_f32(xp1 - 3));
            float32x4_t w2 = ropus_vq_rev4(vld1q_f32(wp2 - 3));
            float32x4_t yv, xv;
            yv = vaddq_f32(vmulq_f32(w2, x2),
               ropus_vq_xor(vmulq_f32(w1, x1), sgn));
            xv = vaddq_f32(vmulq_f32(w1, x2), vmulq_f32(w2, x1));
            vst1q_f32(yp1, yv);
            vst1q_f32(xp1 - 3, ropus_vq_rev4(xv));
            yp1 += 4;
            xp1 -= 4;
            wp1 += 4;
            wp2 -= 4;
         }
      }
#endif
      for (; i < overlap / 2; i++)
      {
         float x1 = *xp1;
         float x2 = *yp1;
         *yp1++ = *wp2 * x2 - *wp1 * x1;
         *xp1-- = *wp1 * x2 + *wp2 * x1;
         wp1++;
         wp2--;
      }
   }
}

/* Frame-decode scratch, one per decoder context (embedded in ropus_t
 * below).  These lived on the decode-frame and CELT-decode stacks:
 * pcm_silk alone is 11.5 KB, the float CELT norm buffers another
 * 19.2 KB, stacking to a worst-case decode depth near 50 KB on the
 * audio/task thread.  Per context and not static for the same reason
 * as sub_q/sub_f: the mixer runs several voices at once.  One scratch
 * per context serves every substream and every (sequential) CELT
 * call, main and redundancy alike. */
typedef struct
{
   int16_t pcm_silk[2880 * 2];
   int16_t bl[960];
   int16_t br[960];
   union
   {
      float   f[240 * 2];
      int16_t q[240 * 2];
   } redundant;
   /* CELT band coefficients (C*N plus last-band lowband scratch) and
    * the quant_all_bands norm scratch; the q view is int16_t spelled
    * out because the ropus_norm (Q14) typedef appears later in the
    * file than this struct must. */
   union
   {
      struct
      {
         float X[2 * 960 + 960];
         float norm[2 * 960];
         float freq[2 * 960];      /* IMDCT staging in celt_synthesis */
         float had[1024];          /* quant_band hadamard interleave  */
      } f;
      struct
      {
         int16_t X[2 * 960 + 960];
         int16_t norm[2 * 960];
         int32_t freq[2 * 960];    /* ropus_sig (Q12), typedef'd later
                                    * in the file than this struct     */
         int16_t had[1024];        /* quant_band hadamard interleave  */
      } q;
   } celt;
} ropus_frame_scratch;

static void ropus_celt_synthesis(const float *X, float *out_syn[],
      ropus_frame_scratch *scr,
      const float *oldBandE, int start, int effEnd, int C, int CC,
      int isTransient, int LM, int silence)
{
   int c, i, b;
   int M, B, N, NB, shift;
   float *freq = scr->celt.f.freq;
   N = ROPUS_SHORT_MDCT << LM;
   M = 1 << LM;
   if (isTransient)
   {
      B = M;
      NB = ROPUS_SHORT_MDCT;
      shift = ROPUS_MAXLM;
   }
   else
   {
      B = 1;
      NB = ROPUS_SHORT_MDCT << LM;
      shift = ROPUS_MAXLM - LM;
   }
   if (CC == 2 && C == 1)
   {
      float *freq2 = out_syn[1] + (ROPUS_OVERLAP / 2);
      ropus_denormalise_bands(X, freq, oldBandE, start, effEnd, M, silence);
      memcpy(freq2, freq, N * sizeof(float));
      for (b = 0; b < B; b++)
         ropus_mdct_backward(&freq2[b], out_syn[0] + NB * b,
            ropus_window120, ROPUS_OVERLAP, shift, B);
      for (b = 0; b < B; b++)
         ropus_mdct_backward(&freq[b], out_syn[1] + NB * b,
            ropus_window120, ROPUS_OVERLAP, shift, B);
   }
   else
   {
      c = 0;
      do
      {
         ropus_denormalise_bands(X + c * N, freq,
            oldBandE + c * ROPUS_NBANDS, start, effEnd, M, silence);
         for (b = 0; b < B; b++)
            ropus_mdct_backward(&freq[b], out_syn[c] + NB * b,
               ropus_window120, ROPUS_OVERLAP, shift, B);
      } while (++c < CC);
   }
   (void)i;
}

static const float ropus_pf_gains[3][3] =
{
   { 0.3066406250f, 0.2170410156f, 0.1296386719f },
   { 0.4638671875f, 0.2680664062f, 0.f },
   { 0.7998046875f, 0.1000976562f, 0.f }
};

static void ropus_comb_filter_const(float *y, float *x, int T, int N,
      float g10, float g11, float g12)
{
   int i;
   for (i = 0; i < N; i++)
   {
      float t = x[i] + g10 * x[i - T];
      t = t + g11 * (x[i - T + 1] + x[i - T - 1]);
      t = t + g12 * (x[i - T + 2] + x[i - T - 2]);
      y[i] = t;
   }
}

static void ropus_comb_filter(float *y, float *x, int T0, int T1, int N,
      float g0, float g1, int tapset0, int tapset1,
      const float *window, int overlap)
{
   int i;
   float g00, g01, g02, g10, g11, g12;
   float x0, x1, x2, x3, x4;
   if (g0 == 0 && g1 == 0)
   {
      if (x != y)
         memmove(y, x, N * sizeof(*y));
      return;
   }
   T0 = ropus_imax(T0, ROPUS_COMBFILTER_MINPERIOD);
   T1 = ropus_imax(T1, ROPUS_COMBFILTER_MINPERIOD);
   g00 = g0 * ropus_pf_gains[tapset0][0];
   g01 = g0 * ropus_pf_gains[tapset0][1];
   g02 = g0 * ropus_pf_gains[tapset0][2];
   g10 = g1 * ropus_pf_gains[tapset1][0];
   g11 = g1 * ropus_pf_gains[tapset1][1];
   g12 = g1 * ropus_pf_gains[tapset1][2];
   x1 = x[-T1 + 1];
   x2 = x[-T1];
   x3 = x[-T1 - 1];
   x4 = x[-T1 - 2];
   if (g0 == g1 && T0 == T1 && tapset0 == tapset1)
      overlap = 0;
   for (i = 0; i < overlap; i++)
   {
      float f;
      x0 = x[i - T1 + 2];
      f = window[i] * window[i];
      y[i] = x[i]
         + ((1.f - f) * g00) * x[i - T0]
         + ((1.f - f) * g01) * (x[i - T0 + 1] + x[i - T0 - 1])
         + ((1.f - f) * g02) * (x[i - T0 + 2] + x[i - T0 - 2])
         + (f * g10) * x2
         + (f * g11) * (x1 + x3)
         + (f * g12) * (x0 + x4);
      x4 = x3;
      x3 = x2;
      x2 = x1;
      x1 = x0;
   }
   if (g1 == 0)
   {
      if (x != y)
         memmove(y + overlap, x + overlap, (N - overlap) * sizeof(*y));
      return;
   }
   ropus_comb_filter_const(y + i, x + i, T1, N - i, g10, g11, g12);
}

/* deemphasis, float, downsample==1 (48 kHz output).                    */
static void ropus_deemphasis(float *in[], float *pcm, int N, int C,
      float *mem)
{
   if (C == 2)
   {
      float *x0 = in[0];
      float *x1 = in[1];
      float m0 = mem[0], m1 = mem[1];
      int j;
      for (j = 0; j < N; j++)
      {
         float tmp0 = x0[j] + ROPUS_VERY_SMALL + m0;
         float tmp1 = x1[j] + ROPUS_VERY_SMALL + m1;
         m0 = ROPUS_PREEMPH_COEF0 * tmp0;
         m1 = ROPUS_PREEMPH_COEF0 * tmp1;
         pcm[2 * j]     = tmp0 * (1.f / ROPUS_CELT_SIG_SCALE);
         pcm[2 * j + 1] = tmp1 * (1.f / ROPUS_CELT_SIG_SCALE);
      }
      mem[0] = m0;
      mem[1] = m1;
   }
   else
   {
      float *x = in[0];
      float m = mem[0];
      int j;
      for (j = 0; j < N; j++)
      {
         float tmp = x[j] + ROPUS_VERY_SMALL + m;
         m = ROPUS_PREEMPH_COEF0 * tmp;
         pcm[j] = tmp * (1.f / ROPUS_CELT_SIG_SCALE);
      }
      mem[0] = m;
   }
}

/* ==================================================================== */
/* celt_decode_with_ec, decode-only, float pipeline, 48 kHz.            */
/* pcm receives N interleaved float frames (CC channels, [-1,1]).       */
/* ==================================================================== */
static int ropus_celt_decode(ropus_celt *st,
      ropus_frame_scratch *scr, const uint8_t *data, int len,
      float *pcm, int frame_size, ropus_ec *dec)
{
   int c, i, N, CC = st->channels, C = st->stream_channels;
   int start = st->start, end = st->end;

   ropus_celt_frame f;
   float *decode_mem[2];
   float *out_syn[2];
   float *oldBandE, *oldLogE, *oldLogE2, *backgroundLogE;
   uint8_t collapse_masks[2 * ROPUS_NBANDS];
   int anti_collapse_on = 0;
   float *X       = scr->celt.f.X;
   float *normbuf = scr->celt.f.norm;
   float max_background_increase;

   (void)data;
   memset(&f, 0, sizeof f);
   oldBandE = st->oldEBands;
   oldLogE = st->oldLogE;
   oldLogE2 = st->oldLogE2;
   backgroundLogE = st->backgroundLogE;

   if (ropus_celt_front(st, dec, len, frame_size, &f))
      return -1;
   N = f.N;

   c = 0;
   do
   {
      decode_mem[c] = st->decode_mem[c];
      out_syn[c] = decode_mem[c] + ROPUS_DECODE_BUFFER_SIZE - N;
      /* history shift (libopus does this right after fine energy) */
      memmove(decode_mem[c], decode_mem[c] + N,
         (ROPUS_DECODE_BUFFER_SIZE - N + ROPUS_OVERLAP / 2)
         * sizeof(float));
   } while (++c < CC);

   memset(X, 0, sizeof scr->celt.f.X);
   ropus_quant_all_bands(start, end, X, C == 2 ? X + N : NULL,
      collapse_masks, f.pulses, f.shortBlocks, f.spread_decision,
      f.dual_stereo, f.intensity, f.tf_res,
      (int32_t)len * (8 << ROPUS_BITRES) - f.anti_collapse_rsv,
      f.balance, dec, f.LM, f.codedBands, &st->rng, 0, normbuf,
      scr->celt.f.had);

   if (f.anti_collapse_rsv > 0)
      anti_collapse_on = (int)ropus_ec_dec_bits(dec, 1);

   ropus_unquant_energy_finalise(start, end, oldBandE, f.fine_quant,
      f.fine_priority, len * 8 - ropus_ec_tell(dec), dec, C);

   if (anti_collapse_on)
      ropus_anti_collapse(X, collapse_masks, f.LM, C, N, start, end,
         oldBandE, oldLogE, oldLogE2, f.pulses, st->rng);

   if (f.silence)
      for (i = 0; i < C * ROPUS_NBANDS; i++)
         oldBandE[i] = -28.f;

   ropus_celt_synthesis(X, out_syn, scr, oldBandE, start, f.effEnd, C, CC,
      f.isTransient, f.LM, f.silence);

   c = 0;
   do
   {
      st->postfilter_period =
         ropus_imax(st->postfilter_period, ROPUS_COMBFILTER_MINPERIOD);
      st->postfilter_period_old =
         ropus_imax(st->postfilter_period_old, ROPUS_COMBFILTER_MINPERIOD);
      ropus_comb_filter(out_syn[c], out_syn[c],
         st->postfilter_period_old, st->postfilter_period,
         ROPUS_SHORT_MDCT, st->postfilter_gain_old, st->postfilter_gain,
         st->postfilter_tapset_old, st->postfilter_tapset,
         ropus_window120, ROPUS_OVERLAP);
      if (f.LM != 0)
         ropus_comb_filter(out_syn[c] + ROPUS_SHORT_MDCT,
            out_syn[c] + ROPUS_SHORT_MDCT,
            st->postfilter_period, f.postfilter_pitch,
            N - ROPUS_SHORT_MDCT,
            st->postfilter_gain, f.postfilter_gain,
            st->postfilter_tapset, f.postfilter_tapset,
            ropus_window120, ROPUS_OVERLAP);
   } while (++c < CC);

   st->postfilter_period_old = st->postfilter_period;
   st->postfilter_gain_old = st->postfilter_gain;
   st->postfilter_tapset_old = st->postfilter_tapset;
   st->postfilter_period = f.postfilter_pitch;
   st->postfilter_gain = f.postfilter_gain;
   st->postfilter_tapset = f.postfilter_tapset;
   if (f.LM != 0)
   {
      st->postfilter_period_old = st->postfilter_period;
      st->postfilter_gain_old = st->postfilter_gain;
      st->postfilter_tapset_old = st->postfilter_tapset;
   }

   if (C == 1)
      memcpy(&oldBandE[ROPUS_NBANDS], oldBandE,
         ROPUS_NBANDS * sizeof(float));

   if (!f.isTransient)
   {
      memcpy(oldLogE2, oldLogE, 2 * ROPUS_NBANDS * sizeof(float));
      memcpy(oldLogE, oldBandE, 2 * ROPUS_NBANDS * sizeof(float));
   }
   else
      for (i = 0; i < 2 * ROPUS_NBANDS; i++)
         oldLogE[i] = ropus_minf(oldLogE[i], oldBandE[i]);

   max_background_increase =
      ropus_imin(160, st->loss_duration + (1 << f.LM)) * 0.001f;
   for (i = 0; i < 2 * ROPUS_NBANDS; i++)
      backgroundLogE[i] = ropus_minf(
         backgroundLogE[i] + max_background_increase, oldBandE[i]);

   c = 0;
   do
   {
      for (i = 0; i < start; i++)
      {
         oldBandE[c * ROPUS_NBANDS + i] = 0;
         oldLogE[c * ROPUS_NBANDS + i] =
            oldLogE2[c * ROPUS_NBANDS + i] = -28.f;
      }
      for (i = end; i < ROPUS_NBANDS; i++)
      {
         oldBandE[c * ROPUS_NBANDS + i] = 0;
         oldLogE[c * ROPUS_NBANDS + i] =
            oldLogE2[c * ROPUS_NBANDS + i] = -28.f;
      }
   } while (++c < 2);

   st->rng = dec->rng;

   ropus_deemphasis(out_syn, pcm, N, CC, st->preemph_memD);
   st->loss_duration = 0;
   if (ropus_ec_tell(dec) > 8 * len)
      return -2;
   if (dec->error)
      st->error = 1;
   return N;
}

/* ==================================================================== */
/* ================  FIXED-POINT (s16) CELT PIPELINE  ================= */
/* Same control flow as the float pipeline above; sample-domain         */
/* arithmetic follows the libopus FIXED_POINT build exactly.            */
/* celt_norm is Q14 int16, celt_sig is Q12 (SIG_SHIFT) int32,           */
/* energies are Q10 (DB_SHIFT) int16.                                   */
/* ==================================================================== */
#define ROPUS_SIG_SHIFT 12
#define ROPUS_DB_SHIFT  10
#define ROPUS_SIG_SAT   300000000

typedef int16_t ropus_norm;              /* celt_norm, Q14              */
typedef int32_t ropus_sig;               /* celt_sig, Q12               */

static INLINE int32_t ropus_shr32(int32_t a, int s) { return a >> s; }
static INLINE int32_t ropus_pshr32(int32_t a, int s)
{
   return (a + ((int32_t)1 << (s - 1))) >> s;
}
static INLINE int32_t ropus_vshr32(int32_t a, int s)
{
   return s > 0 ? (a >> s) : (int32_t)((uint32_t)a << -s);
}
#define ROPUS_MULT16_16(a, b) \
   ((int32_t)(int16_t)(a) * (int32_t)(int16_t)(b))
#define ROPUS_MULT16_16_Q15(a, b)  (ROPUS_MULT16_16(a, b) >> 15)
#define ROPUS_MULT16_16_P15(a, b)  ((16384 + ROPUS_MULT16_16(a, b)) >> 15)
#define ROPUS_MULT16_16_Q14(a, b)  (ROPUS_MULT16_16(a, b) >> 14)
#define ROPUS_MULT16_32_Q15(a, b) \
   ((int32_t)(((int64_t)(int16_t)(a) * (b)) >> 15))
#define ROPUS_MULT16_32_Q16(a, b) \
   ((int32_t)(((int64_t)(int16_t)(a) * (b)) >> 16))
#define ROPUS_MULT32_32_Q31(a, b) \
   ((int32_t)(((int64_t)(a) * (b)) >> 31))
#define ROPUS_MAC16_32_Q16(c, a, b) ((c) + ROPUS_MULT16_32_Q16(a, b))
#define ROPUS_ADD32_OVF(a, b) ((int32_t)((uint32_t)(a) + (uint32_t)(b)))
#define ROPUS_SUB32_OVF(a, b) ((int32_t)((uint32_t)(a) - (uint32_t)(b)))
#define ROPUS_NEG32_OVF(a)    ((int32_t)(0 - (uint32_t)(a)))
#define ROPUS_SAT16(x) \
   ((x) > 32767 ? 32767 : (x) < -32768 ? -32768 : (int16_t)(x))
#define ROPUS_SATURATE(x, a) \
   ((x) > (a) ? (a) : (x) < -(a) ? -(a) : (x))
static INLINE int16_t ropus_min16(int16_t a, int16_t b) { return a < b ? a : b; }
static INLINE int16_t ropus_max16(int16_t a, int16_t b) { return a > b ? a : b; }
static INLINE int32_t ropus_min32(int32_t a, int32_t b) { return a < b ? a : b; }
static INLINE int32_t ropus_max32(int32_t a, int32_t b) { return a > b ? a : b; }

static INLINE int ropus_celt_ilog2(int32_t x)
{
   return ropus_ec_ilog((uint32_t)x) - 1;
}

/* celt/mathops.c fixed-point primitives */
static int16_t ropus_celt_rsqrt_norm_q(int32_t x)
{
   int16_t n, r, r2, y;
   n = (int16_t)(x - 32768);
   r = (int16_t)(23557 + ROPUS_MULT16_16_Q15(n,
      (int16_t)(-13490 + ROPUS_MULT16_16_Q15(n, 6713))));
   r2 = (int16_t)ROPUS_MULT16_16_Q15(r, r);
   y = (int16_t)((int16_t)((int16_t)(ROPUS_MULT16_16_Q15(r2, n) + r2)
      - 16384) * 2);
   return (int16_t)(r + ROPUS_MULT16_16_Q15(r, ROPUS_MULT16_16_Q15(y,
      (int16_t)(ROPUS_MULT16_16_Q15(y, 12288) - 16384))));
}

static int32_t ropus_celt_sqrt_q(int32_t x)
{
   int k;
   int16_t n;
   int32_t rt;
   static const int16_t C[5] = { 23175, 11561, -3011, 1699, -664 };
   if (x == 0)
      return 0;
   else if (x >= 1073741824)
      return 32767;
   k = (ropus_celt_ilog2(x) >> 1) - 7;
   x = ropus_vshr32(x, 2 * k);
   n = (int16_t)(x - 32768);
   rt = (int16_t)(C[0] + ROPUS_MULT16_16_Q15(n, (int16_t)(C[1]
      + ROPUS_MULT16_16_Q15(n, (int16_t)(C[2]
      + ROPUS_MULT16_16_Q15(n, (int16_t)(C[3]
      + ROPUS_MULT16_16_Q15(n, C[4]))))))));
   rt = ropus_vshr32(rt, 7 - k);
   return rt;
}

static INLINE int16_t ropus_cos_pi_2_q(int16_t x)
{
   int16_t x2 = (int16_t)ROPUS_MULT16_16_P15(x, x);
   int32_t v = (int32_t)(int16_t)(32767 - x2)
      + ROPUS_MULT16_16_P15(x2, (int32_t)(-7651)
      + ROPUS_MULT16_16_P15(x2, (int32_t)8277
      + ROPUS_MULT16_16_P15(-626, x2)));
   return (int16_t)(1 + ropus_min32(32766, v));
}

static int16_t ropus_celt_cos_norm_q(int32_t x)
{
   x = x & 0x0001ffff;
   if (x > (1 << 16))
      x = (1 << 17) - x;
   if (x & 0x00007fff)
   {
      if (x < (1 << 15))
         return ropus_cos_pi_2_q((int16_t)x);
      else
         return (int16_t)-ropus_cos_pi_2_q((int16_t)(65536 - x));
   }
   else
   {
      if (x & 0x0000ffff)
         return 0;
      else if (x & 0x0001ffff)
         return -32767;
      else
         return 32767;
   }
}

static INLINE int32_t ropus_celt_exp2_frac_q(int16_t x)
{
   int16_t frac = (int16_t)(x << 4);
   return (int16_t)(16383 + ROPUS_MULT16_16_Q15(frac, (int16_t)(22804
      + ROPUS_MULT16_16_Q15(frac, (int16_t)(14819
      + ROPUS_MULT16_16_Q15(10204, frac))))));
}

static INLINE int32_t ropus_celt_exp2_q(int16_t x)
{
   int integer = x >> 10;
   int32_t frac;
   if (integer > 14)
      return 0x7f000000;
   else if (integer < -15)
      return 0;
   frac = ropus_celt_exp2_frac_q((int16_t)(x - integer * 1024));
   return ropus_vshr32(frac, -integer - 2);
}

static int32_t ropus_celt_rcp_q(int32_t x)
{
   int i = ropus_celt_ilog2(x);
   int16_t n = (int16_t)(ropus_vshr32(x, i - 15) - 32768);
   int16_t r = (int16_t)(30840 + ROPUS_MULT16_16_Q15(-15420, n));
   r = (int16_t)(r - ROPUS_MULT16_16_Q15(r,
      (int16_t)(ROPUS_MULT16_16_Q15(r, n) + (int16_t)(r - 32768))));
   r = (int16_t)(r - (1 + ROPUS_MULT16_16_Q15(r,
      (int16_t)(ROPUS_MULT16_16_Q15(r, n) + (int16_t)(r - 32768)))));
   return ropus_vshr32((int32_t)r, i - 16);
}

#define ROPUS_CELT_DIV_Q(a, b) \
   ROPUS_MULT32_32_Q31((int32_t)(a), ropus_celt_rcp_q(b))

/* Fixed-point energy envelope (quant_bands.c FIXED_POINT).             */
static const int16_t ropus_pred_coef_q[4] = { 29440, 26112, 21248, 16384 };
static const int16_t ropus_beta_coef_q[4] = { 30147, 22282, 12124, 6554 };
#define ROPUS_BETA_INTRA_Q 4915

static void ropus_unquant_coarse_energy_q(int start, int end,
      int16_t *oldEBands, int intra, ropus_ec *dec, int C, int LM)
{
   const uint8_t *prob_model = ropus_e_prob_model[LM][intra];
   int i, c;
   int32_t prev[2] = { 0, 0 };
   int16_t coef, beta;
   int32_t budget, tell;
   if (intra)
   {
      coef = 0;
      beta = ROPUS_BETA_INTRA_Q;
   }
   else
   {
      beta = ropus_beta_coef_q[LM];
      coef = ropus_pred_coef_q[LM];
   }
   budget = dec->storage * 8;
   for (i = start; i < end; i++)
   {
      c = 0;
      do
      {
         int qi;
         int32_t q, tmp;
         tell = ropus_ec_tell(dec);
         if (budget - tell >= 15)
         {
            int pi = 2 * ropus_imin(i, 20);
            qi = ropus_ec_laplace_decode(dec,
               prob_model[pi] << 7, prob_model[pi + 1] << 6);
         }
         else if (budget - tell >= 2)
         {
            qi = ropus_ec_dec_icdf(dec, ropus_small_energy_icdf, 2);
            qi = (qi >> 1) ^ -(qi & 1);
         }
         else if (budget - tell >= 1)
            qi = -ropus_ec_dec_bit_logp(dec, 1);
         else
            qi = -1;
         q = (int32_t)qi * (1 << ROPUS_DB_SHIFT);
         oldEBands[i + c * ROPUS_NBANDS] = ropus_max16(
            (int16_t)-(9 << ROPUS_DB_SHIFT),
            oldEBands[i + c * ROPUS_NBANDS]);
         tmp = ropus_pshr32(
            ROPUS_MULT16_16(coef, oldEBands[i + c * ROPUS_NBANDS]), 8)
            + prev[c] + q * 128;
         tmp = ropus_max32(-((int32_t)28 << (ROPUS_DB_SHIFT + 7)), tmp);
         oldEBands[i + c * ROPUS_NBANDS] = (int16_t)ropus_pshr32(tmp, 7);
         prev[c] = prev[c] + q * 128
            - ROPUS_MULT16_16(beta, ropus_pshr32(q, 8));
      } while (++c < C);
   }
}

static void ropus_unquant_fine_energy_q(int start, int end,
      int16_t *oldEBands, const int *fine_quant, ropus_ec *dec, int C)
{
   int i, c;
   for (i = start; i < end; i++)
   {
      if (fine_quant[i] <= 0)
         continue;
      c = 0;
      do
      {
         int q2 = (int)ropus_ec_dec_bits(dec, fine_quant[i]);
         int16_t offset = (int16_t)(ropus_shr32(
            ((int32_t)q2 << ROPUS_DB_SHIFT) + (1 << (ROPUS_DB_SHIFT - 1)),
            fine_quant[i]) - (1 << (ROPUS_DB_SHIFT - 1)));
         oldEBands[i + c * ROPUS_NBANDS] += offset;
      } while (++c < C);
   }
}

static void ropus_unquant_energy_finalise_q(int start, int end,
      int16_t *oldEBands, const int *fine_quant, const int *fine_priority,
      int bits_left, ropus_ec *dec, int C)
{
   int i, prio, c;
   for (prio = 0; prio < 2; prio++)
   {
      for (i = start; i < end && bits_left >= C; i++)
      {
         if (fine_quant[i] >= ROPUS_MAX_FINE_BITS
               || fine_priority[i] != prio)
            continue;
         c = 0;
         do
         {
            int q2 = (int)ropus_ec_dec_bits(dec, 1);
            int16_t offset = (int16_t)(
               (((int16_t)(q2 << ROPUS_DB_SHIFT))
                - (1 << (ROPUS_DB_SHIFT - 1))) >> (fine_quant[i] + 1));
            oldEBands[i + c * ROPUS_NBANDS] += offset;
            bits_left--;
         } while (++c < C);
      }
   }
}

/* Fixed-point PVQ + band shaping (vq.c / bands.c FIXED_POINT).         */
static int32_t ropus_cwrsi_q(int n, int k, uint32_t i, int *y)
{
   uint32_t p;
   int s, k0;
   int16_t val;
   int32_t yy = 0;
   while (n > 2)
   {
      uint32_t q;
      if (k >= n)
      {
         const uint32_t *row = ropus_pvq_u_row[n];
         p = row[k + 1];
         s = -(i >= p);
         i -= p & s;
         k0 = k;
         q = row[n];
         if (q > i)
         {
            k = n;
            do
               p = ropus_pvq_u_row[--k][n];
            while (p > i);
         }
         else
            for (p = row[k]; p > i; p = row[k])
               k--;
         i -= p;
         val = (k0 - k + s) ^ s;
         *y++ = val;
         yy += ROPUS_MULT16_16(val, val);
      }
      else
      {
         p = ropus_pvq_u_row[k][n];
         q = ropus_pvq_u_row[k + 1][n];
         if (p <= i && i < q)
         {
            i -= p;
            *y++ = 0;
         }
         else
         {
            s = -(i >= q);
            i -= q & s;
            k0 = k;
            do
               p = ropus_pvq_u_row[--k][n];
            while (p > i);
            i -= p;
            val = (k0 - k + s) ^ s;
            *y++ = val;
            yy += ROPUS_MULT16_16(val, val);
         }
      }
      n--;
   }
   p = 2 * k + 1;
   s = -(i >= p);
   i -= p & s;
   k0 = k;
   k = (i + 1) >> 1;
   if (k)
      i -= 2 * k - 1;
   val = (k0 - k + s) ^ s;
   *y++ = val;
   yy += ROPUS_MULT16_16(val, val);
   s = -(int)i;
   val = (k + s) ^ s;
   *y = val;
   yy += ROPUS_MULT16_16(val, val);
   return yy;
}

static int32_t ropus_decode_pulses_q(int *y, int n, int k, ropus_ec *dec)
{
   return ropus_cwrsi_q(n, k, ropus_ec_dec_uint(dec, ROPUS_PVQ_V(n, k)), y);
}

static void ropus_normalise_residual_q(const int *iy, ropus_norm *X,
      int N, int32_t Ryy, int16_t gain)
{
   int i, k;
   int32_t t;
   int16_t g;
   k = ropus_celt_ilog2(Ryy) >> 1;
   t = ropus_vshr32(Ryy, 2 * (k - 7));
   g = (int16_t)ROPUS_MULT16_16_P15(ropus_celt_rsqrt_norm_q(t), gain);
   i = 0;
   do
      X[i] = (ropus_norm)ropus_pshr32(ROPUS_MULT16_16(g, iy[i]), k + 1);
   while (++i < N);
}

static void ropus_exp_rotation1_q(ropus_norm *X, int len, int stride,
      int16_t c, int16_t s)
{
   int i;
   int16_t ms = (int16_t)-s;
   ropus_norm *Xptr = X;
   for (i = 0; i < len - stride; i++)
   {
      ropus_norm x1 = Xptr[0];
      ropus_norm x2 = Xptr[stride];
      Xptr[stride] = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(c, x2) + ROPUS_MULT16_16(s, x1), 15);
      *Xptr++ = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(c, x1) + ROPUS_MULT16_16(ms, x2), 15);
   }
   Xptr = &X[len - 2 * stride - 1];
   for (i = len - 2 * stride - 1; i >= 0; i--)
   {
      ropus_norm x1 = Xptr[0];
      ropus_norm x2 = Xptr[stride];
      Xptr[stride] = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(c, x2) + ROPUS_MULT16_16(s, x1), 15);
      *Xptr-- = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(c, x1) + ROPUS_MULT16_16(ms, x2), 15);
   }
}

static void ropus_exp_rotation_q(ropus_norm *X, int len, int dir,
      int stride, int K, int spread)
{
   static const int SPREAD_FACTOR[3] = { 15, 10, 5 };
   int i, stride2 = 0, factor;
   int16_t c, s, theta;
   int32_t gain;
   if (2 * K >= len || spread == 0)
      return;
   factor = SPREAD_FACTOR[spread - 1];
   gain = ROPUS_CELT_DIV_Q(ROPUS_MULT16_16(32767, len),
      (int32_t)(len + factor * K));
   theta = (int16_t)(ROPUS_MULT16_16_Q15(gain, gain) >> 1);
   c = ropus_celt_cos_norm_q((int32_t)theta);
   s = ropus_celt_cos_norm_q((int32_t)(int16_t)(32767 - theta));
   if (len >= 8 * stride)
   {
      stride2 = 1;
      while ((stride2 * stride2 + stride2) * stride + (stride >> 2) < len)
         stride2++;
   }
   len = (int)((uint32_t)len / stride);
   for (i = 0; i < stride; i++)
   {
      if (dir < 0)
      {
         if (stride2)
            ropus_exp_rotation1_q(X + i * len, len, stride2, s, c);
         ropus_exp_rotation1_q(X + i * len, len, 1, c, s);
      }
      else
      {
         ropus_exp_rotation1_q(X + i * len, len, 1, c, (int16_t)-s);
         if (stride2)
            ropus_exp_rotation1_q(X + i * len, len, stride2, s,
               (int16_t)-c);
      }
   }
}

static void ropus_renormalise_vector_q(ropus_norm *X, int N, int16_t gain)
{
   int i, k;
   int32_t E = 1, t;
   int16_t g;
   ropus_norm *xptr;
   for (i = 0; i < N; i++)
      E += ROPUS_MULT16_16(X[i], X[i]);
   k = ropus_celt_ilog2(E) >> 1;
   t = ropus_vshr32(E, 2 * (k - 7));
   g = (int16_t)ROPUS_MULT16_16_P15(ropus_celt_rsqrt_norm_q(t), gain);
   xptr = X;
   for (i = 0; i < N; i++)
   {
      *xptr = (ropus_norm)ropus_pshr32(ROPUS_MULT16_16(g, *xptr), k + 1);
      xptr++;
   }
}

static unsigned ropus_alg_unquant_q(ropus_norm *X, int N, int K,
      int spread, int B, ropus_ec *dec, int16_t gain)
{
   int32_t Ryy;
   unsigned collapse_mask;
   int iy[176];
   Ryy = ropus_decode_pulses_q(iy, N, K, dec);
   ropus_normalise_residual_q(iy, X, N, Ryy, gain);
   ropus_exp_rotation_q(X, N, -1, B, K, spread);
   collapse_mask = ropus_extract_collapse_mask(iy, N, B);
   return collapse_mask;
}

static void ropus_haar1_q(ropus_norm *X, int N0, int stride)
{
   int i, j;
   N0 >>= 1;
   for (i = 0; i < stride; i++)
      for (j = 0; j < N0; j++)
      {
         int32_t tmp1 = ROPUS_MULT16_16(23170, X[stride * 2 * j + i]);
         int32_t tmp2 = ROPUS_MULT16_16(23170, X[stride * (2 * j + 1) + i]);
         X[stride * 2 * j + i] = (ropus_norm)ropus_pshr32(tmp1 + tmp2, 15);
         X[stride * (2 * j + 1) + i] =
            (ropus_norm)ropus_pshr32(tmp1 - tmp2, 15);
      }
}

static void ropus_deinterleave_hadamard_q(ropus_norm *tmp, ropus_norm *X,
      int N0, int stride, int hadamard)
{
   int i, j, N = N0 * stride;
   if (hadamard)
   {
      const int *ordery = ropus_ordery_table + stride - 2;
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[ordery[i] * N0 + j] = X[j * stride + i];
   }
   else
   {
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[i * N0 + j] = X[j * stride + i];
   }
   memcpy(X, tmp, N * sizeof(*X));
}

static void ropus_interleave_hadamard_q(ropus_norm *tmp, ropus_norm *X,
      int N0, int stride, int hadamard)
{
   int i, j, N = N0 * stride;
   if (hadamard)
   {
      const int *ordery = ropus_ordery_table + stride - 2;
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[j * stride + i] = X[ordery[i] * N0 + j];
   }
   else
   {
      for (i = 0; i < stride; i++)
         for (j = 0; j < N0; j++)
            tmp[j * stride + i] = X[i * N0 + j];
   }
   memcpy(X, tmp, N * sizeof(*X));
}

static void ropus_stereo_merge_q(ropus_norm *X, ropus_norm *Y,
      int16_t mid, int N)
{
   int j, kl, kr;
   int32_t xp = 0, side = 0;
   int32_t El, Er, t, lgain, rgain;
   int16_t mid2;
   for (j = 0; j < N; j++)
   {
      xp += ROPUS_MULT16_16(Y[j], X[j]);
      side += ROPUS_MULT16_16(Y[j], Y[j]);
   }
   xp = ROPUS_MULT16_32_Q15(mid, xp);
   mid2 = (int16_t)(mid >> 1);
   El = ROPUS_MULT16_16(mid2, mid2) + side - 2 * xp;
   Er = ROPUS_MULT16_16(mid2, mid2) + side + 2 * xp;
   if (Er < 161061 || El < 161061)
   {
      memcpy(Y, X, N * sizeof(*Y));
      return;
   }
   kl = ropus_celt_ilog2(El) >> 1;
   kr = ropus_celt_ilog2(Er) >> 1;
   t = ropus_vshr32(El, (kl - 7) << 1);
   lgain = ropus_celt_rsqrt_norm_q(t);
   t = ropus_vshr32(Er, (kr - 7) << 1);
   rgain = ropus_celt_rsqrt_norm_q(t);
   if (kl < 7)
      kl = 7;
   if (kr < 7)
      kr = 7;
   for (j = 0; j < N; j++)
   {
      ropus_norm r, l;
      l = (ropus_norm)ROPUS_MULT16_16_P15(mid, X[j]);
      r = Y[j];
      X[j] = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(lgain, (int16_t)(l - r)), kl + 1);
      Y[j] = (ropus_norm)ropus_pshr32(
         ROPUS_MULT16_16(rgain, (int16_t)(l + r)), kr + 1);
   }
}

/* Fixed-point band decode: identical control flow to the float
 * machinery above; only the sample arithmetic differs.                 */
static unsigned ropus_quant_band_q(ropus_band_ctx *ctx, ropus_norm *X,
      int N, int b, int B, ropus_norm *lowband, int LM,
      ropus_norm *lowband_out, int16_t gain, ropus_norm *lowband_scratch,
      int fill);

static unsigned ropus_quant_band_n1_q(ropus_band_ctx *ctx, ropus_norm *X,
      ropus_norm *Y, ropus_norm *lowband_out)
{
   int c, stereo;
   ropus_norm *x = X;
   ropus_ec *ec = ctx->ec;
   stereo = Y != NULL;
   c = 0;
   do
   {
      int sign = 0;
      if (ctx->remaining_bits >= 1 << ROPUS_BITRES)
      {
         sign = (int)ropus_ec_dec_bits(ec, 1);
         ctx->remaining_bits -= 1 << ROPUS_BITRES;
      }
      x[0] = sign ? -16384 : 16384;
      x = Y;
   } while (++c < 1 + stereo);
   if (lowband_out)
      lowband_out[0] = (ropus_norm)(X[0] >> 4);
   return 1;
}

static unsigned ropus_quant_partition_q(ropus_band_ctx *ctx, ropus_norm *X,
      int N, int b, int B, ropus_norm *lowband, int LM, int16_t gain,
      int fill)
{
   const uint8_t *cache;
   int q, curr_bits;
   int imid = 0, iside = 0;
   int rp_B0 = B;
   int16_t mid = 0, side = 0;
   unsigned cm = 0;
   ropus_norm *Y = NULL;
   int i = ctx->i;
   int spread = ctx->spread;
   ropus_ec *ec = ctx->ec;

   cache = ropus_cache_bits50
      + ropus_cache_index50[(LM + 1) * ROPUS_NBANDS + i];
   if (LM != -1 && b > cache[cache[0]] + 12 && N > 2)
   {
      int mbits, sbits, delta, itheta, qalloc;
      ropus_split_ctx sctx;
      ropus_norm *next_lowband2 = NULL;
      int32_t rebalance;
      N >>= 1;
      Y = X + N;
      LM -= 1;
      if (B == 1)
         fill = (fill & 1) | (fill << 1);
      B = (B + 1) >> 1;
      ropus_compute_theta(ctx, &sctx, NULL, NULL, N, &b, B, rp_B0, LM,
         0, &fill);
      imid = sctx.imid;
      iside = sctx.iside;
      delta = sctx.delta;
      itheta = sctx.itheta;
      qalloc = sctx.qalloc;
      mid = (int16_t)imid;
      side = (int16_t)iside;
      if (rp_B0 > 1 && (itheta & 0x3fff))
      {
         if (itheta > 8192)
            delta -= delta >> (4 - LM);
         else
            delta = ropus_imin(0,
               delta + (N << ROPUS_BITRES >> (5 - LM)));
      }
      mbits = ropus_imax(0, ropus_imin(b, (b - delta) / 2));
      sbits = b - mbits;
      ctx->remaining_bits -= qalloc;
      if (lowband)
         next_lowband2 = lowband + N;
      rebalance = ctx->remaining_bits;
      if (mbits >= sbits)
      {
         cm = ropus_quant_partition_q(ctx, X, N, mbits, B, lowband, LM,
            (int16_t)ROPUS_MULT16_16_P15(gain, mid), fill);
         rebalance = mbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 0)
            sbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_partition_q(ctx, Y, N, sbits, B, next_lowband2,
            LM, (int16_t)ROPUS_MULT16_16_P15(gain, side), fill >> B)
            << (rp_B0 >> 1);
      }
      else
      {
         cm = ropus_quant_partition_q(ctx, Y, N, sbits, B, next_lowband2,
            LM, (int16_t)ROPUS_MULT16_16_P15(gain, side), fill >> B)
            << (rp_B0 >> 1);
         rebalance = sbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 16384)
            mbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_partition_q(ctx, X, N, mbits, B, lowband, LM,
            (int16_t)ROPUS_MULT16_16_P15(gain, mid), fill);
      }
   }
   else
   {
      q = ropus_bits2pulses(i, LM, b);
      curr_bits = ropus_pulses2bits(i, LM, q);
      ctx->remaining_bits -= curr_bits;
      while (ctx->remaining_bits < 0 && q > 0)
      {
         ctx->remaining_bits += curr_bits;
         q--;
         curr_bits = ropus_pulses2bits(i, LM, q);
         ctx->remaining_bits -= curr_bits;
      }
      if (q != 0)
      {
         int K = ropus_get_pulses(q);
         cm = ropus_alg_unquant_q(X, N, K, spread, B, ec, gain);
      }
      else
      {
         int j;
         unsigned cm_mask = (unsigned)(1UL << B) - 1;
         fill &= cm_mask;
         if (!fill)
            memset(X, 0, N * sizeof(*X));
         else
         {
            if (lowband == NULL)
            {
               for (j = 0; j < N; j++)
               {
                  ctx->seed = ropus_lcg_rand(ctx->seed);
                  X[j] = (ropus_norm)((int32_t)ctx->seed >> 20);
               }
               cm = cm_mask;
            }
            else
            {
               for (j = 0; j < N; j++)
               {
                  int16_t tmp;
                  ctx->seed = ropus_lcg_rand(ctx->seed);
                  tmp = 4;             /* QCONST16(1/256., 10)          */
                  tmp = (ctx->seed) & 0x8000 ? tmp : (int16_t)-tmp;
                  X[j] = (ropus_norm)(lowband[j] + tmp);
               }
               cm = fill;
            }
            ropus_renormalise_vector_q(X, N, gain);
         }
      }
   }
   return cm;
}

static unsigned ropus_quant_band_q(ropus_band_ctx *ctx, ropus_norm *X,
      int N, int b, int B, ropus_norm *lowband, int LM,
      ropus_norm *lowband_out, int16_t gain, ropus_norm *lowband_scratch,
      int fill)
{
   int N0 = N;
   int N_B = N;
   int N_B0;
   int rp_B0 = B;
   int time_divide = 0;
   int recombine = 0;
   int longBlocks;
   unsigned cm = 0;
   int k, tf_change;
   tf_change = ctx->tf_change;
   longBlocks = rp_B0 == 1;
   N_B = (int)((uint32_t)N_B / B);
   if (N == 1)
      return ropus_quant_band_n1_q(ctx, X, NULL, lowband_out);
   if (tf_change > 0)
      recombine = tf_change;
   if (lowband_scratch && lowband
         && (recombine || ((N_B & 1) == 0 && tf_change < 0) || rp_B0 > 1))
   {
      memcpy(lowband_scratch, lowband, N * sizeof(*lowband));
      lowband = lowband_scratch;
   }
   for (k = 0; k < recombine; k++)
   {
      static const uint8_t bit_interleave_table[16] =
         { 0, 1, 1, 1, 2, 3, 3, 3, 2, 3, 3, 3, 2, 3, 3, 3 };
      if (lowband)
         ropus_haar1_q(lowband, N >> k, 1 << k);
      fill = bit_interleave_table[fill & 0xF]
         | bit_interleave_table[fill >> 4] << 2;
   }
   B >>= recombine;
   N_B <<= recombine;
   while ((N_B & 1) == 0 && tf_change < 0)
   {
      if (lowband)
         ropus_haar1_q(lowband, N_B, B);
      fill |= fill << B;
      B <<= 1;
      N_B >>= 1;
      time_divide++;
      tf_change++;
   }
   rp_B0 = B;
   N_B0 = N_B;
   if (rp_B0 > 1 && lowband)
      ropus_deinterleave_hadamard_q(ctx->had_q, lowband,
         N_B >> recombine, rp_B0 << recombine, longBlocks);

   cm = ropus_quant_partition_q(ctx, X, N, b, B, lowband, LM, gain, fill);

   if (rp_B0 > 1)
      ropus_interleave_hadamard_q(ctx->had_q, X, N_B >> recombine,
         rp_B0 << recombine, longBlocks);
   N_B = N_B0;
   B = rp_B0;
   for (k = 0; k < time_divide; k++)
   {
      B >>= 1;
      N_B <<= 1;
      cm |= cm >> B;
      ropus_haar1_q(X, N_B, B);
   }
   for (k = 0; k < recombine; k++)
   {
      static const uint8_t bit_deinterleave_table[16] =
      {
         0x00, 0x03, 0x0C, 0x0F, 0x30, 0x33, 0x3C, 0x3F,
         0xC0, 0xC3, 0xCC, 0xCF, 0xF0, 0xF3, 0xFC, 0xFF
      };
      cm = bit_deinterleave_table[cm];
      ropus_haar1_q(X, N0 >> k, 1 << k);
   }
   B <<= recombine;
   if (lowband_out)
   {
      int j;
      int16_t n = (int16_t)ropus_celt_sqrt_q((int32_t)N0 << 22);
      for (j = 0; j < N0; j++)
         lowband_out[j] = (ropus_norm)ROPUS_MULT16_16_Q15(n, X[j]);
   }
   cm &= (1 << B) - 1;
   return cm;
}

static unsigned ropus_quant_band_stereo_q(ropus_band_ctx *ctx,
      ropus_norm *X, ropus_norm *Y, int N, int b, int B,
      ropus_norm *lowband, int LM, ropus_norm *lowband_out,
      ropus_norm *lowband_scratch, int fill)
{
   int imid = 0, iside = 0;
   int inv = 0;
   int16_t mid = 0, side = 0;
   unsigned cm = 0;
   int mbits, sbits, delta, itheta, qalloc;
   ropus_split_ctx sctx;
   int orig_fill;
   ropus_ec *ec = ctx->ec;

   if (N == 1)
      return ropus_quant_band_n1_q(ctx, X, Y, lowband_out);
   orig_fill = fill;
   ropus_compute_theta(ctx, &sctx, NULL, NULL, N, &b, B, B, LM, 1, &fill);
   inv = sctx.inv;
   imid = sctx.imid;
   iside = sctx.iside;
   delta = sctx.delta;
   itheta = sctx.itheta;
   qalloc = sctx.qalloc;
   mid = (int16_t)imid;
   side = (int16_t)iside;

   if (N == 2)
   {
      int c, sign = 0;
      ropus_norm *x2, *y2;
      mbits = b;
      sbits = 0;
      if (itheta != 0 && itheta != 16384)
         sbits = 1 << ROPUS_BITRES;
      mbits -= sbits;
      c = itheta > 8192;
      ctx->remaining_bits -= qalloc + sbits;
      x2 = c ? Y : X;
      y2 = c ? X : Y;
      if (sbits)
         sign = (int)ropus_ec_dec_bits(ec, 1);
      sign = 1 - 2 * sign;
      cm = ropus_quant_band_q(ctx, x2, N, mbits, B, lowband, LM,
         lowband_out, 32767, lowband_scratch, orig_fill);
      y2[0] = (ropus_norm)(-sign * x2[1]);
      y2[1] = (ropus_norm)(sign * x2[0]);
      {
         ropus_norm tmp;
         X[0] = (ropus_norm)ROPUS_MULT16_16_Q15(mid, X[0]);
         X[1] = (ropus_norm)ROPUS_MULT16_16_Q15(mid, X[1]);
         Y[0] = (ropus_norm)ROPUS_MULT16_16_Q15(side, Y[0]);
         Y[1] = (ropus_norm)ROPUS_MULT16_16_Q15(side, Y[1]);
         tmp = X[0];
         X[0] = (ropus_norm)(tmp - Y[0]);
         Y[0] = (ropus_norm)(tmp + Y[0]);
         tmp = X[1];
         X[1] = (ropus_norm)(tmp - Y[1]);
         Y[1] = (ropus_norm)(tmp + Y[1]);
      }
   }
   else
   {
      int32_t rebalance;
      mbits = ropus_imax(0, ropus_imin(b, (b - delta) / 2));
      sbits = b - mbits;
      ctx->remaining_bits -= qalloc;
      rebalance = ctx->remaining_bits;
      if (mbits >= sbits)
      {
         cm = ropus_quant_band_q(ctx, X, N, mbits, B, lowband, LM,
            lowband_out, 32767, lowband_scratch, fill);
         rebalance = mbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 0)
            sbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_band_q(ctx, Y, N, sbits, B, NULL, LM, NULL,
            side, NULL, fill >> B);
      }
      else
      {
         cm = ropus_quant_band_q(ctx, Y, N, sbits, B, NULL, LM, NULL,
            side, NULL, fill >> B);
         rebalance = sbits - (rebalance - ctx->remaining_bits);
         if (rebalance > 3 << ROPUS_BITRES && itheta != 16384)
            mbits += rebalance - (3 << ROPUS_BITRES);
         cm |= ropus_quant_band_q(ctx, X, N, mbits, B, lowband, LM,
            lowband_out, 32767, lowband_scratch, fill);
      }
   }
   if (N != 2)
      ropus_stereo_merge_q(X, Y, mid, N);
   if (inv)
   {
      int j;
      for (j = 0; j < N; j++)
         Y[j] = (ropus_norm)-Y[j];
   }
   return cm;
}

static void ropus_special_hybrid_folding_q(ropus_norm *norm,
      ropus_norm *norm2, int start, int M, int dual_stereo)
{
   int n1, n2;
   const int16_t *eBands = ropus_eband5ms;
   n1 = M * (eBands[start + 1] - eBands[start]);
   n2 = M * (eBands[start + 2] - eBands[start + 1]);
   memmove(&norm[n1], &norm[2 * n1 - n2], (n2 - n1) * sizeof(*norm));
   if (dual_stereo)
      memmove(&norm2[n1], &norm2[2 * n1 - n2],
         (n2 - n1) * sizeof(*norm2));
}

static void ropus_quant_all_bands_q(int start, int end, ropus_norm *X_,
      ropus_norm *Y_, uint8_t *collapse_masks, const int *pulses,
      int shortBlocks, int spread, int dual_stereo, int intensity,
      const int *tf_res, int32_t total_bits, int32_t balance,
      ropus_ec *ec, int LM, int codedBands, uint32_t *seed,
      int disable_inv, ropus_norm *_norm, ropus_norm *_had)
{
   int i;
   int32_t remaining_bits;
   const int16_t *eBands = ropus_eband5ms;
   ropus_norm *norm, *norm2;
   ropus_norm *lowband_scratch;
   int B, M, lowband_offset;
   int update_lowband = 1;
   int C = Y_ != NULL ? 2 : 1;
   int norm_offset;
   ropus_band_ctx ctx;

   M = 1 << LM;
   B = shortBlocks ? M : 1;
   norm_offset = M * eBands[start];
   norm = _norm;
   norm2 = norm + M * eBands[ROPUS_NBANDS - 1] - norm_offset;
   lowband_scratch = X_ + M * eBands[ROPUS_NBANDS - 1];

   lowband_offset = 0;
   ctx.ec = ec;
   ctx.intensity = intensity;
   ctx.seed = *seed;
   ctx.spread = spread;
   ctx.disable_inv = disable_inv;
   ctx.had_f = NULL;
   ctx.had_q = _had;
   ctx.avoid_split_noise = B > 1;
   for (i = start; i < end; i++)
   {
      int32_t tell;
      int b, N;
      int32_t curr_balance;
      int effective_lowband = -1;
      ropus_norm *X, *Y;
      int tf_change = 0;
      unsigned x_cm, y_cm;
      int last;

      ctx.i = i;
      last = (i == end - 1);
      X = X_ + M * eBands[i];
      if (Y_ != NULL)
         Y = Y_ + M * eBands[i];
      else
         Y = NULL;
      N = M * eBands[i + 1] - M * eBands[i];
      tell = (int32_t)ropus_ec_tell_frac(ec);
      if (i != start)
         balance -= tell;
      remaining_bits = total_bits - tell - 1;
      ctx.remaining_bits = remaining_bits;
      if (i <= codedBands - 1)
      {
         curr_balance = balance / ropus_imin(3, codedBands - i);
         b = ropus_imax(0, ropus_imin(16383,
            ropus_imin(remaining_bits + 1, pulses[i] + curr_balance)));
      }
      else
         b = 0;

      if ((M * eBands[i] - N >= M * eBands[start] || i == start + 1)
            && (update_lowband || lowband_offset == 0))
         lowband_offset = i;
      if (i == start + 1)
         ropus_special_hybrid_folding_q(norm, norm2, start, M,
            dual_stereo);

      tf_change = tf_res[i];
      ctx.tf_change = tf_change;
      if (last)
         lowband_scratch = NULL;

      if (lowband_offset != 0
            && (spread != 3 || B > 1 || tf_change < 0))
      {
         int fold_start, fold_end, fold_i;
         effective_lowband = ropus_imax(0,
            M * eBands[lowband_offset] - norm_offset - N);
         fold_start = lowband_offset;
         while (M * eBands[--fold_start] > effective_lowband + norm_offset)
            ;
         fold_end = lowband_offset - 1;
         while (++fold_end < i
               && M * eBands[fold_end] < effective_lowband + norm_offset + N)
            ;
         x_cm = y_cm = 0;
         fold_i = fold_start;
         do
         {
            x_cm |= collapse_masks[fold_i * C + 0];
            y_cm |= collapse_masks[fold_i * C + C - 1];
         } while (++fold_i < fold_end);
      }
      else
         x_cm = y_cm = (1 << B) - 1;

      if (dual_stereo && i == intensity)
      {
         int j;
         dual_stereo = 0;
         for (j = 0; j < M * eBands[i] - norm_offset; j++)
            norm[j] = (ropus_norm)((norm[j] + norm2[j]) >> 1);
      }
      if (dual_stereo)
      {
         x_cm = ropus_quant_band_q(&ctx, X, N, b / 2, B,
            effective_lowband != -1 ? norm + effective_lowband : NULL, LM,
            last ? NULL : norm + M * eBands[i] - norm_offset, 32767,
            lowband_scratch, x_cm);
         y_cm = ropus_quant_band_q(&ctx, Y, N, b / 2, B,
            effective_lowband != -1 ? norm2 + effective_lowband : NULL, LM,
            last ? NULL : norm2 + M * eBands[i] - norm_offset, 32767,
            lowband_scratch, y_cm);
      }
      else
      {
         if (Y != NULL)
            x_cm = ropus_quant_band_stereo_q(&ctx, X, Y, N, b, B,
               effective_lowband != -1 ? norm + effective_lowband : NULL,
               LM, last ? NULL : norm + M * eBands[i] - norm_offset,
               lowband_scratch, x_cm | y_cm);
         else
            x_cm = ropus_quant_band_q(&ctx, X, N, b, B,
               effective_lowband != -1 ? norm + effective_lowband : NULL,
               LM, last ? NULL : norm + M * eBands[i] - norm_offset,
               32767, lowband_scratch, x_cm | y_cm);
         y_cm = x_cm;
      }
      collapse_masks[i * C + 0] = (uint8_t)x_cm;
      collapse_masks[i * C + C - 1] = (uint8_t)y_cm;
      balance += pulses[i] + tell;
      update_lowband = b > (N << ROPUS_BITRES);
      ctx.avoid_split_noise = 0;
   }
   *seed = ctx.seed;
}

/* Fixed-point synthesis.                                               */
#define ROPUS_SATURATE16(x) \
   ((int16_t)((x) > 32767 ? 32767 : (x) < -32768 ? -32768 : (x)))
#define ROPUS_PREEMPH_COEF0_Q 27853  /* QCONST16(.85000610f, 15)        */

static const int8_t ropus_e_means_q[25] =
{
   103, 100, 92, 85, 81,
    77,  72, 70, 78, 75,
    73,  71, 78, 74, 69,
    72,  70, 74, 76, 71,
    60,  60, 60, 60, 60
};

static void ropus_denormalise_bands_q(const ropus_norm *X, ropus_sig *freq,
      const int16_t *bandLogE, int start, int end, int M, int silence)
{
   int i, N, bound;
   ropus_sig *f;
   const ropus_norm *x;
   const int16_t *eBands = ropus_eband5ms;
   N = M * ROPUS_SHORT_MDCT;
   bound = M * eBands[end];
   if (silence)
   {
      bound = 0;
      start = end = 0;
   }
   f = freq;
   x = X + M * eBands[start];
   for (i = 0; i < M * eBands[start]; i++)
      *f++ = 0;
   for (i = start; i < end; i++)
   {
      int j, band_end, shift;
      int16_t g, lg;
      j = M * eBands[i];
      band_end = M * eBands[i + 1];
      lg = ROPUS_SATURATE16((int32_t)bandLogE[i]
         + ((int32_t)ropus_e_means_q[i] << 6));
      shift = 16 - (lg >> ROPUS_DB_SHIFT);
      if (shift > 31)
      {
         shift = 0;
         g = 0;
      }
      else
         g = (int16_t)ropus_celt_exp2_frac_q(
            (int16_t)(lg & ((1 << ROPUS_DB_SHIFT) - 1)));
      if (shift < 0)
      {
         if (shift <= -2)
         {
            g = 16384;
            shift = -2;
         }
         do
            *f++ = (int32_t)((uint32_t)ROPUS_MULT16_16(*x++, g)
               << -shift);
         while (++j < band_end);
      }
      else
         do
            *f++ = ROPUS_MULT16_16(*x++, g) >> shift;
         while (++j < band_end);
   }
   memset(&freq[bound], 0, (N - bound) * sizeof(*freq));
}

static void ropus_anti_collapse_q(ropus_norm *X_,
      const uint8_t *collapse_masks, int LM, int C, int size, int start,
      int end, const int16_t *logE, const int16_t *prev1logE,
      const int16_t *prev2logE, const int *pulses, uint32_t seed)
{
   int c, i, j, k;
   for (i = start; i < end; i++)
   {
      int N0, depth, shift;
      int16_t thresh, sqrt_1;
      int32_t thresh32, t;
      N0 = ropus_eband5ms[i + 1] - ropus_eband5ms[i];
      depth = (int)((uint32_t)(1 + pulses[i]) / N0) >> LM;
      thresh32 = ropus_celt_exp2_q(
         (int16_t)-(depth << (10 - ROPUS_BITRES))) >> 1;
      thresh = (int16_t)ROPUS_MULT16_32_Q15(16384,
         ropus_min32(32767, thresh32));
      t = N0 << LM;
      shift = ropus_celt_ilog2(t) >> 1;
      t = (int32_t)((uint32_t)t << ((7 - shift) << 1));
      sqrt_1 = ropus_celt_rsqrt_norm_q(t);
      c = 0;
      do
      {
         ropus_norm *X;
         int16_t prev1, prev2, r;
         int32_t Ediff;
         int renormalize = 0;
         prev1 = prev1logE[c * ROPUS_NBANDS + i];
         prev2 = prev2logE[c * ROPUS_NBANDS + i];
         if (C == 1)
         {
            prev1 = ropus_max16(prev1, prev1logE[ROPUS_NBANDS + i]);
            prev2 = ropus_max16(prev2, prev2logE[ROPUS_NBANDS + i]);
         }
         Ediff = (int32_t)logE[c * ROPUS_NBANDS + i]
            - (int32_t)ropus_min16(prev1, prev2);
         Ediff = ropus_max32(0, Ediff);
         if (Ediff < 16384)
         {
            int32_t r32 = ropus_celt_exp2_q((int16_t)-Ediff) >> 1;
            r = (int16_t)(2 * ropus_min32(16383, r32));
         }
         else
            r = 0;
         if (LM == 3)
            r = (int16_t)ROPUS_MULT16_16_Q14(23170,
               ropus_min32(23169, r));
         r = (int16_t)(ropus_min16(thresh, r) >> 1);
         r = (int16_t)(ROPUS_MULT16_16_Q15(sqrt_1, r) >> shift);
         X = X_ + c * size + (ropus_eband5ms[i] << LM);
         for (k = 0; k < 1 << LM; k++)
         {
            if (!(collapse_masks[i * C + c] & 1 << k))
            {
               for (j = 0; j < N0; j++)
               {
                  seed = ropus_lcg_rand(seed);
                  X[(j << LM) + k] = (seed & 0x8000
                     ? r : (ropus_norm)-r);
               }
               renormalize = 1;
            }
         }
         if (renormalize)
            ropus_renormalise_vector_q(X, N0 << LM, 32767);
      } while (++c < C);
   }
}

/* Fixed kiss FFT: int32 data, Q15 twiddles, wrapping adds.             */
#define ROPUS_S_MUL_Q(a, b) ROPUS_MULT16_32_Q15(b, a)
#define ROPUS_C_MUL_Q(m, a, b) \
   do { (m).r = ROPUS_SUB32_OVF(ROPUS_S_MUL_Q((a).r, (b).r), \
                                ROPUS_S_MUL_Q((a).i, (b).i)); \
        (m).i = ROPUS_ADD32_OVF(ROPUS_S_MUL_Q((a).r, (b).i), \
                                ROPUS_S_MUL_Q((a).i, (b).r)); } while (0)
#define ROPUS_C_ADD_Q(res, a, b) \
   do { (res).r = ROPUS_ADD32_OVF((a).r, (b).r); \
        (res).i = ROPUS_ADD32_OVF((a).i, (b).i); } while (0)
#define ROPUS_C_SUB_Q(res, a, b) \
   do { (res).r = ROPUS_SUB32_OVF((a).r, (b).r); \
        (res).i = ROPUS_SUB32_OVF((a).i, (b).i); } while (0)
#define ROPUS_C_ADDTO_Q(res, a) \
   do { (res).r = ROPUS_ADD32_OVF((res).r, (a).r); \
        (res).i = ROPUS_ADD32_OVF((res).i, (a).i); } while (0)

typedef struct { int32_t r, i; } ropus_cpx32;

static void ropus_kf_bfly2_q(ropus_cpx32 *Fout, int m, int N)
{
   ropus_cpx32 *Fout2;
   int i;
   int16_t tw = 23170;   /* QCONST16(0.7071067812f, 15) */
   (void)m;
   for (i = 0; i < N; i++)
   {
      ropus_cpx32 t;
      Fout2 = Fout + 4;
      t = Fout2[0];
      ROPUS_C_SUB_Q(Fout2[0], Fout[0], t);
      ROPUS_C_ADDTO_Q(Fout[0], t);
      t.r = ROPUS_S_MUL_Q(ROPUS_ADD32_OVF(Fout2[1].r, Fout2[1].i), tw);
      t.i = ROPUS_S_MUL_Q(ROPUS_SUB32_OVF(Fout2[1].i, Fout2[1].r), tw);
      ROPUS_C_SUB_Q(Fout2[1], Fout[1], t);
      ROPUS_C_ADDTO_Q(Fout[1], t);
      t.r = Fout2[2].i;
      t.i = ROPUS_NEG32_OVF(Fout2[2].r);
      ROPUS_C_SUB_Q(Fout2[2], Fout[2], t);
      ROPUS_C_ADDTO_Q(Fout[2], t);
      t.r = ROPUS_S_MUL_Q(ROPUS_SUB32_OVF(Fout2[3].i, Fout2[3].r), tw);
      t.i = ROPUS_S_MUL_Q(
         ROPUS_NEG32_OVF(ROPUS_ADD32_OVF(Fout2[3].i, Fout2[3].r)), tw);
      ROPUS_C_SUB_Q(Fout2[3], Fout[3], t);
      ROPUS_C_ADDTO_Q(Fout[3], t);
      Fout += 8;
   }
}

static void ropus_kf_bfly4_q(ropus_cpx32 *Fout, size_t fstride,
      int m, int N, int mm)
{
   int i;
   if (m == 1)
   {
      for (i = 0; i < N; i++)
      {
         ropus_cpx32 scratch0, scratch1;
         ROPUS_C_SUB_Q(scratch0, *Fout, Fout[2]);
         ROPUS_C_ADDTO_Q(*Fout, Fout[2]);
         ROPUS_C_ADD_Q(scratch1, Fout[1], Fout[3]);
         ROPUS_C_SUB_Q(Fout[2], *Fout, scratch1);
         ROPUS_C_ADDTO_Q(*Fout, scratch1);
         ROPUS_C_SUB_Q(scratch1, Fout[1], Fout[3]);
         Fout[1].r = ROPUS_ADD32_OVF(scratch0.r, scratch1.i);
         Fout[1].i = ROPUS_SUB32_OVF(scratch0.i, scratch1.r);
         Fout[3].r = ROPUS_SUB32_OVF(scratch0.r, scratch1.i);
         Fout[3].i = ROPUS_ADD32_OVF(scratch0.i, scratch1.r);
         Fout += 4;
      }
   }
   else
   {
      int j;
      ropus_cpx32 scratch[6];
      const ropus_cpx_q *tw1, *tw2, *tw3;
      const int m2 = 2 * m;
      const int m3 = 3 * m;
      ropus_cpx32 *Fout_beg = Fout;
      for (i = 0; i < N; i++)
      {
         Fout = Fout_beg + i * mm;
         tw3 = tw2 = tw1 = ropus_fft_twiddles_q;
         for (j = 0; j < m; j++)
         {
            ROPUS_C_MUL_Q(scratch[0], Fout[m], *tw1);
            ROPUS_C_MUL_Q(scratch[1], Fout[m2], *tw2);
            ROPUS_C_MUL_Q(scratch[2], Fout[m3], *tw3);
            ROPUS_C_SUB_Q(scratch[5], *Fout, scratch[1]);
            ROPUS_C_ADDTO_Q(*Fout, scratch[1]);
            ROPUS_C_ADD_Q(scratch[3], scratch[0], scratch[2]);
            ROPUS_C_SUB_Q(scratch[4], scratch[0], scratch[2]);
            ROPUS_C_SUB_Q(Fout[m2], *Fout, scratch[3]);
            tw1 += fstride;
            tw2 += fstride * 2;
            tw3 += fstride * 3;
            ROPUS_C_ADDTO_Q(*Fout, scratch[3]);
            Fout[m].r = ROPUS_ADD32_OVF(scratch[5].r, scratch[4].i);
            Fout[m].i = ROPUS_SUB32_OVF(scratch[5].i, scratch[4].r);
            Fout[m3].r = ROPUS_SUB32_OVF(scratch[5].r, scratch[4].i);
            Fout[m3].i = ROPUS_ADD32_OVF(scratch[5].i, scratch[4].r);
            ++Fout;
         }
      }
   }
}

static void ropus_kf_bfly3_q(ropus_cpx32 *Fout, size_t fstride,
      int m, int N, int mm)
{
   int i;
   size_t k;
   const size_t m2 = 2 * m;
   const ropus_cpx_q *tw1, *tw2;
   ropus_cpx32 scratch[5];
   int16_t epi3_i = -28378;
   ropus_cpx32 *Fout_beg = Fout;
   for (i = 0; i < N; i++)
   {
      Fout = Fout_beg + i * mm;
      tw1 = tw2 = ropus_fft_twiddles_q;
      k = m;
      do
      {
         ROPUS_C_MUL_Q(scratch[1], Fout[m], *tw1);
         ROPUS_C_MUL_Q(scratch[2], Fout[m2], *tw2);
         ROPUS_C_ADD_Q(scratch[3], scratch[1], scratch[2]);
         ROPUS_C_SUB_Q(scratch[0], scratch[1], scratch[2]);
         tw1 += fstride;
         tw2 += fstride * 2;
         Fout[m].r = ROPUS_SUB32_OVF(Fout->r, (scratch[3].r >> 1));
         Fout[m].i = ROPUS_SUB32_OVF(Fout->i, (scratch[3].i >> 1));
         scratch[0].r = ROPUS_S_MUL_Q(scratch[0].r, epi3_i);
         scratch[0].i = ROPUS_S_MUL_Q(scratch[0].i, epi3_i);
         ROPUS_C_ADDTO_Q(*Fout, scratch[3]);
         Fout[m2].r = ROPUS_ADD32_OVF(Fout[m].r, scratch[0].i);
         Fout[m2].i = ROPUS_SUB32_OVF(Fout[m].i, scratch[0].r);
         Fout[m].r = ROPUS_SUB32_OVF(Fout[m].r, scratch[0].i);
         Fout[m].i = ROPUS_ADD32_OVF(Fout[m].i, scratch[0].r);
         ++Fout;
      } while (--k);
   }
}

static void ropus_kf_bfly5_q(ropus_cpx32 *Fout, size_t fstride,
      int m, int N, int mm)
{
   ropus_cpx32 *Fout0, *Fout1, *Fout2, *Fout3, *Fout4;
   int i, u;
   ropus_cpx32 scratch[13];
   const ropus_cpx_q *tw;
   ropus_cpx_q ya, yb;
   ropus_cpx32 *Fout_beg = Fout;
   ya.r = 10126;
   ya.i = -31164;
   yb.r = -26510;
   yb.i = -19261;
   tw = ropus_fft_twiddles_q;
   for (i = 0; i < N; i++)
   {
      Fout = Fout_beg + i * mm;
      Fout0 = Fout;
      Fout1 = Fout0 + m;
      Fout2 = Fout0 + 2 * m;
      Fout3 = Fout0 + 3 * m;
      Fout4 = Fout0 + 4 * m;
      for (u = 0; u < m; ++u)
      {
         scratch[0] = *Fout0;
         ROPUS_C_MUL_Q(scratch[1], *Fout1, tw[u * fstride]);
         ROPUS_C_MUL_Q(scratch[2], *Fout2, tw[2 * u * fstride]);
         ROPUS_C_MUL_Q(scratch[3], *Fout3, tw[3 * u * fstride]);
         ROPUS_C_MUL_Q(scratch[4], *Fout4, tw[4 * u * fstride]);
         ROPUS_C_ADD_Q(scratch[7], scratch[1], scratch[4]);
         ROPUS_C_SUB_Q(scratch[10], scratch[1], scratch[4]);
         ROPUS_C_ADD_Q(scratch[8], scratch[2], scratch[3]);
         ROPUS_C_SUB_Q(scratch[9], scratch[2], scratch[3]);
         Fout0->r = ROPUS_ADD32_OVF(Fout0->r,
            ROPUS_ADD32_OVF(scratch[7].r, scratch[8].r));
         Fout0->i = ROPUS_ADD32_OVF(Fout0->i,
            ROPUS_ADD32_OVF(scratch[7].i, scratch[8].i));
         scratch[5].r = ROPUS_ADD32_OVF(scratch[0].r,
            ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(scratch[7].r, ya.r),
                            ROPUS_S_MUL_Q(scratch[8].r, yb.r)));
         scratch[5].i = ROPUS_ADD32_OVF(scratch[0].i,
            ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(scratch[7].i, ya.r),
                            ROPUS_S_MUL_Q(scratch[8].i, yb.r)));
         scratch[6].r = ROPUS_ADD32_OVF(
            ROPUS_S_MUL_Q(scratch[10].i, ya.i),
            ROPUS_S_MUL_Q(scratch[9].i, yb.i));
         scratch[6].i = ROPUS_NEG32_OVF(ROPUS_ADD32_OVF(
            ROPUS_S_MUL_Q(scratch[10].r, ya.i),
            ROPUS_S_MUL_Q(scratch[9].r, yb.i)));
         ROPUS_C_SUB_Q(*Fout1, scratch[5], scratch[6]);
         ROPUS_C_ADD_Q(*Fout4, scratch[5], scratch[6]);
         scratch[11].r = ROPUS_ADD32_OVF(scratch[0].r,
            ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(scratch[7].r, yb.r),
                            ROPUS_S_MUL_Q(scratch[8].r, ya.r)));
         scratch[11].i = ROPUS_ADD32_OVF(scratch[0].i,
            ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(scratch[7].i, yb.r),
                            ROPUS_S_MUL_Q(scratch[8].i, ya.r)));
         scratch[12].r = ROPUS_SUB32_OVF(
            ROPUS_S_MUL_Q(scratch[9].i, ya.i),
            ROPUS_S_MUL_Q(scratch[10].i, yb.i));
         scratch[12].i = ROPUS_SUB32_OVF(
            ROPUS_S_MUL_Q(scratch[10].r, yb.i),
            ROPUS_S_MUL_Q(scratch[9].r, ya.i));
         ROPUS_C_ADD_Q(*Fout2, scratch[11], scratch[12]);
         ROPUS_C_SUB_Q(*Fout3, scratch[11], scratch[12]);
         ++Fout0;
         ++Fout1;
         ++Fout2;
         ++Fout3;
         ++Fout4;
      }
   }
}

static void ropus_fft_impl_q(const ropus_fft_state *st, ropus_cpx32 *fout)
{
   int m2, m, p, L, i;
   int fstride[ROPUS_MAXFACTORS];
   int shift = st->shift > 0 ? st->shift : 0;
   fstride[0] = 1;
   L = 0;
   do
   {
      p = st->factors[2 * L];
      m = st->factors[2 * L + 1];
      fstride[L + 1] = fstride[L] * p;
      L++;
   } while (m != 1);
   m = st->factors[2 * L - 1];
   for (i = L - 1; i >= 0; i--)
   {
      if (i != 0)
         m2 = st->factors[2 * i - 1];
      else
         m2 = 1;
      switch (st->factors[2 * i])
      {
         case 2:
            ropus_kf_bfly2_q(fout, m, fstride[i]);
            break;
         case 4:
            ropus_kf_bfly4_q(fout, fstride[i] << shift, m,
               fstride[i], m2);
            break;
         case 3:
            ropus_kf_bfly3_q(fout, fstride[i] << shift, m,
               fstride[i], m2);
            break;
         case 5:
            ropus_kf_bfly5_q(fout, fstride[i] << shift, m,
               fstride[i], m2);
            break;
      }
      m = m2;
   }
}

static void ropus_mdct_backward_q(const ropus_sig *in, ropus_sig *out,
      const int16_t *window, int overlap, int shift, int stride)
{
   int i;
   int N, N2, N4;
   const int16_t *trig = ropus_mdct_twiddles_q;
   N = 1920;
   for (i = 0; i < shift; i++)
   {
      N >>= 1;
      trig += N;
   }
   N2 = N >> 1;
   N4 = N >> 2;
   {
      const ropus_sig *xp1 = in;
      const ropus_sig *xp2 = in + stride * (N2 - 1);
      ropus_sig *yp = out + (overlap >> 1);
      const int16_t *t = &trig[0];
      const int16_t *bitrev = ropus_fft_states[shift].bitrev;
      for (i = 0; i < N4; i++)
      {
         int rev = *bitrev++;
         ropus_sig yr = ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(*xp2, t[i]),
            ROPUS_S_MUL_Q(*xp1, t[N4 + i]));
         ropus_sig yi = ROPUS_SUB32_OVF(ROPUS_S_MUL_Q(*xp1, t[i]),
            ROPUS_S_MUL_Q(*xp2, t[N4 + i]));
         yp[2 * rev + 1] = yr;
         yp[2 * rev] = yi;
         xp1 += 2 * stride;
         xp2 -= 2 * stride;
      }
   }
   ropus_fft_impl_q(&ropus_fft_states[shift],
      (ropus_cpx32 *)(out + (overlap >> 1)));
   {
      ropus_sig *yp0 = out + (overlap >> 1);
      ropus_sig *yp1 = out + (overlap >> 1) + N2 - 2;
      const int16_t *t = &trig[0];
      for (i = 0; i < (N4 + 1) >> 1; i++)
      {
         ropus_sig re, im, yr, yi;
         int16_t t0, t1;
         re = yp0[1];
         im = yp0[0];
         t0 = t[i];
         t1 = t[N4 + i];
         yr = ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(re, t0),
            ROPUS_S_MUL_Q(im, t1));
         yi = ROPUS_SUB32_OVF(ROPUS_S_MUL_Q(re, t1),
            ROPUS_S_MUL_Q(im, t0));
         re = yp1[1];
         im = yp1[0];
         yp0[0] = yr;
         yp1[1] = yi;
         t0 = t[N4 - i - 1];
         t1 = t[N2 - i - 1];
         yr = ROPUS_ADD32_OVF(ROPUS_S_MUL_Q(re, t0),
            ROPUS_S_MUL_Q(im, t1));
         yi = ROPUS_SUB32_OVF(ROPUS_S_MUL_Q(re, t1),
            ROPUS_S_MUL_Q(im, t0));
         yp1[0] = yr;
         yp0[1] = yi;
         yp0 += 2;
         yp1 -= 2;
      }
   }
   {
      ropus_sig *xp1 = out + overlap - 1;
      ropus_sig *yp1 = out;
      const int16_t *wp1 = window;
      const int16_t *wp2 = window + overlap - 1;
      for (i = 0; i < overlap / 2; i++)
      {
         ropus_sig x1 = *xp1;
         ropus_sig x2 = *yp1;
         *yp1++ = ROPUS_SUB32_OVF(ROPUS_MULT16_32_Q15(*wp2, x2),
            ROPUS_MULT16_32_Q15(*wp1, x1));
         *xp1-- = ROPUS_ADD32_OVF(ROPUS_MULT16_32_Q15(*wp1, x2),
            ROPUS_MULT16_32_Q15(*wp2, x1));
         wp1++;
         wp2--;
      }
   }
}

static void ropus_celt_synthesis_q(const ropus_norm *X, ropus_sig *out_syn[],
      ropus_frame_scratch *scr,
      const int16_t *oldBandE, int start, int effEnd, int C, int CC,
      int isTransient, int LM, int silence)
{
   int c, b;
   int M, B, N, NB, shift;
   ropus_sig *freq = scr->celt.q.freq;
   int i;
   N = ROPUS_SHORT_MDCT << LM;
   M = 1 << LM;
   if (isTransient)
   {
      B = M;
      NB = ROPUS_SHORT_MDCT;
      shift = ROPUS_MAXLM;
   }
   else
   {
      B = 1;
      NB = ROPUS_SHORT_MDCT << LM;
      shift = ROPUS_MAXLM - LM;
   }
   if (CC == 2 && C == 1)
   {
      ropus_sig *freq2 = out_syn[1] + (ROPUS_OVERLAP / 2);
      ropus_denormalise_bands_q(X, freq, oldBandE, start, effEnd, M,
         silence);
      memcpy(freq2, freq, N * sizeof(ropus_sig));
      for (b = 0; b < B; b++)
         ropus_mdct_backward_q(&freq2[b], out_syn[0] + NB * b,
            ropus_window120_q15, ROPUS_OVERLAP, shift, B);
      for (b = 0; b < B; b++)
         ropus_mdct_backward_q(&freq[b], out_syn[1] + NB * b,
            ropus_window120_q15, ROPUS_OVERLAP, shift, B);
   }
   else
   {
      c = 0;
      do
      {
         ropus_denormalise_bands_q(X + c * N, freq,
            oldBandE + c * ROPUS_NBANDS, start, effEnd, M, silence);
         for (b = 0; b < B; b++)
            ropus_mdct_backward_q(&freq[b], out_syn[c] + NB * b,
               ropus_window120_q15, ROPUS_OVERLAP, shift, B);
      } while (++c < CC);
   }
   /* Saturate IMDCT output (fixed pipeline only). */
   c = 0;
   do
   {
      for (i = 0; i < N; i++)
         out_syn[c][i] = ROPUS_SATURATE(out_syn[c][i], ROPUS_SIG_SAT);
   } while (++c < CC);
}

static void ropus_comb_filter_const_q(ropus_sig *y, ropus_sig *x, int T,
      int N, int16_t g10, int16_t g11, int16_t g12)
{
   int i;
   for (i = 0; i < N; i++)
   {
      int32_t t = ROPUS_MAC16_32_Q16(x[i], g10,
         (int32_t)((uint32_t)x[i - T] << 1));
      t = ROPUS_MAC16_32_Q16(t, g11,
         (int32_t)((uint32_t)(x[i - T + 1] + x[i - T - 1]) << 1));
      t = ROPUS_MAC16_32_Q16(t, g12,
         (int32_t)((uint32_t)(x[i - T + 2] + x[i - T - 2]) << 1));
      t = ROPUS_SATURATE(t, ROPUS_SIG_SAT);
      y[i] = t;
   }
}

static void ropus_comb_filter_q(ropus_sig *y, ropus_sig *x, int T0, int T1,
      int N, int16_t g0, int16_t g1, int tapset0, int tapset1,
      const int16_t *window, int overlap)
{
   int i;
   int16_t g00, g01, g02, g10, g11, g12;
   ropus_sig x0, x1, x2, x3, x4;
   static const int16_t gains_q[3][3] =
   {
      { 10048, 7112, 4248 },   /* QCONST16(gains[][], 15)              */
      { 15200, 8784, 0 },
      { 26208, 3280, 0 }
   };
   if (g0 == 0 && g1 == 0)
   {
      if (x != y)
         memmove(y, x, N * sizeof(*y));
      return;
   }
   T0 = ropus_imax(T0, ROPUS_COMBFILTER_MINPERIOD);
   T1 = ropus_imax(T1, ROPUS_COMBFILTER_MINPERIOD);
   g00 = (int16_t)ROPUS_MULT16_16_P15(g0, gains_q[tapset0][0]);
   g01 = (int16_t)ROPUS_MULT16_16_P15(g0, gains_q[tapset0][1]);
   g02 = (int16_t)ROPUS_MULT16_16_P15(g0, gains_q[tapset0][2]);
   g10 = (int16_t)ROPUS_MULT16_16_P15(g1, gains_q[tapset1][0]);
   g11 = (int16_t)ROPUS_MULT16_16_P15(g1, gains_q[tapset1][1]);
   g12 = (int16_t)ROPUS_MULT16_16_P15(g1, gains_q[tapset1][2]);
   x1 = x[-T1 + 1];
   x2 = x[-T1];
   x3 = x[-T1 - 1];
   x4 = x[-T1 - 2];
   if (g0 == g1 && T0 == T1 && tapset0 == tapset1)
      overlap = 0;
   for (i = 0; i < overlap; i++)
   {
      int16_t f;
      int32_t t;
      x0 = x[i - T1 + 2];
      f = (int16_t)ROPUS_MULT16_16_Q15(window[i], window[i]);
      t = x[i]
         + ROPUS_MULT16_32_Q15(
            ROPUS_MULT16_16_Q15((int16_t)(32767 - f), g00), x[i - T0])
         + ROPUS_MULT16_32_Q15(
            ROPUS_MULT16_16_Q15((int16_t)(32767 - f), g01),
            x[i - T0 + 1] + x[i - T0 - 1])
         + ROPUS_MULT16_32_Q15(
            ROPUS_MULT16_16_Q15((int16_t)(32767 - f), g02),
            x[i - T0 + 2] + x[i - T0 - 2])
         + ROPUS_MULT16_32_Q15(ROPUS_MULT16_16_Q15(f, g10), x2)
         + ROPUS_MULT16_32_Q15(ROPUS_MULT16_16_Q15(f, g11), x1 + x3)
         + ROPUS_MULT16_32_Q15(ROPUS_MULT16_16_Q15(f, g12), x0 + x4);
      y[i] = ROPUS_SATURATE(t, ROPUS_SIG_SAT);
      x4 = x3;
      x3 = x2;
      x2 = x1;
      x1 = x0;
   }
   if (g1 == 0)
   {
      if (x != y)
         memmove(y + overlap, x + overlap, (N - overlap) * sizeof(*y));
      return;
   }
   ropus_comb_filter_const_q(y + i, x + i, T1, N - i, g10, g11, g12);
}

static void ropus_deemphasis_q(ropus_sig *in[], int16_t *pcm, int N, int C,
      ropus_sig *mem, int accum)
{
   if (accum)
   {
      int c = 0;
      do
      {
         ropus_sig *x = in[c];
         int16_t *y = pcm + c;
         ropus_sig m = mem[c];
         int j;
         for (j = 0; j < N; j++)
         {
            ropus_sig tmp = x[j] + m;
            m = ROPUS_MULT16_32_Q15(ROPUS_PREEMPH_COEF0_Q, tmp);
            y[j * C] = ROPUS_SAT16((int32_t)y[j * C]
               + ROPUS_SAT16(ropus_pshr32(tmp, ROPUS_SIG_SHIFT)));
         }
         mem[c] = m;
      } while (++c < C);
      return;
   }
   if (C == 2)
   {
      ropus_sig *x0 = in[0];
      ropus_sig *x1 = in[1];
      ropus_sig m0 = mem[0], m1 = mem[1];
      int j;
      for (j = 0; j < N; j++)
      {
         ropus_sig tmp0 = x0[j] + m0;
         ropus_sig tmp1 = x1[j] + m1;
         m0 = ROPUS_MULT16_32_Q15(ROPUS_PREEMPH_COEF0_Q, tmp0);
         m1 = ROPUS_MULT16_32_Q15(ROPUS_PREEMPH_COEF0_Q, tmp1);
         pcm[2 * j] = ROPUS_SAT16(ropus_pshr32(tmp0, ROPUS_SIG_SHIFT));
         pcm[2 * j + 1] =
            ROPUS_SAT16(ropus_pshr32(tmp1, ROPUS_SIG_SHIFT));
      }
      mem[0] = m0;
      mem[1] = m1;
   }
   else
   {
      ropus_sig *x = in[0];
      ropus_sig m = mem[0];
      int j;
      for (j = 0; j < N; j++)
      {
         ropus_sig tmp = x[j] + m;
         m = ROPUS_MULT16_32_Q15(ROPUS_PREEMPH_COEF0_Q, tmp);
         pcm[j] = ROPUS_SAT16(ropus_pshr32(tmp, ROPUS_SIG_SHIFT));
      }
      mem[0] = m;
   }
}

/* Fixed-point CELT decoder state.                                      */
typedef struct
{
   int channels;
   int stream_channels;
   int start, end;
   uint32_t rng;
   int error;
   int postfilter_period, postfilter_period_old;
   int16_t postfilter_gain, postfilter_gain_old;
   int postfilter_tapset, postfilter_tapset_old;
   ropus_sig preemph_memD[2];
   int loss_duration;
   ropus_sig decode_mem[2][ROPUS_DECODE_BUFFER_SIZE + ROPUS_OVERLAP];
   int16_t oldEBands[2 * ROPUS_NBANDS];
   int16_t oldLogE[2 * ROPUS_NBANDS];
   int16_t oldLogE2[2 * ROPUS_NBANDS];
   int16_t backgroundLogE[2 * ROPUS_NBANDS];
} ropus_celt_q;

static void ropus_celt_init_q(ropus_celt_q *st, int channels)
{
   int i;
   memset(st, 0, sizeof(*st));
   st->channels = channels;
   st->stream_channels = channels;
   st->start = 0;
   st->end = ROPUS_NBANDS;
   for (i = 0; i < 2 * ROPUS_NBANDS; i++)
      st->oldLogE[i] = st->oldLogE2[i] = -(28 << ROPUS_DB_SHIFT);
}

/* Fixed front-end: identical symbol flow; fixed energy + Q15 pf gain.  */
static int ropus_celt_front_q(ropus_celt_q *st, ropus_ec *dec, int len,
      int frame_size, ropus_celt_frame *f, int16_t *pf_gain_q)
{
   int i, LM, M, N, spread_decision;
   int32_t total_bits, tell, bits;
   int start = st->start, end = st->end;
   int C = st->stream_channels;
   int dynalloc_logp;
   int16_t pf_gain = 0;

   for (LM = 0; LM <= ROPUS_MAXLM; LM++)
      if (ROPUS_SHORT_MDCT << LM == frame_size)
         break;
   if (LM > ROPUS_MAXLM)
      return -1;
   M = 1 << LM;
   N = M * ROPUS_SHORT_MDCT;

   f->LM = LM;
   f->N = N;
   f->C = C;
   f->CC = st->channels;
   f->effEnd = end;

   total_bits = len * 8;
   tell = ropus_ec_tell(dec);
   if (tell >= total_bits)
      f->silence = 1;
   else if (tell == 1)
      f->silence = ropus_ec_dec_bit_logp(dec, 15);
   else
      f->silence = 0;
   if (f->silence)
   {
      tell = len * 8;
      dec->nbits_total += tell - ropus_ec_tell(dec);
   }

   f->postfilter_pitch = 0;
   f->postfilter_tapset = 0;
   if (start == 0 && tell + 16 <= total_bits)
   {
      if (ropus_ec_dec_bit_logp(dec, 1))
      {
         int qg, octave;
         octave = (int)ropus_ec_dec_uint(dec, 6);
         f->postfilter_pitch = (16 << octave)
            + (int)ropus_ec_dec_bits(dec, 4 + octave) - 1;
         qg = (int)ropus_ec_dec_bits(dec, 3);
         if (ropus_ec_tell(dec) + 2 <= total_bits)
            f->postfilter_tapset =
               ropus_ec_dec_icdf(dec, ropus_tapset_icdf, 2);
         pf_gain = (int16_t)(3072 * (qg + 1));  /* QCONST16(.09375,15) */
      }
      tell = ropus_ec_tell(dec);
   }
   *pf_gain_q = pf_gain;

   if (LM > 0 && tell + 3 <= total_bits)
   {
      f->isTransient = ropus_ec_dec_bit_logp(dec, 3);
      tell = ropus_ec_tell(dec);
   }
   else
      f->isTransient = 0;
   f->shortBlocks = f->isTransient ? M : 0;

   f->intra_ener = tell + 3 <= total_bits
      ? ropus_ec_dec_bit_logp(dec, 3) : 0;

   ropus_unquant_coarse_energy_q(start, end, st->oldEBands,
      f->intra_ener, dec, C, LM);

   ropus_tf_decode(start, end, f->isTransient, f->tf_res, LM, dec);

   tell = ropus_ec_tell(dec);
   spread_decision = 2;
   if (tell + 4 <= total_bits)
      spread_decision = ropus_ec_dec_icdf(dec, ropus_spread_icdf, 5);
   f->spread_decision = spread_decision;

   ropus_init_caps(f->cap, LM, C);

   dynalloc_logp = 6;
   total_bits <<= ROPUS_BITRES;
   tell = ropus_ec_tell_frac(dec);
   for (i = start; i < end; i++)
   {
      int width, quanta, dynalloc_loop_logp, boost;
      width = C * (ropus_eband5ms[i + 1] - ropus_eband5ms[i]) << LM;
      quanta = ropus_imin(width << ROPUS_BITRES,
         ropus_imax(6 << ROPUS_BITRES, width));
      dynalloc_loop_logp = dynalloc_logp;
      boost = 0;
      while (tell + (dynalloc_loop_logp << ROPUS_BITRES) < total_bits
            && boost < f->cap[i])
      {
         int flag = ropus_ec_dec_bit_logp(dec, dynalloc_loop_logp);
         tell = ropus_ec_tell_frac(dec);
         if (!flag)
            break;
         boost += quanta;
         total_bits -= quanta;
         dynalloc_loop_logp = 1;
      }
      f->offsets[i] = boost;
      if (boost > 0)
         dynalloc_logp = ropus_imax(2, dynalloc_logp - 1);
   }

   f->alloc_trim = tell + (6 << ROPUS_BITRES) <= total_bits
      ? ropus_ec_dec_icdf(dec, ropus_trim_icdf, 7) : 5;

   bits = (((int32_t)len * 8) << ROPUS_BITRES)
      - (int32_t)ropus_ec_tell_frac(dec) - 1;
   f->anti_collapse_rsv = f->isTransient && LM >= 2
      && bits >= ((LM + 2) << ROPUS_BITRES) ? (1 << ROPUS_BITRES) : 0;
   bits -= f->anti_collapse_rsv;

   f->codedBands = ropus_compute_allocation(start, end, f->offsets,
      f->cap, f->alloc_trim, &f->intensity, &f->dual_stereo, bits,
      &f->balance, f->pulses, f->fine_quant, f->fine_priority, C, LM, dec);

   ropus_unquant_fine_energy_q(start, end, st->oldEBands,
      f->fine_quant, dec, C);
   return 0;
}

/* Master fixed-point decode: s16 PCM out.                              */
static int ropus_celt_decode_q(ropus_celt_q *st,
      ropus_frame_scratch *scr, const uint8_t *data,
      int len, int16_t *pcm, int frame_size, ropus_ec *dec, int accum)
{
   int c, i, N, CC = st->channels, C = st->stream_channels;
   int start = st->start, end = st->end;

   ropus_celt_frame f;
   int16_t pf_gain = 0;
   ropus_sig *decode_mem[2];
   ropus_sig *out_syn[2];
   int16_t *oldBandE, *oldLogE, *oldLogE2, *backgroundLogE;
   uint8_t collapse_masks[2 * ROPUS_NBANDS];
   int anti_collapse_on = 0;
   ropus_norm *X       = scr->celt.q.X;
   ropus_norm *normbuf = scr->celt.q.norm;
   int16_t max_background_increase;

   (void)data;
   memset(&f, 0, sizeof f);
   oldBandE = st->oldEBands;
   oldLogE = st->oldLogE;
   oldLogE2 = st->oldLogE2;
   backgroundLogE = st->backgroundLogE;

   if (ropus_celt_front_q(st, dec, len, frame_size, &f, &pf_gain))
      return -1;
   N = f.N;

   c = 0;
   do
   {
      decode_mem[c] = st->decode_mem[c];
      out_syn[c] = decode_mem[c] + ROPUS_DECODE_BUFFER_SIZE - N;
      memmove(decode_mem[c], decode_mem[c] + N,
         (ROPUS_DECODE_BUFFER_SIZE - N + ROPUS_OVERLAP / 2)
         * sizeof(ropus_sig));
   } while (++c < CC);

   memset(X, 0, sizeof scr->celt.q.X);
   ropus_quant_all_bands_q(start, end, X, C == 2 ? X + N : NULL,
      collapse_masks, f.pulses, f.shortBlocks, f.spread_decision,
      f.dual_stereo, f.intensity, f.tf_res,
      (int32_t)len * (8 << ROPUS_BITRES) - f.anti_collapse_rsv,
      f.balance, dec, f.LM, f.codedBands, &st->rng, 0, normbuf,
      scr->celt.q.had);

   if (f.anti_collapse_rsv > 0)
      anti_collapse_on = (int)ropus_ec_dec_bits(dec, 1);

   ropus_unquant_energy_finalise_q(start, end, oldBandE, f.fine_quant,
      f.fine_priority, len * 8 - ropus_ec_tell(dec), dec, C);

   if (anti_collapse_on)
      ropus_anti_collapse_q(X, collapse_masks, f.LM, C, N, start, end,
         oldBandE, oldLogE, oldLogE2, f.pulses, st->rng);

   if (f.silence)
      for (i = 0; i < C * ROPUS_NBANDS; i++)
         oldBandE[i] = -(28 << ROPUS_DB_SHIFT);

   ropus_celt_synthesis_q(X, out_syn, scr, oldBandE, start, f.effEnd, C, CC,
      f.isTransient, f.LM, f.silence);

   c = 0;
   do
   {
      st->postfilter_period =
         ropus_imax(st->postfilter_period, ROPUS_COMBFILTER_MINPERIOD);
      st->postfilter_period_old =
         ropus_imax(st->postfilter_period_old, ROPUS_COMBFILTER_MINPERIOD);
      ropus_comb_filter_q(out_syn[c], out_syn[c],
         st->postfilter_period_old, st->postfilter_period,
         ROPUS_SHORT_MDCT, st->postfilter_gain_old, st->postfilter_gain,
         st->postfilter_tapset_old, st->postfilter_tapset,
         ropus_window120_q15, ROPUS_OVERLAP);
      if (f.LM != 0)
         ropus_comb_filter_q(out_syn[c] + ROPUS_SHORT_MDCT,
            out_syn[c] + ROPUS_SHORT_MDCT,
            st->postfilter_period, f.postfilter_pitch,
            N - ROPUS_SHORT_MDCT,
            st->postfilter_gain, pf_gain,
            st->postfilter_tapset, f.postfilter_tapset,
            ropus_window120_q15, ROPUS_OVERLAP);
   } while (++c < CC);

   st->postfilter_period_old = st->postfilter_period;
   st->postfilter_gain_old = st->postfilter_gain;
   st->postfilter_tapset_old = st->postfilter_tapset;
   st->postfilter_period = f.postfilter_pitch;
   st->postfilter_gain = pf_gain;
   st->postfilter_tapset = f.postfilter_tapset;
   if (f.LM != 0)
   {
      st->postfilter_period_old = st->postfilter_period;
      st->postfilter_gain_old = st->postfilter_gain;
      st->postfilter_tapset_old = st->postfilter_tapset;
   }

   if (C == 1)
      memcpy(&oldBandE[ROPUS_NBANDS], oldBandE,
         ROPUS_NBANDS * sizeof(int16_t));

   if (!f.isTransient)
   {
      memcpy(oldLogE2, oldLogE, 2 * ROPUS_NBANDS * sizeof(int16_t));
      memcpy(oldLogE, oldBandE, 2 * ROPUS_NBANDS * sizeof(int16_t));
   }
   else
      for (i = 0; i < 2 * ROPUS_NBANDS; i++)
         oldLogE[i] = ropus_min16(oldLogE[i], oldBandE[i]);

   max_background_increase =
      (int16_t)(ropus_imin(160, st->loss_duration + (1 << f.LM)) * 1);
   for (i = 0; i < 2 * ROPUS_NBANDS; i++)
      backgroundLogE[i] = ropus_min16(
         (int16_t)(backgroundLogE[i] + max_background_increase),
         oldBandE[i]);

   c = 0;
   do
   {
      for (i = 0; i < start; i++)
      {
         oldBandE[c * ROPUS_NBANDS + i] = 0;
         oldLogE[c * ROPUS_NBANDS + i] =
            oldLogE2[c * ROPUS_NBANDS + i] = -(28 << ROPUS_DB_SHIFT);
      }
      for (i = end; i < ROPUS_NBANDS; i++)
      {
         oldBandE[c * ROPUS_NBANDS + i] = 0;
         oldLogE[c * ROPUS_NBANDS + i] =
            oldLogE2[c * ROPUS_NBANDS + i] = -(28 << ROPUS_DB_SHIFT);
      }
   } while (++c < 2);

   st->rng = dec->rng;

   ropus_deemphasis_q(out_syn, pcm, N, CC, st->preemph_memD, accum);
   st->loss_duration = 0;
   if (ropus_ec_tell(dec) > 8 * len)
      return -2;
   if (dec->error)
      st->error = 1;
   return N;
}

/* ==================================================================== */
/* ========================  SILK DECODER  =========================== */
/* Fixed-point (libopus SILK is natively fixed); shared by both the     */
/* s16 and float pipelines (the float API scales the s16 output, which  */
/* is the native precision, exactly as libopus does).                   */
/* No PLC/CNG: loss-free playback only (media player use case).         */
/* ==================================================================== */
/* SILK decoder tables, extracted verbatim from libopus v1.4. */

static const uint8_t ropus_type_offset_VAD_iCDF[ 4 ] = {
       232,    158,    10,      0
};

static const uint8_t ropus_type_offset_no_VAD_iCDF[ 2 ] = {
       230,      0
};

static const uint8_t ropus_gain_iCDF[ 3 ][ 64 / 8 ] =
{
{
       224,    112,     44,     15,      3,      2,      1,      0
},
{
       254,    237,    192,    132,     70,     23,      4,      0
},
{
       255,    252,    226,    155,     61,     11,      2,      0
}
};

static const uint8_t ropus_delta_gain_iCDF[ 36 - -4 + 1 ] = {
       250,    245,    234,    203,     71,     50,     42,     38,
        35,     33,     31,     29,     28,     27,     26,     25,
        24,     23,     22,     21,     20,     19,     18,     17,
        16,     15,     14,     13,     12,     11,     10,      9,
         8,      7,      6,      5,      4,      3,      2,      1,
         0
};

static const uint8_t ropus_uniform3_iCDF[ 3 ] = { 171, 85, 0 };

static const uint8_t ropus_uniform4_iCDF[ 4 ] = { 192, 128, 64, 0 };

static const uint8_t ropus_uniform5_iCDF[ 5 ] = { 205, 154, 102, 51, 0 };

static const uint8_t ropus_uniform6_iCDF[ 6 ] = { 213, 171, 128, 85, 43, 0 };

static const uint8_t ropus_uniform8_iCDF[ 8 ] = { 224, 192, 160, 128, 96, 64, 32, 0 };

static const uint8_t ropus_NLSF_EXT_iCDF[ 7 ] = { 100, 40, 16, 7, 3, 1, 0 };

static const uint8_t ropus_NLSF_interpolation_factor_iCDF[ 5 ] = { 243, 221, 192, 181, 0 };

static const uint8_t ropus_pitch_lag_iCDF[ 2 * ( 18 - 2 ) ] = {
       253,    250,    244,    233,    212,    182,    150,    131,
       120,    110,     98,     85,     72,     60,     49,     40,
        32,     25,     19,     15,     13,     11,      9,      8,
         7,      6,      5,      4,      3,      2,      1,      0
};

static const uint8_t ropus_pitch_delta_iCDF[21] = {
       210,    208,    206,    203,    199,    193,    183,    168,
       142,    104,     74,     52,     37,     27,     20,     14,
        10,      6,      4,      2,      0
};

static const uint8_t ropus_pitch_contour_iCDF[34] = {
       223,    201,    183,    167,    152,    138,    124,    111,
        98,     88,     79,     70,     62,     56,     50,     44,
        39,     35,     31,     27,     24,     21,     18,     16,
        14,     12,     10,      8,      6,      4,      3,      2,
         1,      0
};

static const uint8_t ropus_pitch_contour_NB_iCDF[11] = {
       188,    176,    155,    138,    119,     97,     67,     43,
        26,     10,      0
};

static const uint8_t ropus_pitch_contour_10_ms_iCDF[12] = {
       165,    119,     80,     61,     47,     35,     27,     20,
        14,      9,      4,      0
};

static const uint8_t ropus_pitch_contour_10_ms_NB_iCDF[3] = {
       113,     63,      0
};

static const uint8_t ropus_LTP_per_index_iCDF[3] = {
       179,     99,      0
};

static const uint8_t ropus_LTP_gain_iCDF_0[8] = {
        71,     56,     43,     30,     21,     12,      6,      0
};

static const uint8_t ropus_LTP_gain_iCDF_1[16] = {
       199,    165,    144,    124,    109,     96,     84,     71,
        61,     51,     42,     32,     23,     15,      8,      0
};

static const uint8_t ropus_LTP_gain_iCDF_2[32] = {
       241,    225,    211,    199,    187,    175,    164,    153,
       142,    132,    123,    114,    105,     96,     88,     80,
        72,     64,     57,     50,     44,     38,     33,     29,
        24,     20,     16,     12,      9,      5,      2,      0
};

static const int8_t ropus_LTP_gain_vq_0[8][5] =
{
{
         4,      6,     24,      7,      5
},
{
         0,      0,      2,      0,      0
},
{
        12,     28,     41,     13,     -4
},
{
        -9,     15,     42,     25,     14
},
{
         1,     -2,     62,     41,     -9
},
{
       -10,     37,     65,     -4,      3
},
{
        -6,      4,     66,      7,     -8
},
{
        16,     14,     38,     -3,     33
}
};

static const int8_t ropus_LTP_gain_vq_1[16][5] =
{
{
        13,     22,     39,     23,     12
},
{
        -1,     36,     64,     27,     -6
},
{
        -7,     10,     55,     43,     17
},
{
         1,      1,      8,      1,      1
},
{
         6,    -11,     74,     53,     -9
},
{
       -12,     55,     76,    -12,      8
},
{
        -3,      3,     93,     27,     -4
},
{
        26,     39,     59,      3,     -8
},
{
         2,      0,     77,     11,      9
},
{
        -8,     22,     44,     -6,      7
},
{
        40,      9,     26,      3,      9
},
{
        -7,     20,    101,     -7,      4
},
{
         3,     -8,     42,     26,      0
},
{
       -15,     33,     68,      2,     23
},
{
        -2,     55,     46,     -2,     15
},
{
         3,     -1,     21,     16,     41
}
};

static const int8_t ropus_LTP_gain_vq_2[32][5] =
{
{
        -6,     27,     61,     39,      5
},
{
       -11,     42,     88,      4,      1
},
{
        -2,     60,     65,      6,     -4
},
{
        -1,     -5,     73,     56,      1
},
{
        -9,     19,     94,     29,     -9
},
{
         0,     12,     99,      6,      4
},
{
         8,    -19,    102,     46,    -13
},
{
         3,      2,     13,      3,      2
},
{
         9,    -21,     84,     72,    -18
},
{
       -11,     46,    104,    -22,      8
},
{
        18,     38,     48,     23,      0
},
{
       -16,     70,     83,    -21,     11
},
{
         5,    -11,    117,     22,     -8
},
{
        -6,     23,    117,    -12,      3
},
{
         3,     -8,     95,     28,      4
},
{
       -10,     15,     77,     60,    -15
},
{
        -1,      4,    124,      2,     -4
},
{
         3,     38,     84,     24,    -25
},
{
         2,     13,     42,     13,     31
},
{
        21,     -4,     56,     46,     -1
},
{
        -1,     35,     79,    -13,     19
},
{
        -7,     65,     88,     -9,    -14
},
{
        20,      4,     81,     49,    -29
},
{
        20,      0,     75,      3,    -17
},
{
         5,     -9,     44,     92,     -8
},
{
         1,     -3,     22,     69,     31
},
{
        -6,     95,     41,    -12,      5
},
{
        39,     67,     16,     -4,      1
},
{
         0,     -6,    120,     55,    -36
},
{
       -13,     44,    122,      4,    -24
},
{
        81,      5,     11,      3,      7
},
{
         2,      0,      9,     10,     88
}
};

static const uint8_t ropus_LTPscale_iCDF[ 3 ] = { 128, 64, 0 };

static const int16_t ropus_LTPScales_table_Q14[ 3 ] = { 15565, 12288, 8192 };

static const uint8_t ropus_max_pulses_table[ 4 ] = {
         8,     10,     12,     16
};

static const uint8_t ropus_pulses_per_block_iCDF[ 10 ][ 18 ] = {
{
       125,     51,     26,     18,     15,     12,     11,     10,
         9,      8,      7,      6,      5,      4,      3,      2,
         1,      0
},
{
       198,    105,     45,     22,     15,     12,     11,     10,
         9,      8,      7,      6,      5,      4,      3,      2,
         1,      0
},
{
       213,    162,    116,     83,     59,     43,     32,     24,
        18,     15,     12,      9,      7,      6,      5,      3,
         2,      0
},
{
       239,    187,    116,     59,     28,     16,     11,     10,
         9,      8,      7,      6,      5,      4,      3,      2,
         1,      0
},
{
       250,    229,    188,    135,     86,     51,     30,     19,
        13,     10,      8,      6,      5,      4,      3,      2,
         1,      0
},
{
       249,    235,    213,    185,    156,    128,    103,     83,
        66,     53,     42,     33,     26,     21,     17,     13,
        10,      0
},
{
       254,    249,    235,    206,    164,    118,     77,     46,
        27,     16,     10,      7,      5,      4,      3,      2,
         1,      0
},
{
       255,    253,    249,    239,    220,    191,    156,    119,
        85,     57,     37,     23,     15,     10,      6,      4,
         2,      0
},
{
       255,    253,    251,    246,    237,    223,    203,    179,
       152,    124,     98,     75,     55,     40,     29,     21,
        15,      0
},
{
       255,    254,    253,    247,    220,    162,    106,     67,
        42,     28,     18,     12,      9,      6,      4,      3,
         2,      0
}
};

static const uint8_t ropus_rate_levels_iCDF[ 2 ][ 9 ] =
{
{
       241,    190,    178,    132,     87,     74,     41,     14,
         0
},
{
       223,    193,    157,    140,    106,     57,     39,     18,
         0
}
};

static const uint8_t ropus_shell_code_table0[ 152 ] = {
       128,      0,    214,     42,      0,    235,    128,     21,
         0,    244,    184,     72,     11,      0,    248,    214,
       128,     42,      7,      0,    248,    225,    170,     80,
        25,      5,      0,    251,    236,    198,    126,     54,
        18,      3,      0,    250,    238,    211,    159,     82,
        35,     15,      5,      0,    250,    231,    203,    168,
       128,     88,     53,     25,      6,      0,    252,    238,
       216,    185,    148,    108,     71,     40,     18,      4,
         0,    253,    243,    225,    199,    166,    128,     90,
        57,     31,     13,      3,      0,    254,    246,    233,
       212,    183,    147,    109,     73,     44,     23,     10,
         2,      0,    255,    250,    240,    223,    198,    166,
       128,     90,     58,     33,     16,      6,      1,      0,
       255,    251,    244,    231,    210,    181,    146,    110,
        75,     46,     25,     12,      5,      1,      0,    255,
       253,    248,    238,    221,    196,    164,    128,     92,
        60,     35,     18,      8,      3,      1,      0,    255,
       253,    249,    242,    229,    208,    180,    146,    110,
        76,     48,     27,     14,      7,      3,      1,      0
};

static const uint8_t ropus_shell_code_table1[ 152 ] = {
       129,      0,    207,     50,      0,    236,    129,     20,
         0,    245,    185,     72,     10,      0,    249,    213,
       129,     42,      6,      0,    250,    226,    169,     87,
        27,      4,      0,    251,    233,    194,    130,     62,
        20,      4,      0,    250,    236,    207,    160,     99,
        47,     17,      3,      0,    255,    240,    217,    182,
       131,     81,     41,     11,      1,      0,    255,    254,
       233,    201,    159,    107,     61,     20,      2,      1,
         0,    255,    249,    233,    206,    170,    128,     86,
        50,     23,      7,      1,      0,    255,    250,    238,
       217,    186,    148,    108,     70,     39,     18,      6,
         1,      0,    255,    252,    243,    226,    200,    166,
       128,     90,     56,     30,     13,      4,      1,      0,
       255,    252,    245,    231,    209,    180,    146,    110,
        76,     47,     25,     11,      4,      1,      0,    255,
       253,    248,    237,    219,    194,    163,    128,     93,
        62,     37,     19,      8,      3,      1,      0,    255,
       254,    250,    241,    226,    205,    177,    145,    111,
        79,     51,     30,     15,      6,      2,      1,      0
};

static const uint8_t ropus_shell_code_table2[ 152 ] = {
       129,      0,    203,     54,      0,    234,    129,     23,
         0,    245,    184,     73,     10,      0,    250,    215,
       129,     41,      5,      0,    252,    232,    173,     86,
        24,      3,      0,    253,    240,    200,    129,     56,
        15,      2,      0,    253,    244,    217,    164,     94,
        38,     10,      1,      0,    253,    245,    226,    189,
       132,     71,     27,      7,      1,      0,    253,    246,
       231,    203,    159,    105,     56,     23,      6,      1,
         0,    255,    248,    235,    213,    179,    133,     85,
        47,     19,      5,      1,      0,    255,    254,    243,
       221,    194,    159,    117,     70,     37,     12,      2,
         1,      0,    255,    254,    248,    234,    208,    171,
       128,     85,     48,     22,      8,      2,      1,      0,
       255,    254,    250,    240,    220,    189,    149,    107,
        67,     36,     16,      6,      2,      1,      0,    255,
       254,    251,    243,    227,    201,    166,    128,     90,
        55,     29,     13,      5,      2,      1,      0,    255,
       254,    252,    246,    234,    213,    183,    147,    109,
        73,     43,     22,     10,      4,      2,      1,      0
};

static const uint8_t ropus_shell_code_table3[ 152 ] = {
       130,      0,    200,     58,      0,    231,    130,     26,
         0,    244,    184,     76,     12,      0,    249,    214,
       130,     43,      6,      0,    252,    232,    173,     87,
        24,      3,      0,    253,    241,    203,    131,     56,
        14,      2,      0,    254,    246,    221,    167,     94,
        35,      8,      1,      0,    254,    249,    232,    193,
       130,     65,     23,      5,      1,      0,    255,    251,
       239,    211,    162,     99,     45,     15,      4,      1,
         0,    255,    251,    243,    223,    186,    131,     74,
        33,     11,      3,      1,      0,    255,    252,    245,
       230,    202,    158,    105,     57,     24,      8,      2,
         1,      0,    255,    253,    247,    235,    214,    179,
       132,     84,     44,     19,      7,      2,      1,      0,
       255,    254,    250,    240,    223,    196,    159,    112,
        69,     36,     15,      6,      2,      1,      0,    255,
       254,    253,    245,    231,    209,    176,    136,     93,
        55,     27,     11,      3,      2,      1,      0,    255,
       254,    253,    252,    239,    221,    194,    158,    117,
        76,     42,     18,      4,      3,      2,      1,      0
};

static const uint8_t ropus_shell_code_table_offsets[ 17 ] = {
         0,      0,      2,      5,      9,     14,     20,     27,
        35,     44,     54,     65,     77,     90,    104,    119,
       135
};

static const uint8_t ropus_lsb_iCDF[ 2 ] = { 120, 0 };

static const uint8_t ropus_sign_iCDF[ 42 ] = {
       254,     49,     67,     77,     82,     93,     99,
       198,     11,     18,     24,     31,     36,     45,
       255,     46,     66,     78,     87,     94,    104,
       208,     14,     21,     32,     42,     51,     66,
       255,     94,    104,    109,    112,    115,    118,
       248,     53,     69,     80,     88,     95,    102
};

static const int16_t ropus_NLSF_DELTA_MIN_WB_Q15[ 17 ] = {
       100,      3,     40,      3,      3,      3,      5,     14,
        14,     10,     11,      3,      8,      9,      7,      3,
       347
};

static const uint8_t ropus_NLSF_CB1_WB_Q8[ 512 ] = {
         7,     23,     38,     54,     69,     85,    100,    116,
       131,    147,    162,    178,    193,    208,    223,    239,
        13,     25,     41,     55,     69,     83,     98,    112,
       127,    142,    157,    171,    187,    203,    220,    236,
        15,     21,     34,     51,     61,     78,     92,    106,
       126,    136,    152,    167,    185,    205,    225,    240,
        10,     21,     36,     50,     63,     79,     95,    110,
       126,    141,    157,    173,    189,    205,    221,    237,
        17,     20,     37,     51,     59,     78,     89,    107,
       123,    134,    150,    164,    184,    205,    224,    240,
        10,     15,     32,     51,     67,     81,     96,    112,
       129,    142,    158,    173,    189,    204,    220,    236,
         8,     21,     37,     51,     65,     79,     98,    113,
       126,    138,    155,    168,    179,    192,    209,    218,
        12,     15,     34,     55,     63,     78,     87,    108,
       118,    131,    148,    167,    185,    203,    219,    236,
        16,     19,     32,     36,     56,     79,     91,    108,
       118,    136,    154,    171,    186,    204,    220,    237,
        11,     28,     43,     58,     74,     89,    105,    120,
       135,    150,    165,    180,    196,    211,    226,    241,
         6,     16,     33,     46,     60,     75,     92,    107,
       123,    137,    156,    169,    185,    199,    214,    225,
        11,     19,     30,     44,     57,     74,     89,    105,
       121,    135,    152,    169,    186,    202,    218,    234,
        12,     19,     29,     46,     57,     71,     88,    100,
       120,    132,    148,    165,    182,    199,    216,    233,
        17,     23,     35,     46,     56,     77,     92,    106,
       123,    134,    152,    167,    185,    204,    222,    237,
        14,     17,     45,     53,     63,     75,     89,    107,
       115,    132,    151,    171,    188,    206,    221,    240,
         9,     16,     29,     40,     56,     71,     88,    103,
       119,    137,    154,    171,    189,    205,    222,    237,
        16,     19,     36,     48,     57,     76,     87,    105,
       118,    132,    150,    167,    185,    202,    218,    236,
        12,     17,     29,     54,     71,     81,     94,    104,
       126,    136,    149,    164,    182,    201,    221,    237,
        15,     28,     47,     62,     79,     97,    115,    129,
       142,    155,    168,    180,    194,    208,    223,    238,
         8,     14,     30,     45,     62,     78,     94,    111,
       127,    143,    159,    175,    192,    207,    223,    239,
        17,     30,     49,     62,     79,     92,    107,    119,
       132,    145,    160,    174,    190,    204,    220,    235,
        14,     19,     36,     45,     61,     76,     91,    108,
       121,    138,    154,    172,    189,    205,    222,    238,
        12,     18,     31,     45,     60,     76,     91,    107,
       123,    138,    154,    171,    187,    204,    221,    236,
        13,     17,     31,     43,     53,     70,     83,    103,
       114,    131,    149,    167,    185,    203,    220,    237,
        17,     22,     35,     42,     58,     78,     93,    110,
       125,    139,    155,    170,    188,    206,    224,    240,
         8,     15,     34,     50,     67,     83,     99,    115,
       131,    146,    162,    178,    193,    209,    224,    239,
        13,     16,     41,     66,     73,     86,     95,    111,
       128,    137,    150,    163,    183,    206,    225,    241,
        17,     25,     37,     52,     63,     75,     92,    102,
       119,    132,    144,    160,    175,    191,    212,    231,
        19,     31,     49,     65,     83,    100,    117,    133,
       147,    161,    174,    187,    200,    213,    227,    242,
        18,     31,     52,     68,     88,    103,    117,    126,
       138,    149,    163,    177,    192,    207,    223,    239,
        16,     29,     47,     61,     76,     90,    106,    119,
       133,    147,    161,    176,    193,    209,    224,    240,
        15,     21,     35,     50,     61,     73,     86,     97,
       110,    119,    129,    141,    175,    198,    218,    237
};

static const uint8_t ropus_NLSF_CB1_iCDF_WB[ 64 ] = {
       225,    204,    201,    184,    183,    175,    158,    154,
       153,    135,    119,    115,    113,    110,    109,     99,
        98,     95,     79,     68,     52,     50,     48,     45,
        43,     32,     31,     27,     18,     10,      3,      0,
       255,    251,    235,    230,    212,    201,    196,    182,
       167,    166,    163,    151,    138,    124,    110,    104,
        90,     78,     76,     70,     69,     57,     45,     34,
        24,     21,     11,      6,      5,      4,      3,      0
};

static const uint8_t ropus_NLSF_PRED_WB_Q8[ 30 ] = {
       175,    148,    160,    176,    178,    173,    174,    164,
       177,    174,    196,    182,    198,    192,    182,     68,
        62,     66,     60,     72,    117,     85,     90,    118,
       136,    151,    142,    160,    142,    155
};

static const int16_t ropus_NLSF_CB1_WB_Wght_Q9[ 512 ] = {
     3657, 2925, 2925, 2925, 2925, 2925, 2925, 2925, 2925, 2925, 2925, 2925, 2963, 2963, 2925, 2846,
     3216, 3085, 2972, 3056, 3056, 3010, 3010, 3010, 2963, 2963, 3010, 2972, 2888, 2846, 2846, 2726,
     3920, 4014, 2981, 3207, 3207, 2934, 3056, 2846, 3122, 3244, 2925, 2846, 2620, 2553, 2780, 2925,
     3516, 3197, 3010, 3103, 3019, 2888, 2925, 2925, 2925, 2925, 2888, 2888, 2888, 2888, 2888, 2753,
     5054, 5054, 2934, 3573, 3385, 3056, 3085, 2793, 3160, 3160, 2972, 2846, 2513, 2540, 2753, 2888,
     4428, 4149, 2700, 2753, 2972, 3010, 2925, 2846, 2981, 3019, 2925, 2925, 2925, 2925, 2888, 2726,
     3620, 3019, 2972, 3056, 3056, 2873, 2806, 3056, 3216, 3047, 2981, 3291, 3291, 2981, 3310, 2991,
     5227, 5014, 2540, 3338, 3526, 3385, 3197, 3094, 3376, 2981, 2700, 2647, 2687, 2793, 2846, 2673,
     5081, 5174, 4615, 4428, 2460, 2897, 3047, 3207, 3169, 2687, 2740, 2888, 2846, 2793, 2846, 2700,
     3122, 2888, 2963, 2925, 2925, 2925, 2925, 2963, 2963, 2963, 2963, 2925, 2925, 2963, 2963, 2963,
     4202, 3207, 2981, 3103, 3010, 2888, 2888, 2925, 2972, 2873, 2916, 3019, 2972, 3010, 3197, 2873,
     3760, 3760, 3244, 3103, 2981, 2888, 2925, 2888, 2972, 2934, 2793, 2793, 2846, 2888, 2888, 2660,
     3854, 4014, 3207, 3122, 3244, 2934, 3047, 2963, 2963, 3085, 2846, 2793, 2793, 2793, 2793, 2580,
     3845, 4080, 3357, 3516, 3094, 2740, 3010, 2934, 3122, 3085, 2846, 2846, 2647, 2647, 2846, 2806,
     5147, 4894, 3225, 3845, 3441, 3169, 2897, 3413, 3451, 2700, 2580, 2673, 2740, 2846, 2806, 2753,
     4109, 3789, 3291, 3160, 2925, 2888, 2888, 2925, 2793, 2740, 2793, 2740, 2793, 2846, 2888, 2806,
     5081, 5054, 3047, 3545, 3244, 3056, 3085, 2944, 3103, 2897, 2740, 2740, 2740, 2846, 2793, 2620,
     4309, 4309, 2860, 2527, 3207, 3376, 3376, 3075, 3075, 3376, 3056, 2846, 2647, 2580, 2726, 2753,
     3056, 2916, 2806, 2888, 2740, 2687, 2897, 3103, 3150, 3150, 3216, 3169, 3056, 3010, 2963, 2846,
     4375, 3882, 2925, 2888, 2846, 2888, 2846, 2846, 2888, 2888, 2888, 2846, 2888, 2925, 2888, 2846,
     2981, 2916, 2916, 2981, 2981, 3056, 3122, 3216, 3150, 3056, 3010, 2972, 2972, 2972, 2925, 2740,
     4229, 4149, 3310, 3347, 2925, 2963, 2888, 2981, 2981, 2846, 2793, 2740, 2846, 2846, 2846, 2793,
     4080, 4014, 3103, 3010, 2925, 2925, 2925, 2888, 2925, 2925, 2846, 2846, 2846, 2793, 2888, 2780,
     4615, 4575, 3169, 3441, 3207, 2981, 2897, 3038, 3122, 2740, 2687, 2687, 2687, 2740, 2793, 2700,
     4149, 4269, 3789, 3657, 2726, 2780, 2888, 2888, 3010, 2972, 2925, 2846, 2687, 2687, 2793, 2888,
     4215, 3554, 2753, 2846, 2846, 2888, 2888, 2888, 2925, 2925, 2888, 2925, 2925, 2925, 2963, 2888,
     5174, 4921, 2261, 3432, 3789, 3479, 3347, 2846, 3310, 3479, 3150, 2897, 2460, 2487, 2753, 2925,
     3451, 3685, 3122, 3197, 3357, 3047, 3207, 3207, 2981, 3216, 3085, 2925, 2925, 2687, 2540, 2434,
     2981, 3010, 2793, 2793, 2740, 2793, 2846, 2972, 3056, 3103, 3150, 3150, 3150, 3103, 3010, 3010,
     2944, 2873, 2687, 2726, 2780, 3010, 3432, 3545, 3357, 3244, 3056, 3010, 2963, 2925, 2888, 2846,
     3019, 2944, 2897, 3010, 3010, 2972, 3019, 3103, 3056, 3056, 3010, 2888, 2846, 2925, 2925, 2888,
     3920, 3967, 3010, 3197, 3357, 3216, 3291, 3291, 3479, 3704, 3441, 2726, 2181, 2460, 2580, 2607
};

static const uint8_t ropus_NLSF_CB2_SELECT_WB[ 256 ] = {
         0,      0,      0,      0,      0,      0,      0,      1,
       100,    102,    102,     68,     68,     36,     34,     96,
       164,    107,    158,    185,    180,    185,    139,    102,
        64,     66,     36,     34,     34,      0,      1,     32,
       208,    139,    141,    191,    152,    185,    155,    104,
        96,    171,    104,    166,    102,    102,    102,    132,
         1,      0,      0,      0,      0,     16,     16,      0,
        80,    109,     78,    107,    185,    139,    103,    101,
       208,    212,    141,    139,    173,    153,    123,    103,
        36,      0,      0,      0,      0,      0,      0,      1,
        48,      0,      0,      0,      0,      0,      0,     32,
        68,    135,    123,    119,    119,    103,     69,     98,
        68,    103,    120,    118,    118,    102,     71,     98,
       134,    136,    157,    184,    182,    153,    139,    134,
       208,    168,    248,     75,    189,    143,    121,    107,
        32,     49,     34,     34,     34,      0,     17,      2,
       210,    235,    139,    123,    185,    137,    105,    134,
        98,    135,    104,    182,    100,    183,    171,    134,
       100,     70,     68,     70,     66,     66,     34,    131,
        64,    166,    102,     68,     36,      2,      1,      0,
       134,    166,    102,     68,     34,     34,     66,    132,
       212,    246,    158,    139,    107,    107,     87,    102,
       100,    219,    125,    122,    137,    118,    103,    132,
       114,    135,    137,    105,    171,    106,     50,     34,
       164,    214,    141,    143,    185,    151,    121,    103,
       192,     34,      0,      0,      0,      0,      0,      1,
       208,    109,     74,    187,    134,    249,    159,    137,
       102,    110,    154,    118,     87,    101,    119,    101,
         0,      2,      0,     36,     36,     66,     68,     35,
        96,    164,    102,    100,     36,      0,      2,     33,
       167,    138,    174,    102,    100,     84,      2,      2,
       100,    107,    120,    119,     36,    197,     24,      0
};

static const uint8_t ropus_NLSF_CB2_iCDF_WB[ 72 ] = {
       255,    254,    253,    244,     12,      3,      2,      1,
         0,    255,    254,    252,    224,     38,      3,      2,
         1,      0,    255,    254,    251,    209,     57,      4,
         2,      1,      0,    255,    254,    244,    195,     69,
         4,      2,      1,      0,    255,    251,    232,    184,
        84,      7,      2,      1,      0,    255,    254,    240,
       186,     86,     14,      2,      1,      0,    255,    254,
       239,    178,     91,     30,      5,      1,      0,    255,
       248,    227,    177,    100,     19,      2,      1,      0
};

static const uint8_t ropus_NLSF_CB2_BITS_WB_Q5[ 72 ] = {
       255,    255,    255,    156,      4,    154,    255,    255,
       255,    255,    255,    227,    102,     15,     92,    255,
       255,    255,    255,    255,    213,     83,     24,     72,
       236,    255,    255,    255,    255,    150,     76,     33,
        63,    214,    255,    255,    255,    190,    121,     77,
        43,     55,    185,    255,    255,    255,    245,    137,
        71,     43,     59,    139,    255,    255,    255,    255,
       131,     66,     50,     66,    107,    194,    255,    255,
       166,    116,     76,     55,     53,    125,    255,    255
};

static const int16_t ropus_LSFCosTab_FIX_Q12[ 128 + 1 ] = {
            8192,             8190,             8182,             8170,
            8152,             8130,             8104,             8072,
            8034,             7994,             7946,             7896,
            7840,             7778,             7714,             7644,
            7568,             7490,             7406,             7318,
            7226,             7128,             7026,             6922,
            6812,             6698,             6580,             6458,
            6332,             6204,             6070,             5934,
            5792,             5648,             5502,             5352,
            5198,             5040,             4880,             4718,
            4552,             4382,             4212,             4038,
            3862,             3684,             3502,             3320,
            3136,             2948,             2760,             2570,
            2378,             2186,             1990,             1794,
            1598,             1400,             1202,             1002,
             802,              602,              402,              202,
               0,             -202,             -402,             -602,
            -802,            -1002,            -1202,            -1400,
           -1598,            -1794,            -1990,            -2186,
           -2378,            -2570,            -2760,            -2948,
           -3136,            -3320,            -3502,            -3684,
           -3862,            -4038,            -4212,            -4382,
           -4552,            -4718,            -4880,            -5040,
           -5198,            -5352,            -5502,            -5648,
           -5792,            -5934,            -6070,            -6204,
           -6332,            -6458,            -6580,            -6698,
           -6812,            -6922,            -7026,            -7128,
           -7226,            -7318,            -7406,            -7490,
           -7568,            -7644,            -7714,            -7778,
           -7840,            -7896,            -7946,            -7994,
           -8034,            -8072,            -8104,            -8130,
           -8152,            -8170,            -8182,            -8190,
           -8192
};

static const int16_t ropus_stereo_pred_quant_Q13[ 16 ] = {
    -13732, -10050, -8266, -7526, -6500, -5000, -2950,  -820,
       820,   2950,  5000,  6500,  7526,  8266, 10050, 13732
};

static const uint8_t  ropus_stereo_pred_joint_iCDF[ 25 ] = {
    249, 247, 246, 245, 244,
    234, 210, 202, 201, 200,
    197, 174,  82,  59,  56,
     55,  54,  46,  22,  12,
     11,  10,   9,   7,   0
};

static const uint8_t  ropus_stereo_only_code_mid_iCDF[ 2 ] = { 64, 0 };

/* Pitch contour codebooks (silk/pitch_est_tables.c). */

static const int8_t ropus_CB_lags_stage2_10_ms[ 2][ 3 ] =
{
    {0, 1, 0},
    {0, 0, 1}
};

static const int8_t ropus_CB_lags_stage3_10_ms[ 2 ][ 12 ] =
{
    { 0, 0, 1,-1, 1,-1, 2,-2, 2,-2, 3,-3},
    { 0, 1, 0, 1,-1, 2,-1, 2,-2, 3,-2, 3}
};

static const int8_t ropus_CB_lags_stage2[ 4 ][ 11 ] =
{
    {0, 2,-1,-1,-1, 0, 0, 1, 1, 0, 1},
    {0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0},
    {0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0},
    {0,-1, 2, 1, 0, 1, 1, 0, 0,-1,-1}
};

static const int8_t ropus_CB_lags_stage3[ 4 ][ 34 ] =
{
    {0, 0, 1,-1, 0, 1,-1, 0,-1, 1,-2, 2,-2,-2, 2,-3, 2, 3,-3,-4, 3,-4, 4, 4,-5, 5,-6,-5, 6,-7, 6, 5, 8,-9},
    {0, 0, 1, 0, 0, 0, 0, 0, 0, 0,-1, 1, 0, 0, 1,-1, 0, 1,-1,-1, 1,-1, 2, 1,-1, 2,-2,-2, 2,-2, 2, 2, 3,-3},
    {0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1,-1, 1, 0, 0, 2, 1,-1, 2,-1,-1, 2,-1, 2, 2,-1, 3,-2,-2,-2, 3},
    {0, 1, 0, 0, 1, 0, 1,-1, 2,-1, 2,-1, 2, 3,-2, 3,-2,-2, 4, 4,-3, 5,-3,-4, 6,-4, 6, 5,-5, 8,-6,-5,-7, 9}
};

/* Resampler ROM (silk/resampler_rom.c). */

static const int16_t ropus_resampler_frac_FIR_12[ 12 ][ 4 ] = {
    {  189,  -600,   617, 30567 },
    {  117,  -159, -1070, 29704 },
    {   52,   221, -2392, 28276 },
    {   -4,   529, -3350, 26341 },
    {  -48,   758, -3956, 23973 },
    {  -80,   905, -4235, 21254 },
    {  -99,   972, -4222, 18278 },
    { -107,   967, -3957, 15143 },
    { -103,   896, -3487, 11950 },
    {  -91,   773, -2865,  8798 },
    {  -71,   611, -2143,  5784 },
    {  -46,   425, -1375,  2996 },
};

static const int16_t ropus_resampler_3_4_COEFS[ 2 + 3 * 9 ] = {
    -20694, -13867,
       -49,     64,     17,   -157,    353,   -496,    163,  11047,  22205,
       -39,      6,     91,   -170,    186,     23,   -896,   6336,  19928,
       -19,    -36,    102,    -89,    -24,    328,   -951,   2568,  15909,
};

static const int16_t ropus_resampler_2_3_COEFS[ 2 + 2 * 9 ] = {
    -14457, -14019,
        64,    128,   -122,     36,    310,   -768,    584,   9267,  17733,
        12,    128,     18,   -142,    288,   -117,   -865,   4123,  14459,
};

static const int16_t ropus_resampler_1_2_COEFS[ 2 + 12 ] = {
       616, -14323,
       -10,     39,     58,    -46,    -84,    120,    184,   -315,   -541,   1284,   5380,   9024,
};

static const int16_t ropus_resampler_1_3_COEFS[ 2 + 18 ] = {
     16102, -15162,
       -13,      0,     20,     26,      5,    -31,    -43,     -4,     65,     90,      7,   -157,   -248,    -44,    593,   1583,   2612,   3271,
};

static const int16_t ropus_resampler_1_4_COEFS[ 2 + 18 ] = {
     22500, -15099,
         3,    -14,    -20,    -15,      2,     25,     37,     25,    -16,    -71,   -107,    -79,     50,    292,    623,    982,   1288,   1464,
};

static const int16_t ropus_resampler_1_6_COEFS[ 2 + 18 ] = {
     27540, -15257,
        17,     12,      8,      1,    -10,    -22,    -30,    -32,    -22,      3,     44,    100,    168,    243,    317,    381,    429,    455,
};

/* NB/MB NLSF codebook (silk/tables_NLSF_CB_NB_MB.c). */

static const uint8_t ropus_NLSF_CB1_NB_MB_Q8[ 320 ] = {
        12,     35,     60,     83,    108,    132,    157,    180,
       206,    228,     15,     32,     55,     77,    101,    125,
       151,    175,    201,    225,     19,     42,     66,     89,
       114,    137,    162,    184,    209,    230,     12,     25,
        50,     72,     97,    120,    147,    172,    200,    223,
        26,     44,     69,     90,    114,    135,    159,    180,
       205,    225,     13,     22,     53,     80,    106,    130,
       156,    180,    205,    228,     15,     25,     44,     64,
        90,    115,    142,    168,    196,    222,     19,     24,
        62,     82,    100,    120,    145,    168,    190,    214,
        22,     31,     50,     79,    103,    120,    151,    170,
       203,    227,     21,     29,     45,     65,    106,    124,
       150,    171,    196,    224,     30,     49,     75,     97,
       121,    142,    165,    186,    209,    229,     19,     25,
        52,     70,     93,    116,    143,    166,    192,    219,
        26,     34,     62,     75,     97,    118,    145,    167,
       194,    217,     25,     33,     56,     70,     91,    113,
       143,    165,    196,    223,     21,     34,     51,     72,
        97,    117,    145,    171,    196,    222,     20,     29,
        50,     67,     90,    117,    144,    168,    197,    221,
        22,     31,     48,     66,     95,    117,    146,    168,
       196,    222,     24,     33,     51,     77,    116,    134,
       158,    180,    200,    224,     21,     28,     70,     87,
       106,    124,    149,    170,    194,    217,     26,     33,
        53,     64,     83,    117,    152,    173,    204,    225,
        27,     34,     65,     95,    108,    129,    155,    174,
       210,    225,     20,     26,     72,     99,    113,    131,
       154,    176,    200,    219,     34,     43,     61,     78,
        93,    114,    155,    177,    205,    229,     23,     29,
        54,     97,    124,    138,    163,    179,    209,    229,
        30,     38,     56,     89,    118,    129,    158,    178,
       200,    231,     21,     29,     49,     63,     85,    111,
       142,    163,    193,    222,     27,     48,     77,    103,
       133,    158,    179,    196,    215,    232,     29,     47,
        74,     99,    124,    151,    176,    198,    220,    237,
        33,     42,     61,     76,     93,    121,    155,    174,
       207,    225,     29,     53,     87,    112,    136,    154,
       170,    188,    208,    227,     24,     30,     52,     84,
       131,    150,    166,    186,    203,    229,     37,     48,
        64,     84,    104,    118,    156,    177,    201,    230
};

static const uint8_t ropus_NLSF_CB1_iCDF_NB_MB[ 64 ] = {
       212,    178,    148,    129,    108,     96,     85,     82,
        79,     77,     61,     59,     57,     56,     51,     49,
        48,     45,     42,     41,     40,     38,     36,     34,
        31,     30,     21,     12,     10,      3,      1,      0,
       255,    245,    244,    236,    233,    225,    217,    203,
       190,    176,    175,    161,    149,    136,    125,    114,
       102,     91,     81,     71,     60,     52,     43,     35,
        28,     20,     19,     18,     12,     11,      5,      0
};

static const uint8_t ropus_NLSF_PRED_NB_MB_Q8[ 18 ] = {
       179,    138,    140,    148,    151,    149,    153,    151,
       163,    116,     67,     82,     59,     92,     72,    100,
        89,     92
};

static const uint8_t ropus_NLSF_CB2_SELECT_NB_MB[ 160 ] = {
        16,      0,      0,      0,      0,     99,     66,     36,
        36,     34,     36,     34,     34,     34,     34,     83,
        69,     36,     52,     34,    116,    102,     70,     68,
        68,    176,    102,     68,     68,     34,     65,     85,
        68,     84,     36,    116,    141,    152,    139,    170,
       132,    187,    184,    216,    137,    132,    249,    168,
       185,    139,    104,    102,    100,     68,     68,    178,
       218,    185,    185,    170,    244,    216,    187,    187,
       170,    244,    187,    187,    219,    138,    103,    155,
       184,    185,    137,    116,    183,    155,    152,    136,
       132,    217,    184,    184,    170,    164,    217,    171,
       155,    139,    244,    169,    184,    185,    170,    164,
       216,    223,    218,    138,    214,    143,    188,    218,
       168,    244,    141,    136,    155,    170,    168,    138,
       220,    219,    139,    164,    219,    202,    216,    137,
       168,    186,    246,    185,    139,    116,    185,    219,
       185,    138,    100,    100,    134,    100,    102,     34,
        68,     68,    100,     68,    168,    203,    221,    218,
       168,    167,    154,    136,    104,     70,    164,    246,
       171,    137,    139,    137,    155,    218,    219,    139
};

static const uint8_t ropus_NLSF_CB2_iCDF_NB_MB[ 72 ] = {
       255,    254,    253,    238,     14,      3,      2,      1,
         0,    255,    254,    252,    218,     35,      3,      2,
         1,      0,    255,    254,    250,    208,     59,      4,
         2,      1,      0,    255,    254,    246,    194,     71,
        10,      2,      1,      0,    255,    252,    236,    183,
        82,      8,      2,      1,      0,    255,    252,    235,
       180,     90,     17,      2,      1,      0,    255,    248,
       224,    171,     97,     30,      4,      1,      0,    255,
       254,    236,    173,     95,     37,      7,      1,      0
};

static const uint8_t ropus_NLSF_CB2_BITS_NB_MB_Q5[ 72 ] = {
       255,    255,    255,    131,      6,    145,    255,    255,
       255,    255,    255,    236,     93,     15,     96,    255,
       255,    255,    255,    255,    194,     83,     25,     71,
       221,    255,    255,    255,    255,    162,     73,     34,
        66,    162,    255,    255,    255,    210,    126,     73,
        43,     57,    173,    255,    255,    255,    201,    125,
        71,     48,     58,    130,    255,    255,    255,    166,
       110,     73,     57,     62,    104,    210,    255,    255,
       251,    123,     65,     55,     68,    100,    171,    255
};

static const int16_t ropus_NLSF_DELTA_MIN_NB_MB_Q15[ 11 ] = {
       250,      3,      6,      3,      3,      3,      4,      3,
         3,      3,    461
};

static const int16_t ropus_NLSF_CB1_NB_MB_Wght_Q9[ 320 ] = {
     2897, 2314, 2314, 2314, 2287, 2287, 2314, 2300, 2327, 2287,
     2888, 2580, 2394, 2367, 2314, 2274, 2274, 2274, 2274, 2194,
     2487, 2340, 2340, 2314, 2314, 2314, 2340, 2340, 2367, 2354,
     3216, 2766, 2340, 2340, 2314, 2274, 2221, 2207, 2261, 2194,
     2460, 2474, 2367, 2394, 2394, 2394, 2394, 2367, 2407, 2314,
     3479, 3056, 2127, 2207, 2274, 2274, 2274, 2287, 2314, 2261,
     3282, 3141, 2580, 2394, 2247, 2221, 2207, 2194, 2194, 2114,
     4096, 3845, 2221, 2620, 2620, 2407, 2314, 2394, 2367, 2074,
     3178, 3244, 2367, 2221, 2553, 2434, 2340, 2314, 2167, 2221,
     3338, 3488, 2726, 2194, 2261, 2460, 2354, 2367, 2207, 2101,
     2354, 2420, 2327, 2367, 2394, 2420, 2420, 2420, 2460, 2367,
     3779, 3629, 2434, 2527, 2367, 2274, 2274, 2300, 2207, 2048,
     3254, 3225, 2713, 2846, 2447, 2327, 2300, 2300, 2274, 2127,
     3263, 3300, 2753, 2806, 2447, 2261, 2261, 2247, 2127, 2101,
     2873, 2981, 2633, 2367, 2407, 2354, 2194, 2247, 2247, 2114,
     3225, 3197, 2633, 2580, 2274, 2181, 2247, 2221, 2221, 2141,
     3178, 3310, 2740, 2407, 2274, 2274, 2274, 2287, 2194, 2114,
     3141, 3272, 2460, 2061, 2287, 2500, 2367, 2487, 2434, 2181,
     3507, 3282, 2314, 2700, 2647, 2474, 2367, 2394, 2340, 2127,
     3423, 3535, 3038, 3056, 2300, 1950, 2221, 2274, 2274, 2274,
     3404, 3366, 2087, 2687, 2873, 2354, 2420, 2274, 2474, 2540,
     3760, 3488, 1950, 2660, 2897, 2527, 2394, 2367, 2460, 2261,
     3028, 3272, 2740, 2888, 2740, 2154, 2127, 2287, 2234, 2247,
     3695, 3657, 2025, 1969, 2660, 2700, 2580, 2500, 2327, 2367,
     3207, 3413, 2354, 2074, 2888, 2888, 2340, 2487, 2247, 2167,
     3338, 3366, 2846, 2780, 2327, 2154, 2274, 2287, 2114, 2061,
     2327, 2300, 2181, 2167, 2181, 2367, 2633, 2700, 2700, 2553,
     2407, 2434, 2221, 2261, 2221, 2221, 2340, 2420, 2607, 2700,
     3038, 3244, 2806, 2888, 2474, 2074, 2300, 2314, 2354, 2380,
     2221, 2154, 2127, 2287, 2500, 2793, 2793, 2620, 2580, 2367,
     3676, 3713, 2234, 1838, 2181, 2753, 2726, 2673, 2513, 2207,
     2793, 3160, 2726, 2553, 2846, 2513, 2181, 2394, 2221, 2181
};

#define ROPUS_SILK_MAX_LPC_ORDER   16
#define ROPUS_SILK_MAX_NB_SUBFR    4
#define ROPUS_SILK_MAX_FRAME_LEN   320   /* 20 ms at 16 kHz             */
#define ROPUS_SILK_MAX_FRAMES      3
#define ROPUS_SILK_LTP_MEM_MS      20
#define ROPUS_SILK_SHELL_LEN       16
#define ROPUS_SILK_MAX_SHELL_BLOCKS 24   /* 320/16 + headroom (12kHz)   */
#define ROPUS_SILK_MAX_PULSES      16
#define ROPUS_NLSF_QUANT_MAX_AMP   4

typedef struct
{
   int16_t nVectors, order;
   int16_t quantStepSize_Q16, invQuantStepSize_Q6;
   const uint8_t  *CB1_NLSF_Q8;
   const int16_t  *CB1_Wght_Q9;
   const uint8_t  *CB1_iCDF;
   const uint8_t  *pred_Q8;
   const uint8_t  *ec_sel;
   const uint8_t  *ec_iCDF;
   const uint8_t  *ec_Rates_Q5;
   const int16_t  *deltaMin_Q15;
} ropus_nlsf_cb;

static const ropus_nlsf_cb ropus_nlsf_cb_wb =
{
   32, 16,
   9830,     /* SILK_FIX_CONST(0.15, 16)      */
   427,      /* SILK_FIX_CONST(1.0/0.15, 6)   */
   ropus_NLSF_CB1_WB_Q8,
   ropus_NLSF_CB1_WB_Wght_Q9,
   ropus_NLSF_CB1_iCDF_WB,
   ropus_NLSF_PRED_WB_Q8,
   ropus_NLSF_CB2_SELECT_WB,
   ropus_NLSF_CB2_iCDF_WB,
   ropus_NLSF_CB2_BITS_WB_Q5,
   ropus_NLSF_DELTA_MIN_WB_Q15
};

static const ropus_nlsf_cb ropus_nlsf_cb_nb_mb =
{
   32, 10,
   11796,    /* SILK_FIX_CONST(0.18, 16)      */
   356,      /* SILK_FIX_CONST(1.0/0.18, 6)   */
   ropus_NLSF_CB1_NB_MB_Q8,
   ropus_NLSF_CB1_NB_MB_Wght_Q9,
   ropus_NLSF_CB1_iCDF_NB_MB,
   ropus_NLSF_PRED_NB_MB_Q8,
   ropus_NLSF_CB2_SELECT_NB_MB,
   ropus_NLSF_CB2_iCDF_NB_MB,
   ropus_NLSF_CB2_BITS_NB_MB_Q5,
   ropus_NLSF_DELTA_MIN_NB_MB_Q15
};

typedef struct
{
   int8_t  GainsIndices[ROPUS_SILK_MAX_NB_SUBFR];
   int8_t  LTPIndex[ROPUS_SILK_MAX_NB_SUBFR];
   int8_t  NLSFIndices[ROPUS_SILK_MAX_LPC_ORDER + 1];
   int16_t lagIndex;
   int8_t  contourIndex;
   int8_t  signalType;
   int8_t  quantOffsetType;
   int8_t  NLSFInterpCoef_Q2;
   int8_t  PERIndex;
   int8_t  LTP_scaleIndex;
   int8_t  Seed;
} ropus_silk_indices;

typedef struct
{
   int fs_kHz;
   int frame_length, subfr_length, nb_subfr, ltp_mem_length;
   int LPC_order;
   int nFramesPerPacket, nFramesDecoded;
   int VAD_flags[ROPUS_SILK_MAX_FRAMES];
   int LBRR_flag, LBRR_flags[ROPUS_SILK_MAX_FRAMES];
   int ec_prevSignalType;
   int16_t ec_prevLagIndex;
   int prevSignalType;
   int lagPrev;
   int8_t LastGainIndex;
   int first_frame_after_reset;
   ropus_silk_indices indices;
   const ropus_nlsf_cb *psNLSF_CB;
   const uint8_t *pitch_lag_low_bits_iCDF;
   const uint8_t *pitch_contour_iCDF;
   int16_t prevNLSF_Q15[ROPUS_SILK_MAX_LPC_ORDER];
   /* synthesis state */
   int16_t outBuf[ROPUS_SILK_MAX_FRAME_LEN
      + 20 * 16 /* ltp_mem at 16 kHz */];
   int32_t sLPC_Q14_buf[ROPUS_SILK_MAX_LPC_ORDER];
   int32_t exc_Q14[ROPUS_SILK_MAX_FRAME_LEN];
} ropus_silk_state;

/* silk decode_indices (silk/decode_indices.c) */
static void ropus_silk_decode_indices(ropus_silk_state *st, ropus_ec *dec,
      int FrameIndex, int decode_LBRR, int condCoding /*0 indep,2 cond*/)
{
   int i, k, Ix;
   int decode_absolute_lagIndex, delta_lagIndex;
   int16_t ec_ix[ROPUS_SILK_MAX_LPC_ORDER];
   uint8_t pred_Q8[ROPUS_SILK_MAX_LPC_ORDER];

   if (decode_LBRR || st->VAD_flags[FrameIndex])
      Ix = ropus_ec_dec_icdf(dec, ropus_type_offset_VAD_iCDF, 8) + 2;
   else
      Ix = ropus_ec_dec_icdf(dec, ropus_type_offset_no_VAD_iCDF, 8);
   st->indices.signalType = (int8_t)(Ix >> 1);
   st->indices.quantOffsetType = (int8_t)(Ix & 1);

   if (condCoding == 2)
      st->indices.GainsIndices[0] =
         (int8_t)ropus_ec_dec_icdf(dec, ropus_delta_gain_iCDF, 8);
   else
   {
      st->indices.GainsIndices[0] = (int8_t)(ropus_ec_dec_icdf(dec,
         ropus_gain_iCDF[st->indices.signalType], 8) << 3);
      st->indices.GainsIndices[0] +=
         (int8_t)ropus_ec_dec_icdf(dec, ropus_uniform8_iCDF, 8);
   }
   for (i = 1; i < st->nb_subfr; i++)
      st->indices.GainsIndices[i] =
         (int8_t)ropus_ec_dec_icdf(dec, ropus_delta_gain_iCDF, 8);

   st->indices.NLSFIndices[0] = (int8_t)ropus_ec_dec_icdf(dec,
      &st->psNLSF_CB->CB1_iCDF[(st->indices.signalType >> 1)
         * st->psNLSF_CB->nVectors], 8);
   /* NLSF_unpack */
   {
      const uint8_t *ec_sel_ptr = &st->psNLSF_CB->ec_sel[
         st->indices.NLSFIndices[0] * st->psNLSF_CB->order / 2];
      for (i = 0; i < st->psNLSF_CB->order; i += 2)
      {
         uint8_t entry = *ec_sel_ptr++;
         ec_ix[i] = (int16_t)(((entry >> 1) & 7)
            * (2 * ROPUS_NLSF_QUANT_MAX_AMP + 1));
         pred_Q8[i] = st->psNLSF_CB->pred_Q8[i
            + (entry & 1) * (st->psNLSF_CB->order - 1)];
         ec_ix[i + 1] = (int16_t)(((entry >> 5) & 7)
            * (2 * ROPUS_NLSF_QUANT_MAX_AMP + 1));
         pred_Q8[i + 1] = st->psNLSF_CB->pred_Q8[i
            + ((entry >> 4) & 1) * (st->psNLSF_CB->order - 1) + 1];
      }
   }
   (void)pred_Q8;
   for (i = 0; i < st->psNLSF_CB->order; i++)
   {
      Ix = ropus_ec_dec_icdf(dec, &st->psNLSF_CB->ec_iCDF[ec_ix[i]], 8);
      if (Ix == 0)
         Ix -= ropus_ec_dec_icdf(dec, ropus_NLSF_EXT_iCDF, 8);
      else if (Ix == 2 * ROPUS_NLSF_QUANT_MAX_AMP)
         Ix += ropus_ec_dec_icdf(dec, ropus_NLSF_EXT_iCDF, 8);
      st->indices.NLSFIndices[i + 1] =
         (int8_t)(Ix - ROPUS_NLSF_QUANT_MAX_AMP);
   }

   if (st->nb_subfr == ROPUS_SILK_MAX_NB_SUBFR)
      st->indices.NLSFInterpCoef_Q2 = (int8_t)ropus_ec_dec_icdf(dec,
         ropus_NLSF_interpolation_factor_iCDF, 8);
   else
      st->indices.NLSFInterpCoef_Q2 = 4;

   if (st->indices.signalType == 2)      /* TYPE_VOICED */
   {
      decode_absolute_lagIndex = 1;
      if (condCoding == 2 && st->ec_prevSignalType == 2)
      {
         delta_lagIndex = (int16_t)ropus_ec_dec_icdf(dec,
            ropus_pitch_delta_iCDF, 8);
         if (delta_lagIndex > 0)
         {
            delta_lagIndex = delta_lagIndex - 9;
            st->indices.lagIndex =
               (int16_t)(st->ec_prevLagIndex + delta_lagIndex);
            decode_absolute_lagIndex = 0;
         }
      }
      if (decode_absolute_lagIndex)
      {
         st->indices.lagIndex = (int16_t)(ropus_ec_dec_icdf(dec,
            ropus_pitch_lag_iCDF, 8) * (st->fs_kHz >> 1));
         st->indices.lagIndex += (int16_t)ropus_ec_dec_icdf(dec,
            st->pitch_lag_low_bits_iCDF, 8);
      }
      st->ec_prevLagIndex = st->indices.lagIndex;
      st->indices.contourIndex = (int8_t)ropus_ec_dec_icdf(dec,
         st->pitch_contour_iCDF, 8);
      st->indices.PERIndex = (int8_t)ropus_ec_dec_icdf(dec,
         ropus_LTP_per_index_iCDF, 8);
      for (k = 0; k < st->nb_subfr; k++)
      {
         static const uint8_t *const ltp_icdf[3] =
         {
            ropus_LTP_gain_iCDF_0, ropus_LTP_gain_iCDF_1,
            ropus_LTP_gain_iCDF_2
         };
         st->indices.LTPIndex[k] = (int8_t)ropus_ec_dec_icdf(dec,
            ltp_icdf[(int)st->indices.PERIndex], 8);
      }
      if (condCoding == 0)               /* CODE_INDEPENDENTLY          */
         st->indices.LTP_scaleIndex =
            (int8_t)ropus_ec_dec_icdf(dec, ropus_LTPscale_iCDF, 8);
      else
         st->indices.LTP_scaleIndex = 0;
   }
   st->ec_prevSignalType = st->indices.signalType;
   st->indices.Seed = (int8_t)ropus_ec_dec_icdf(dec, ropus_uniform4_iCDF, 8);
}

/* silk shell/pulse decode (decode_pulses.c, shell_coder.c, code_signs.c) */
static INLINE void ropus_silk_decode_split(int16_t *c1, int16_t *c2,
      ropus_ec *dec, int p, const uint8_t *shell_table)
{
   if (p > 0)
   {
      c1[0] = (int16_t)ropus_ec_dec_icdf(dec,
         &shell_table[ropus_shell_code_table_offsets[p]], 8);
      c2[0] = (int16_t)(p - c1[0]);
   }
   else
   {
      c1[0] = 0;
      c2[0] = 0;
   }
}

static void ropus_silk_shell_decoder(int16_t *pulses0, ropus_ec *dec,
      int pulses4)
{
   int16_t pulses3[2], pulses2[4], pulses1[8];
   ropus_silk_decode_split(&pulses3[0], &pulses3[1], dec, pulses4,
      ropus_shell_code_table3);
   ropus_silk_decode_split(&pulses2[0], &pulses2[1], dec, pulses3[0],
      ropus_shell_code_table2);
   ropus_silk_decode_split(&pulses1[0], &pulses1[1], dec, pulses2[0],
      ropus_shell_code_table1);
   ropus_silk_decode_split(&pulses0[0], &pulses0[1], dec, pulses1[0],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses0[2], &pulses0[3], dec, pulses1[1],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses1[2], &pulses1[3], dec, pulses2[1],
      ropus_shell_code_table1);
   ropus_silk_decode_split(&pulses0[4], &pulses0[5], dec, pulses1[2],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses0[6], &pulses0[7], dec, pulses1[3],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses2[2], &pulses2[3], dec, pulses3[1],
      ropus_shell_code_table2);
   ropus_silk_decode_split(&pulses1[4], &pulses1[5], dec, pulses2[2],
      ropus_shell_code_table1);
   ropus_silk_decode_split(&pulses0[8], &pulses0[9], dec, pulses1[4],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses0[10], &pulses0[11], dec, pulses1[5],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses1[6], &pulses1[7], dec, pulses2[3],
      ropus_shell_code_table1);
   ropus_silk_decode_split(&pulses0[12], &pulses0[13], dec, pulses1[6],
      ropus_shell_code_table0);
   ropus_silk_decode_split(&pulses0[14], &pulses0[15], dec, pulses1[7],
      ropus_shell_code_table0);
}

static void ropus_silk_decode_pulses(ropus_ec *dec, int16_t *pulses,
      int signalType, int quantOffsetType, int frame_length)
{
   int i, j, k, iter, abs_q, nLS, RateLevelIndex;
   int sum_pulses[ROPUS_SILK_MAX_SHELL_BLOCKS];
   int nLshifts[ROPUS_SILK_MAX_SHELL_BLOCKS];
   int16_t *pulses_ptr;
   const uint8_t *cdf_ptr;

   RateLevelIndex = ropus_ec_dec_icdf(dec,
      ropus_rate_levels_iCDF[signalType >> 1], 8);
   iter = frame_length >> 4;
   if (iter * ROPUS_SILK_SHELL_LEN < frame_length)
      iter++;                            /* 10 ms @ 12 kHz              */

   cdf_ptr = ropus_pulses_per_block_iCDF[RateLevelIndex];
   for (i = 0; i < iter; i++)
   {
      nLshifts[i] = 0;
      sum_pulses[i] = ropus_ec_dec_icdf(dec, cdf_ptr, 8);
      while (sum_pulses[i] == ROPUS_SILK_MAX_PULSES + 1)
      {
         nLshifts[i]++;
         sum_pulses[i] = ropus_ec_dec_icdf(dec,
            ropus_pulses_per_block_iCDF[10 - 1]
            + (nLshifts[i] == 10), 8);
      }
   }
   for (i = 0; i < iter; i++)
   {
      if (sum_pulses[i] > 0)
         ropus_silk_shell_decoder(&pulses[i * ROPUS_SILK_SHELL_LEN],
            dec, sum_pulses[i]);
      else
         memset(&pulses[i * ROPUS_SILK_SHELL_LEN], 0,
            ROPUS_SILK_SHELL_LEN * sizeof(pulses[0]));
   }
   for (i = 0; i < iter; i++)
   {
      if (nLshifts[i] > 0)
      {
         nLS = nLshifts[i];
         pulses_ptr = &pulses[i * ROPUS_SILK_SHELL_LEN];
         for (k = 0; k < ROPUS_SILK_SHELL_LEN; k++)
         {
            abs_q = pulses_ptr[k];
            for (j = 0; j < nLS; j++)
            {
               abs_q = abs_q << 1;
               abs_q += ropus_ec_dec_icdf(dec, ropus_lsb_iCDF, 8);
            }
            pulses_ptr[k] = (int16_t)abs_q;
         }
         sum_pulses[i] |= nLS << 5;
      }
   }
   /* decode signs */
   {
      uint8_t icdf[2];
      int16_t *q_ptr = pulses;
      const uint8_t *icdf_ptr;
      int length;
      icdf[1] = 0;
      i = 7 * (quantOffsetType + (signalType << 1));
      icdf_ptr = &ropus_sign_iCDF[i];
      length = (frame_length + ROPUS_SILK_SHELL_LEN / 2) >> 4;
      for (i = 0; i < length; i++)
      {
         int p = sum_pulses[i];
         if (p > 0)
         {
            icdf[0] = icdf_ptr[ropus_imin(p & 0x1F, 6)];
            for (j = 0; j < ROPUS_SILK_SHELL_LEN; j++)
               if (q_ptr[j] > 0)
                  q_ptr[j] = (int16_t)(q_ptr[j]
                     * (2 * ropus_ec_dec_icdf(dec, icdf, 8) - 1));
         }
         q_ptr += ROPUS_SILK_SHELL_LEN;
      }
   }
}

/* SILK fixed-point macros (silk/SigProc_FIX.h, macros.h), int64 forms. */
#define ROPUS_SILK_SMULWB(a, b) \
   ((int32_t)(((a) * (int64_t)((int16_t)(b))) >> 16))
#define ROPUS_SILK_SMLAWB(a, b, c) \
   ((int32_t)((a) + (((b) * (int64_t)((int16_t)(c))) >> 16)))
#define ROPUS_SILK_SMULWW(a, b)  ((int32_t)(((int64_t)(a) * (b)) >> 16))
#define ROPUS_SILK_SMLAWW(a, b, c) \
   ((int32_t)((a) + (((int64_t)(b) * (c)) >> 16)))
#define ROPUS_SILK_SMULBB(a, b) \
   ((int32_t)((int16_t)(a)) * (int32_t)((int16_t)(b)))
#define ROPUS_SILK_SMLABB(a, b, c) ((a) + ROPUS_SILK_SMULBB(b, c))
#define ROPUS_SILK_SMULL(a, b)   ((int64_t)(a) * (b))
#define ROPUS_SILK_SMMUL(a, b)   ((int32_t)(ROPUS_SILK_SMULL(a, b) >> 32))
#define ROPUS_SILK_RSHIFT_ROUND(a, s) \
   ((s) == 1 ? ((a) >> 1) + ((a) & 1) : (((a) >> ((s) - 1)) + 1) >> 1)
#define ROPUS_SILK_RSHIFT_ROUND64(a, s) \
   ((s) == 1 ? ((a) >> 1) + ((a) & 1) : (((a) >> ((s) - 1)) + 1) >> 1)
#define ROPUS_SILK_SAT16(a) \
   ((a) > 32767 ? 32767 : ((a) < -32768 ? -32768 : (a)))
#define ROPUS_SILK_ADD_SAT16(a, b) \
   ((int16_t)ROPUS_SILK_SAT16((int32_t)(a) + (b)))
#define ROPUS_SILK_LIMIT(a, l1, l2) \
   ((l1) > (l2) ? ((a) > (l1) ? (l1) : ((a) < (l2) ? (l2) : (a))) \
                : ((a) > (l2) ? (l2) : ((a) < (l1) ? (l1) : (a))))
#define ROPUS_SILK_ABS(a) (((a) > 0) ? (a) : -(a))
#define ROPUS_SILK_RAND(seed) \
   ((int32_t)((uint32_t)907633515 + (uint32_t)(seed) * 196314165u))
#define ROPUS_SILK_ADD32_OVF(a, b) ((int32_t)((uint32_t)(a) + (uint32_t)(b)))

static INLINE int ropus_silk_clz32(int32_t in32)
{
   return in32 ? 32 - ropus_ec_ilog((uint32_t)in32) : 32;
}

static INLINE int32_t ropus_silk_lshift_sat32(int32_t a, int s)
{
   int32_t lo = (int32_t)((int32_t)0x80000000 >> s);
   int32_t hi = 0x7fffffff >> s;
   return (int32_t)((uint32_t)ROPUS_SILK_LIMIT(a, lo, hi) << s);
}

static int32_t ropus_silk_inverse32_varq(int32_t b32, int Qres)
{
   int b_headrm, lshift;
   int32_t b32_inv, b32_nrm, err_Q32, result;
   b_headrm = ropus_silk_clz32(ROPUS_SILK_ABS(b32)) - 1;
   b32_nrm = (int32_t)((uint32_t)b32 << b_headrm);
   b32_inv = (0x7fffffff >> 2) / (b32_nrm >> 16);
   result = (int32_t)((uint32_t)b32_inv << 16);
   err_Q32 = (int32_t)((uint32_t)(((int32_t)1 << 29)
      - ROPUS_SILK_SMULWB(b32_nrm, b32_inv)) << 3);
   result = ROPUS_SILK_SMLAWW(result, err_Q32, b32_inv);
   lshift = 61 - b_headrm - Qres;
   if (lshift <= 0)
      return ropus_silk_lshift_sat32(result, -lshift);
   else if (lshift < 32)
      return result >> lshift;
   return 0;
}

/* silk_log2lin (silk/log2lin.c) */
static int32_t ropus_silk_log2lin(int32_t inLog_Q7)
{
   int32_t out, frac_Q7;
   if (inLog_Q7 < 0)
      return 0;
   else if (inLog_Q7 >= 3967)
      return 0x7fffffff;
   out = 1 << (inLog_Q7 >> 7);
   frac_Q7 = inLog_Q7 & 0x7F;
   if (inLog_Q7 < 2048)
      out = out + ((out * ROPUS_SILK_SMLAWB(frac_Q7,
         ROPUS_SILK_SMULBB(frac_Q7, 128 - frac_Q7), -174)) >> 7);
   else
      out = out + (out >> 7) * ROPUS_SILK_SMLAWB(frac_Q7,
         ROPUS_SILK_SMULBB(frac_Q7, 128 - frac_Q7), -174);
   return out;
}

/* silk_gains_dequant (silk/gain_quant.c) */
#define ROPUS_SILK_QGAIN_OFFSET      ((2 * 128) / 6 + 16 * 128)
#define ROPUS_SILK_QGAIN_INV_SCALE   ((65536 * (((88 - 2) * 128) / 6)) / (64 - 1))

static void ropus_silk_gains_dequant(int32_t *gain_Q16, const int8_t *ind,
      int8_t *prev_ind, int conditional, int nb_subfr)
{
   int k, ind_tmp, double_step_size_threshold;
   for (k = 0; k < nb_subfr; k++)
   {
      if (k == 0 && conditional == 0)
         *prev_ind = (int8_t)ropus_imax(ind[k], *prev_ind - 16);
      else
      {
         ind_tmp = ind[k] + (-4);          /* MIN_DELTA_GAIN_QUANT     */
         double_step_size_threshold = 2 * 36 - 64 + *prev_ind;
         if (ind_tmp > double_step_size_threshold)
            *prev_ind = (int8_t)(*prev_ind + (ind_tmp << 1)
               - double_step_size_threshold);
         else
            *prev_ind = (int8_t)(*prev_ind + ind_tmp);
      }
      *prev_ind = (int8_t)ROPUS_SILK_LIMIT(*prev_ind, 0, 64 - 1);
      gain_Q16[k] = ropus_silk_log2lin(ropus_min32(
         ROPUS_SILK_SMULWB(ROPUS_SILK_QGAIN_INV_SCALE, *prev_ind)
         + ROPUS_SILK_QGAIN_OFFSET, 3967));
   }
}

/* silk_NLSF_stabilize (NLSF_stabilize.c + sort.c) */
static void ropus_silk_insertion_sort_i16(int16_t *a, int L)
{
   int i, j, value;
   for (i = 1; i < L; i++)
   {
      value = a[i];
      for (j = i - 1; (j >= 0) && (value < a[j]); j--)
         a[j + 1] = a[j];
      a[j + 1] = (int16_t)value;
   }
}

static void ropus_silk_nlsf_stabilize(int16_t *NLSF_Q15,
      const int16_t *NDeltaMin_Q15, int L)
{
   int i, I = 0, k, loops;
   int16_t center_freq_Q15;
   int32_t diff_Q15, min_diff_Q15, min_center_Q15, max_center_Q15;
   for (loops = 0; loops < 20; loops++)
   {
      min_diff_Q15 = NLSF_Q15[0] - NDeltaMin_Q15[0];
      I = 0;
      for (i = 1; i <= L - 1; i++)
      {
         diff_Q15 = NLSF_Q15[i] - (NLSF_Q15[i - 1] + NDeltaMin_Q15[i]);
         if (diff_Q15 < min_diff_Q15)
         {
            min_diff_Q15 = diff_Q15;
            I = i;
         }
      }
      diff_Q15 = (1 << 15) - (NLSF_Q15[L - 1] + NDeltaMin_Q15[L]);
      if (diff_Q15 < min_diff_Q15)
      {
         min_diff_Q15 = diff_Q15;
         I = L;
      }
      if (min_diff_Q15 >= 0)
         return;
      if (I == 0)
         NLSF_Q15[0] = NDeltaMin_Q15[0];
      else if (I == L)
         NLSF_Q15[L - 1] = (int16_t)((1 << 15) - NDeltaMin_Q15[L]);
      else
      {
         min_center_Q15 = 0;
         for (k = 0; k < I; k++)
            min_center_Q15 += NDeltaMin_Q15[k];
         min_center_Q15 += NDeltaMin_Q15[I] >> 1;
         max_center_Q15 = 1 << 15;
         for (k = L; k > I; k--)
            max_center_Q15 -= NDeltaMin_Q15[k];
         max_center_Q15 -= NDeltaMin_Q15[I] >> 1;
         center_freq_Q15 = (int16_t)ROPUS_SILK_LIMIT(
            ROPUS_SILK_RSHIFT_ROUND((int32_t)NLSF_Q15[I - 1]
               + (int32_t)NLSF_Q15[I], 1),
            min_center_Q15, max_center_Q15);
         NLSF_Q15[I - 1] = (int16_t)(center_freq_Q15
            - (NDeltaMin_Q15[I] >> 1));
         NLSF_Q15[I] = (int16_t)(NLSF_Q15[I - 1] + NDeltaMin_Q15[I]);
      }
   }
   if (loops == 20)
   {
      ropus_silk_insertion_sort_i16(&NLSF_Q15[0], L);
      NLSF_Q15[0] = (int16_t)ropus_imax(NLSF_Q15[0], NDeltaMin_Q15[0]);
      for (i = 1; i < L; i++)
         NLSF_Q15[i] = (int16_t)ropus_imax(NLSF_Q15[i],
            ROPUS_SILK_ADD_SAT16(NLSF_Q15[i - 1], NDeltaMin_Q15[i]));
      NLSF_Q15[L - 1] = (int16_t)ropus_imin(NLSF_Q15[L - 1],
         (1 << 15) - NDeltaMin_Q15[L]);
      for (i = L - 2; i >= 0; i--)
         NLSF_Q15[i] = (int16_t)ropus_imin(NLSF_Q15[i],
            NLSF_Q15[i + 1] - NDeltaMin_Q15[i + 1]);
   }
}

/* silk_NLSF_decode (NLSF_decode.c) */
static void ropus_silk_nlsf_decode(int16_t *pNLSF_Q15, const int8_t *NLSFIndices,
      const ropus_nlsf_cb *cb)
{
   int i;
   uint8_t pred_Q8[ROPUS_SILK_MAX_LPC_ORDER];
   int16_t ec_ix[ROPUS_SILK_MAX_LPC_ORDER];
   int16_t res_Q10[ROPUS_SILK_MAX_LPC_ORDER];
   int32_t NLSF_Q15_tmp;
   const uint8_t *pCB_element;
   const int16_t *pCB_Wght_Q9;

   /* NLSF_unpack */
   {
      const uint8_t *ec_sel_ptr = &cb->ec_sel[NLSFIndices[0]
         * cb->order / 2];
      for (i = 0; i < cb->order; i += 2)
      {
         uint8_t entry = *ec_sel_ptr++;
         ec_ix[i] = (int16_t)(((entry >> 1) & 7)
            * (2 * ROPUS_NLSF_QUANT_MAX_AMP + 1));
         pred_Q8[i] = cb->pred_Q8[i + (entry & 1) * (cb->order - 1)];
         ec_ix[i + 1] = (int16_t)(((entry >> 5) & 7)
            * (2 * ROPUS_NLSF_QUANT_MAX_AMP + 1));
         pred_Q8[i + 1] = cb->pred_Q8[i
            + ((entry >> 4) & 1) * (cb->order - 1) + 1];
      }
   }
   (void)ec_ix;
   /* residual dequant, backward */
   {
      int out_Q10 = 0, pred_Q10;
      for (i = cb->order - 1; i >= 0; i--)
      {
         pred_Q10 = ROPUS_SILK_SMULBB(out_Q10, (int16_t)pred_Q8[i]) >> 8;
         out_Q10 = (int)NLSFIndices[i + 1] * 1024;
         if (out_Q10 > 0)
            out_Q10 = (int16_t)(out_Q10 - 102);  /* 0.1 in Q10        */
         else if (out_Q10 < 0)
            out_Q10 = (int16_t)(out_Q10 + 102);
         out_Q10 = ROPUS_SILK_SMLAWB(pred_Q10, (int32_t)out_Q10,
            cb->quantStepSize_Q16);
         res_Q10[i] = (int16_t)out_Q10;
      }
   }
   pCB_element = &cb->CB1_NLSF_Q8[NLSFIndices[0] * cb->order];
   pCB_Wght_Q9 = &cb->CB1_Wght_Q9[NLSFIndices[0] * cb->order];
   for (i = 0; i < cb->order; i++)
   {
      NLSF_Q15_tmp = ((((int32_t)res_Q10[i] * 16384) / pCB_Wght_Q9[i]))
         + ((int32_t)(int16_t)pCB_element[i] << 7);
      pNLSF_Q15[i] = (int16_t)ROPUS_SILK_LIMIT(NLSF_Q15_tmp, 0, 32767);
   }
   ropus_silk_nlsf_stabilize(pNLSF_Q15, cb->deltaMin_Q15, cb->order);
}

/* silk_bwexpander_32 */
static void ropus_silk_bwexpander_32(int32_t *ar, int d, int32_t chirp_Q16)
{
   int i;
   int32_t chirp_minus_one_Q16 = chirp_Q16 - 65536;
   for (i = 0; i < d - 1; i++)
   {
      ar[i] = ROPUS_SILK_SMULWW(chirp_Q16, ar[i]);
      chirp_Q16 += ROPUS_SILK_RSHIFT_ROUND(chirp_Q16 * chirp_minus_one_Q16, 16);
   }
   ar[d - 1] = ROPUS_SILK_SMULWW(chirp_Q16, ar[d - 1]);
}

/* silk_LPC_fit */
static void ropus_silk_lpc_fit(int16_t *a_QOUT, int32_t *a_QIN, int QOUT,
      int QIN, int d)
{
   int i, k, idx = 0;
   int32_t maxabs, absval, chirp_Q16;
   for (i = 0; i < 10; i++)
   {
      maxabs = 0;
      for (k = 0; k < d; k++)
      {
         absval = ROPUS_SILK_ABS(a_QIN[k]);
         if (absval > maxabs)
         {
            maxabs = absval;
            idx = k;
         }
      }
      maxabs = ROPUS_SILK_RSHIFT_ROUND(maxabs, QIN - QOUT);
      if (maxabs > 32767)
      {
         maxabs = ropus_min32(maxabs, 163838);
         chirp_Q16 = 65470   /* SILK_FIX_CONST(0.999, 16)              */
            - (((maxabs - 32767) << 14)
               / ((maxabs * (idx + 1)) >> 2));
         ropus_silk_bwexpander_32(a_QIN, d, chirp_Q16);
      }
      else
         break;
   }
   if (i == 10)
      for (k = 0; k < d; k++)
      {
         a_QOUT[k] = (int16_t)ROPUS_SILK_SAT16(
            ROPUS_SILK_RSHIFT_ROUND(a_QIN[k], QIN - QOUT));
         a_QIN[k] = (int32_t)((uint32_t)a_QOUT[k] << (QIN - QOUT));
      }
   else
      for (k = 0; k < d; k++)
         a_QOUT[k] = (int16_t)ROPUS_SILK_RSHIFT_ROUND(a_QIN[k], QIN - QOUT);
}

/* silk_LPC_inverse_pred_gain (LPC_inv_pred_gain.c), QA = 24 */
#define ROPUS_SILK_INVGAIN_QA 24
#define ROPUS_SILK_A_LIMIT 16773022        /* SILK_FIX_CONST(0.99975, 24)   */
#define ROPUS_SILK_MUL32_FRAC_Q(a, b, Q) \
   ((int32_t)ROPUS_SILK_RSHIFT_ROUND64(ROPUS_SILK_SMULL(a, b), Q))
#define ROPUS_SILK_SUB_SAT32(a, b) \
   ((int32_t)ropus_min32(ropus_max32((int64_t)(a) - (b) < -2147483647 - 1 \
      ? -2147483647 - 1 : (int32_t)((int64_t)(a) - (b)), \
      -2147483647 - 1), 2147483647))

static INLINE int32_t ropus_silk_sub_sat32(int32_t a, int32_t b)
{
   int64_t r = (int64_t)a - b;
   if (r > 2147483647)
      return 2147483647;
   if (r < -2147483647 - 1)
      return -2147483647 - 1;
   return (int32_t)r;
}

static int32_t ropus_silk_lpc_inv_pred_gain_qa(int32_t *A_QA, int order)
{
   int k, n, mult2Q;
   int32_t invGain_Q30, rc_Q31, rc_mult1_Q30, rc_mult2, tmp1, tmp2;
   invGain_Q30 = (int32_t)1 << 30;
   for (k = order - 1; k > 0; k--)
   {
      if (A_QA[k] > ROPUS_SILK_A_LIMIT || A_QA[k] < -ROPUS_SILK_A_LIMIT)
         return 0;
      rc_Q31 = -(int32_t)((uint32_t)A_QA[k] << (31 - ROPUS_SILK_INVGAIN_QA));
      rc_mult1_Q30 = ((int32_t)1 << 30) - ROPUS_SILK_SMMUL(rc_Q31, rc_Q31);
      invGain_Q30 = (int32_t)((uint32_t)ROPUS_SILK_SMMUL(invGain_Q30,
         rc_mult1_Q30) << 2);
      if (invGain_Q30 < 107374)  /* SILK_FIX_CONST(1/1e4, 30)          */
         return 0;
      mult2Q = 32 - ropus_silk_clz32(ROPUS_SILK_ABS(rc_mult1_Q30));
      rc_mult2 = ropus_silk_inverse32_varq(rc_mult1_Q30, mult2Q + 30);
      for (n = 0; n < (k + 1) >> 1; n++)
      {
         int64_t tmp64;
         tmp1 = A_QA[n];
         tmp2 = A_QA[k - n - 1];
         tmp64 = ROPUS_SILK_RSHIFT_ROUND64(ROPUS_SILK_SMULL(ropus_silk_sub_sat32(tmp1,
            ROPUS_SILK_MUL32_FRAC_Q(tmp2, rc_Q31, 31)), rc_mult2), mult2Q);
         if (tmp64 > 2147483647 || tmp64 < -2147483647 - 1)
            return 0;
         A_QA[n] = (int32_t)tmp64;
         tmp64 = ROPUS_SILK_RSHIFT_ROUND64(ROPUS_SILK_SMULL(ropus_silk_sub_sat32(tmp2,
            ROPUS_SILK_MUL32_FRAC_Q(tmp1, rc_Q31, 31)), rc_mult2), mult2Q);
         if (tmp64 > 2147483647 || tmp64 < -2147483647 - 1)
            return 0;
         A_QA[k - n - 1] = (int32_t)tmp64;
      }
   }
   if (A_QA[0] > ROPUS_SILK_A_LIMIT || A_QA[0] < -ROPUS_SILK_A_LIMIT)
      return 0;
   rc_Q31 = -(int32_t)((uint32_t)A_QA[0] << (31 - ROPUS_SILK_INVGAIN_QA));
   rc_mult1_Q30 = ((int32_t)1 << 30) - ROPUS_SILK_SMMUL(rc_Q31, rc_Q31);
   invGain_Q30 = (int32_t)((uint32_t)ROPUS_SILK_SMMUL(invGain_Q30,
      rc_mult1_Q30) << 2);
   if (invGain_Q30 < 107374)
      return 0;
   return invGain_Q30;
}

static int32_t ropus_silk_lpc_inv_pred_gain(const int16_t *A_Q12, int order)
{
   int k;
   int32_t Atmp_QA[ROPUS_SILK_MAX_LPC_ORDER];
   int32_t DC_resp = 0;
   for (k = 0; k < order; k++)
   {
      DC_resp += (int32_t)A_Q12[k];
      Atmp_QA[k] = (int32_t)((uint32_t)A_Q12[k]
         << (ROPUS_SILK_INVGAIN_QA - 12));
   }
   if (DC_resp >= 4096)
      return 0;
   return ropus_silk_lpc_inv_pred_gain_qa(Atmp_QA, order);
}

/* silk_NLSF2A (NLSF2A.c), QA = 16 */
static void ropus_silk_nlsf2a_find_poly(int32_t *out, const int32_t *cLSF,
      int dd)
{
   int k, n;
   int32_t ftmp;
   out[0] = (int32_t)1 << 16;
   out[1] = -cLSF[0];
   for (k = 1; k < dd; k++)
   {
      ftmp = cLSF[2 * k];
      out[k + 1] = (int32_t)((uint32_t)out[k - 1] << 1)
         - (int32_t)ROPUS_SILK_RSHIFT_ROUND64(ROPUS_SILK_SMULL(ftmp, out[k]), 16);
      for (n = k; n > 1; n--)
         out[n] += out[n - 2]
            - (int32_t)ROPUS_SILK_RSHIFT_ROUND64(
               ROPUS_SILK_SMULL(ftmp, out[n - 1]), 16);
      out[1] -= ftmp;
   }
}

static void ropus_silk_nlsf2a(int16_t *a_Q12, const int16_t *NLSF, int d)
{
   static const uint8_t ordering16[16] =
      { 0, 15, 8, 7, 4, 11, 12, 3, 2, 13, 10, 5, 6, 9, 14, 1 };
   static const uint8_t ordering10[10] =
      { 0, 9, 6, 3, 4, 5, 8, 1, 2, 7 };
   const uint8_t *ordering;
   int k, i, dd;
   int32_t cos_LSF_QA[ROPUS_SILK_MAX_LPC_ORDER] = {0};
   int32_t P[ROPUS_SILK_MAX_LPC_ORDER / 2 + 1];
   int32_t Q[ROPUS_SILK_MAX_LPC_ORDER / 2 + 1];
   int32_t Ptmp, Qtmp, f_int, f_frac, cos_val, delta;
   int32_t a32_QA1[ROPUS_SILK_MAX_LPC_ORDER];

   ordering = d == 16 ? ordering16 : ordering10;
   for (k = 0; k < d; k++)
   {
      f_int = NLSF[k] >> (15 - 7);
      f_frac = NLSF[k] - (f_int << (15 - 7));
      cos_val = ropus_LSFCosTab_FIX_Q12[f_int];
      delta = ropus_LSFCosTab_FIX_Q12[f_int + 1] - cos_val;
      cos_LSF_QA[ordering[k]] = ROPUS_SILK_RSHIFT_ROUND(
         (int32_t)((uint32_t)cos_val << 8) + delta * f_frac, 20 - 16);
   }
   dd = d >> 1;
   ropus_silk_nlsf2a_find_poly(P, &cos_LSF_QA[0], dd);
   ropus_silk_nlsf2a_find_poly(Q, &cos_LSF_QA[1], dd);
   for (k = 0; k < dd; k++)
   {
      Ptmp = P[k + 1] + P[k];
      Qtmp = Q[k + 1] - Q[k];
      a32_QA1[k] = -Qtmp - Ptmp;
      a32_QA1[d - k - 1] = Qtmp - Ptmp;
   }
   ropus_silk_lpc_fit(a_Q12, a32_QA1, 12, 16 + 1, d);
   for (i = 0; ropus_silk_lpc_inv_pred_gain(a_Q12, d) == 0 && i < 16; i++)
   {
      ropus_silk_bwexpander_32(a32_QA1, d, 65536 - (2 << i));
      for (k = 0; k < d; k++)
         a_Q12[k] = (int16_t)ROPUS_SILK_RSHIFT_ROUND(a32_QA1[k],
            16 + 1 - 12);
   }
}

/* silk_decode_pitch (decode_pitch.c) */
static void ropus_silk_decode_pitch(int16_t lagIndex, int8_t contourIndex,
      int *pitch_lags, int Fs_kHz, int nb_subfr)
{
   int lag, k, min_lag, max_lag, cbk_size;
   const int8_t *Lag_CB_ptr;
   if (Fs_kHz == 8)
   {
      if (nb_subfr == 4)
      {
         Lag_CB_ptr = &ropus_CB_lags_stage2[0][0];
         cbk_size = 11;
      }
      else
      {
         Lag_CB_ptr = &ropus_CB_lags_stage2_10_ms[0][0];
         cbk_size = 3;
      }
   }
   else
   {
      if (nb_subfr == 4)
      {
         Lag_CB_ptr = &ropus_CB_lags_stage3[0][0];
         cbk_size = 34;
      }
      else
      {
         Lag_CB_ptr = &ropus_CB_lags_stage3_10_ms[0][0];
         cbk_size = 12;
      }
   }
   min_lag = 2 * Fs_kHz;
   max_lag = 18 * Fs_kHz;
   lag = min_lag + lagIndex;
   for (k = 0; k < nb_subfr; k++)
   {
      pitch_lags[k] = lag + Lag_CB_ptr[k * cbk_size + contourIndex];
      pitch_lags[k] = ROPUS_SILK_LIMIT(pitch_lags[k], min_lag, max_lag);
   }
}

/* Decoder control (silk_decoder_control subset). */
typedef struct
{
   int pitchL[ROPUS_SILK_MAX_NB_SUBFR];
   int32_t Gains_Q16[ROPUS_SILK_MAX_NB_SUBFR];
   int16_t PredCoef_Q12[2][ROPUS_SILK_MAX_LPC_ORDER];
   int16_t LTPCoef_Q14[5 * ROPUS_SILK_MAX_NB_SUBFR];
   int LTP_scale_Q14;
} ropus_silk_ctrl;

/* silk_decode_parameters (decode_parameters.c), no-loss path.          */
static void ropus_silk_decode_parameters(ropus_silk_state *st,
      ropus_silk_ctrl *ctrl, int condCoding)
{
   int i, k, Ix;
   int16_t pNLSF_Q15[ROPUS_SILK_MAX_LPC_ORDER];
   int16_t pNLSF0_Q15[ROPUS_SILK_MAX_LPC_ORDER];
   const int8_t *cbk_ptr_Q7;

   ropus_silk_gains_dequant(ctrl->Gains_Q16, st->indices.GainsIndices,
      &st->LastGainIndex, condCoding == 2, st->nb_subfr);

   ropus_silk_nlsf_decode(pNLSF_Q15, st->indices.NLSFIndices, st->psNLSF_CB);
   ropus_silk_nlsf2a(ctrl->PredCoef_Q12[1], pNLSF_Q15, st->LPC_order);

   if (st->first_frame_after_reset == 1)
      st->indices.NLSFInterpCoef_Q2 = 4;

   if (st->indices.NLSFInterpCoef_Q2 < 4)
   {
      for (i = 0; i < st->LPC_order; i++)
         pNLSF0_Q15[i] = (int16_t)(st->prevNLSF_Q15[i]
            + ((st->indices.NLSFInterpCoef_Q2
               * (pNLSF_Q15[i] - st->prevNLSF_Q15[i])) >> 2));
      ropus_silk_nlsf2a(ctrl->PredCoef_Q12[0], pNLSF0_Q15, st->LPC_order);
   }
   else
      memcpy(ctrl->PredCoef_Q12[0], ctrl->PredCoef_Q12[1],
         st->LPC_order * sizeof(int16_t));

   memcpy(st->prevNLSF_Q15, pNLSF_Q15,
      st->LPC_order * sizeof(int16_t));

   if (st->indices.signalType == 2)      /* TYPE_VOICED */
   {
      static const int8_t *const vq_ptrs[3] =
      {
         &ropus_LTP_gain_vq_0[0][0], &ropus_LTP_gain_vq_1[0][0],
         &ropus_LTP_gain_vq_2[0][0]
      };
      ropus_silk_decode_pitch(st->indices.lagIndex, st->indices.contourIndex,
         ctrl->pitchL, st->fs_kHz, st->nb_subfr);
      cbk_ptr_Q7 = vq_ptrs[(int)st->indices.PERIndex];
      for (k = 0; k < st->nb_subfr; k++)
      {
         Ix = st->indices.LTPIndex[k];
         for (i = 0; i < 5; i++)
            ctrl->LTPCoef_Q14[k * 5 + i] =
               (int16_t)((int32_t)cbk_ptr_Q7[Ix * 5 + i] * 128);
      }
      Ix = st->indices.LTP_scaleIndex;
      ctrl->LTP_scale_Q14 = ropus_LTPScales_table_Q14[Ix];
   }
   else
   {
      memset(ctrl->pitchL, 0, st->nb_subfr * sizeof(int));
      memset(ctrl->LTPCoef_Q14, 0,
         5 * st->nb_subfr * sizeof(int16_t));
      st->indices.PERIndex = 0;
      ctrl->LTP_scale_Q14 = 0;
   }
}

/* silk_ADD_SAT32 (silk/macros.h) */
static INLINE int32_t ropus_silk_add_sat32(int32_t a, int32_t b)
{
   uint32_t s = (uint32_t)a + (uint32_t)b;
   if (((s ^ (uint32_t)a) & (s ^ (uint32_t)b)) & 0x80000000u)
      return a < 0 ? (int32_t)0x80000000 : 0x7fffffff;
   return (int32_t)s;
}

static int32_t ropus_silk_div32_varq(int32_t a32, int32_t b32, int Qres)
{
   int a_headrm, b_headrm, lshift;
   int32_t b32_inv, a32_nrm, b32_nrm, result;
   a_headrm = ropus_silk_clz32(ROPUS_SILK_ABS(a32)) - 1;
   a32_nrm = (int32_t)((uint32_t)a32 << a_headrm);
   b_headrm = ropus_silk_clz32(ROPUS_SILK_ABS(b32)) - 1;
   b32_nrm = (int32_t)((uint32_t)b32 << b_headrm);
   b32_inv = (0x7fffffff >> 2) / (b32_nrm >> 16);
   result = ROPUS_SILK_SMULWB(a32_nrm, b32_inv);
   a32_nrm = (int32_t)((uint32_t)a32_nrm
      - ((uint32_t)ROPUS_SILK_SMMUL(b32_nrm, result) << 3));
   result = ROPUS_SILK_SMLAWB(result, a32_nrm, b32_inv);
   lshift = 29 + a_headrm - b_headrm - Qres;
   if (lshift < 0)
      return ropus_silk_lshift_sat32(result, -lshift);
   else if (lshift < 32)
      return result >> lshift;
   return 0;
}

/* silk_LPC_analysis_filter (LPC_analysis_filter.c, USE_CELT_FIR=0)     */
static void ropus_silk_lpc_analysis_filter(int16_t *out, const int16_t *in,
      const int16_t *B, int32_t len, int32_t d)
{
   int j, ix;
   int32_t out32_Q12, out32;
   const int16_t *in_ptr;
   for (ix = d; ix < len; ix++)
   {
      in_ptr = &in[ix - 1];
      out32_Q12 = ROPUS_SILK_SMULBB(in_ptr[0], B[0]);
      out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
         ROPUS_SILK_SMULBB(in_ptr[-1], B[1]));
      out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
         ROPUS_SILK_SMULBB(in_ptr[-2], B[2]));
      out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
         ROPUS_SILK_SMULBB(in_ptr[-3], B[3]));
      out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
         ROPUS_SILK_SMULBB(in_ptr[-4], B[4]));
      out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
         ROPUS_SILK_SMULBB(in_ptr[-5], B[5]));
      for (j = 6; j < d; j += 2)
      {
         out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
            ROPUS_SILK_SMULBB(in_ptr[-j], B[j]));
         out32_Q12 = ROPUS_SILK_ADD32_OVF(out32_Q12,
            ROPUS_SILK_SMULBB(in_ptr[-j - 1], B[j + 1]));
      }
      out32_Q12 = (int32_t)(((uint32_t)(int32_t)in_ptr[1] << 12)
         - (uint32_t)out32_Q12);
      out32 = ROPUS_SILK_RSHIFT_ROUND(out32_Q12, 12);
      out[ix] = (int16_t)ROPUS_SILK_SAT16(out32);
   }
   memset(out, 0, d * sizeof(int16_t));
}

static const int16_t ropus_quant_offsets_Q10[2][2] =
   { { 100, 240 }, { 32, 100 } };   /* UVL/UVH, VL/VH                  */

/* silk_decode_core (decode_core.c), no-loss path.                      */
static void ropus_silk_decode_core(ropus_silk_state *st, ropus_silk_ctrl *ctrl,
      int16_t *xq, const int16_t *pulses, int32_t *prev_gain_Q16,
      int16_t *sLTP, int32_t *sLTP_Q15)
{
   int i, k, lag = 0, start_idx, sLTP_buf_idx;
   int NLSF_interpolation_flag, signalType;
   const int16_t *A_Q12;
   int16_t *B_Q14;
   int16_t *pxq;
   int16_t A_Q12_tmp[ROPUS_SILK_MAX_LPC_ORDER];
   int32_t res_Q14[5 * 16];
   int32_t sLPC_Q14[5 * 16 + ROPUS_SILK_MAX_LPC_ORDER];
   int32_t LTP_pred_Q13, LPC_pred_Q10, Gain_Q10;
   int32_t inv_gain_Q31, gain_adj_Q16, rand_seed, offset_Q10;
   int32_t *pred_lag_ptr, *pexc_Q14, *pres_Q14;

   offset_Q10 = ropus_quant_offsets_Q10[st->indices.signalType >> 1]
      [(int)st->indices.quantOffsetType];
   NLSF_interpolation_flag = st->indices.NLSFInterpCoef_Q2 < 4 ? 1 : 0;

   rand_seed = st->indices.Seed;
   for (i = 0; i < st->frame_length; i++)
   {
      rand_seed = ROPUS_SILK_RAND(rand_seed);
      st->exc_Q14[i] = (int32_t)((uint32_t)pulses[i] << 14);
      if (st->exc_Q14[i] > 0)
         st->exc_Q14[i] -= 80 << 4;      /* QUANT_LEVEL_ADJUST_Q10     */
      else if (st->exc_Q14[i] < 0)
         st->exc_Q14[i] += 80 << 4;
      st->exc_Q14[i] += offset_Q10 << 4;
      if (rand_seed < 0)
         st->exc_Q14[i] = -st->exc_Q14[i];
      rand_seed = ROPUS_SILK_ADD32_OVF(rand_seed, pulses[i]);
   }

   memcpy(sLPC_Q14, st->sLPC_Q14_buf,
      ROPUS_SILK_MAX_LPC_ORDER * sizeof(int32_t));
   pexc_Q14 = st->exc_Q14;
   pxq = xq;
   sLTP_buf_idx = st->ltp_mem_length;

   for (k = 0; k < st->nb_subfr; k++)
   {
      pres_Q14 = res_Q14;
      A_Q12 = ctrl->PredCoef_Q12[k >> 1];
      memcpy(A_Q12_tmp, A_Q12, st->LPC_order * sizeof(int16_t));
      B_Q14 = &ctrl->LTPCoef_Q14[k * 5];
      signalType = st->indices.signalType;
      Gain_Q10 = ctrl->Gains_Q16[k] >> 6;
      inv_gain_Q31 = ropus_silk_inverse32_varq(ctrl->Gains_Q16[k], 47);

      if (ctrl->Gains_Q16[k] != *prev_gain_Q16)
      {
         gain_adj_Q16 = ropus_silk_div32_varq(*prev_gain_Q16,
            ctrl->Gains_Q16[k], 16);
         for (i = 0; i < ROPUS_SILK_MAX_LPC_ORDER; i++)
            sLPC_Q14[i] = ROPUS_SILK_SMULWW(gain_adj_Q16, sLPC_Q14[i]);
      }
      else
         gain_adj_Q16 = (int32_t)1 << 16;

      *prev_gain_Q16 = ctrl->Gains_Q16[k];

      if (signalType == 2)               /* TYPE_VOICED                */
      {
         lag = ctrl->pitchL[k];
         if (k == 0 || (k == 2 && NLSF_interpolation_flag))
         {
            start_idx = st->ltp_mem_length - lag
               - st->LPC_order - 5 / 2;
            if (k == 2)
               memcpy(&st->outBuf[st->ltp_mem_length], xq,
                  2 * st->subfr_length * sizeof(int16_t));
            ropus_silk_lpc_analysis_filter(&sLTP[start_idx],
               &st->outBuf[start_idx + k * st->subfr_length],
               A_Q12, st->ltp_mem_length - start_idx, st->LPC_order);
            if (k == 0)
               inv_gain_Q31 = (int32_t)((uint32_t)ROPUS_SILK_SMULWB(
                  inv_gain_Q31, ctrl->LTP_scale_Q14) << 2);
            for (i = 0; i < lag + 5 / 2; i++)
               sLTP_Q15[sLTP_buf_idx - i - 1] = ROPUS_SILK_SMULWB(
                  inv_gain_Q31, sLTP[st->ltp_mem_length - i - 1]);
         }
         else
         {
            if (gain_adj_Q16 != (int32_t)1 << 16)
               for (i = 0; i < lag + 5 / 2; i++)
                  sLTP_Q15[sLTP_buf_idx - i - 1] = ROPUS_SILK_SMULWW(
                     gain_adj_Q16, sLTP_Q15[sLTP_buf_idx - i - 1]);
         }
      }

      if (signalType == 2)
      {
         pred_lag_ptr = &sLTP_Q15[sLTP_buf_idx - lag + 5 / 2];
         for (i = 0; i < st->subfr_length; i++)
         {
            LTP_pred_Q13 = 2;
            LTP_pred_Q13 = ROPUS_SILK_SMLAWB(LTP_pred_Q13,
               pred_lag_ptr[0], B_Q14[0]);
            LTP_pred_Q13 = ROPUS_SILK_SMLAWB(LTP_pred_Q13,
               pred_lag_ptr[-1], B_Q14[1]);
            LTP_pred_Q13 = ROPUS_SILK_SMLAWB(LTP_pred_Q13,
               pred_lag_ptr[-2], B_Q14[2]);
            LTP_pred_Q13 = ROPUS_SILK_SMLAWB(LTP_pred_Q13,
               pred_lag_ptr[-3], B_Q14[3]);
            LTP_pred_Q13 = ROPUS_SILK_SMLAWB(LTP_pred_Q13,
               pred_lag_ptr[-4], B_Q14[4]);
            pred_lag_ptr++;
            pres_Q14[i] = pexc_Q14[i]
               + (int32_t)((uint32_t)LTP_pred_Q13 << 1);
            sLTP_Q15[sLTP_buf_idx] =
               (int32_t)((uint32_t)pres_Q14[i] << 1);
            sLTP_buf_idx++;
         }
      }
      else
         pres_Q14 = pexc_Q14;

      for (i = 0; i < st->subfr_length; i++)
      {
         LPC_pred_Q10 = st->LPC_order >> 1;
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 1], A_Q12_tmp[0]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 2], A_Q12_tmp[1]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 3], A_Q12_tmp[2]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 4], A_Q12_tmp[3]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 5], A_Q12_tmp[4]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 6], A_Q12_tmp[5]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 7], A_Q12_tmp[6]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 8], A_Q12_tmp[7]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 9], A_Q12_tmp[8]);
         LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
            sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 10], A_Q12_tmp[9]);
         if (st->LPC_order == 16)
         {
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 11],
               A_Q12_tmp[10]);
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 12],
               A_Q12_tmp[11]);
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 13],
               A_Q12_tmp[12]);
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 14],
               A_Q12_tmp[13]);
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 15],
               A_Q12_tmp[14]);
            LPC_pred_Q10 = ROPUS_SILK_SMLAWB(LPC_pred_Q10,
               sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i - 16],
               A_Q12_tmp[15]);
         }
         sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i] = ropus_silk_add_sat32(
            pres_Q14[i], ropus_silk_lshift_sat32(LPC_pred_Q10, 4));
         pxq[i] = (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(
            ROPUS_SILK_SMULWW(sLPC_Q14[ROPUS_SILK_MAX_LPC_ORDER + i],
               Gain_Q10), 8));
      }
      memcpy(sLPC_Q14, &sLPC_Q14[st->subfr_length],
         ROPUS_SILK_MAX_LPC_ORDER * sizeof(int32_t));
      pexc_Q14 += st->subfr_length;
      pxq += st->subfr_length;
   }
   memcpy(st->sLPC_Q14_buf, sLPC_Q14,
      ROPUS_SILK_MAX_LPC_ORDER * sizeof(int32_t));
}

/* ==================================================================== */
/* SILK resampler (silk/resampler*.c), decoder paths.                   */
/* ==================================================================== */
static const int16_t ropus_resampler_up2_hq_0[3] =
   { 1746, 14986, 39083 - 65536 };
static const int16_t ropus_resampler_up2_hq_1[3] =
   { 6854, 25769, 55542 - 65536 };

#define ROPUS_RESAMPLER_ORDER_FIR_12   8
#define ROPUS_RESAMPLER_MAX_BATCH_MS   10

typedef struct
{
   int32_t sIIR[6];
   int16_t sFIR_i16[36];    /* covers FIR_12 (8) and down-FIR orders    */
   int32_t sFIR_i32[36];
   int16_t delayBuf[48];
   int resampler_function;  /* 0 copy, 1 up2_HQ, 2 IIR_FIR, 3 down_FIR */
   int batchSize;
   int32_t invRatio_Q16;
   int FIR_Order, FIR_Fracs;
   int Fs_in_kHz, Fs_out_kHz;
   int inputDelay;
   const int16_t *Coefs;
} ropus_silk_resampler;

static const int8_t ropus_delay_matrix_dec[3][5] =
{
   { 4, 0, 2, 0, 0 },
   { 0, 9, 4, 7, 4 },
   { 0, 3, 12, 7, 7 }
};

static INLINE int ropus_rate_id(int32_t Fs_Hz)
{
   /* rateID(R) from resampler.c: ( ((R>>12) - (R>16000)) >> (R>24000) ) - 1
      maps 8000->0,12000->1,16000->2,24000->3,48000->4                  */
   return (((Fs_Hz >> 12) - (Fs_Hz > 16000)) >> (Fs_Hz > 24000)) - 1;
}

static int ropus_silk_resampler_init(ropus_silk_resampler *S,
      int32_t Fs_Hz_in, int32_t Fs_Hz_out)
{
   int up2x;
   memset(S, 0, sizeof(*S));
   S->inputDelay = ropus_delay_matrix_dec[ropus_rate_id(Fs_Hz_in)]
      [ropus_rate_id(Fs_Hz_out)];
   S->Fs_in_kHz = Fs_Hz_in / 1000;
   S->Fs_out_kHz = Fs_Hz_out / 1000;
   S->batchSize = S->Fs_in_kHz * ROPUS_RESAMPLER_MAX_BATCH_MS;
   up2x = 0;
   if (Fs_Hz_out > Fs_Hz_in)
   {
      if (Fs_Hz_out == Fs_Hz_in * 2)
         S->resampler_function = 1;
      else
      {
         S->resampler_function = 2;
         up2x = 1;
      }
   }
   else if (Fs_Hz_out < Fs_Hz_in)
   {
      S->resampler_function = 3;
      if (Fs_Hz_out * 4 == Fs_Hz_in * 3)
      {
         S->FIR_Fracs = 3;
         S->FIR_Order = 18;
         S->Coefs = ropus_resampler_3_4_COEFS;
      }
      else if (Fs_Hz_out * 3 == Fs_Hz_in * 2)
      {
         S->FIR_Fracs = 2;
         S->FIR_Order = 18;
         S->Coefs = ropus_resampler_2_3_COEFS;
      }
      else if (Fs_Hz_out * 2 == Fs_Hz_in)
      {
         S->FIR_Fracs = 1;
         S->FIR_Order = 24;
         S->Coefs = ropus_resampler_1_2_COEFS;
      }
      else if (Fs_Hz_out * 3 == Fs_Hz_in)
      {
         S->FIR_Fracs = 1;
         S->FIR_Order = 36;
         S->Coefs = ropus_resampler_1_3_COEFS;
      }
      else if (Fs_Hz_out * 4 == Fs_Hz_in)
      {
         S->FIR_Fracs = 1;
         S->FIR_Order = 36;
         S->Coefs = ropus_resampler_1_4_COEFS;
      }
      else if (Fs_Hz_out * 6 == Fs_Hz_in)
      {
         S->FIR_Fracs = 1;
         S->FIR_Order = 36;
         S->Coefs = ropus_resampler_1_6_COEFS;
      }
      else
         return -1;
   }
   else
      S->resampler_function = 0;
   S->invRatio_Q16 = (int32_t)((uint32_t)(
      (int32_t)((uint32_t)Fs_Hz_in << (14 + up2x)) / Fs_Hz_out) << 2);
   while (ROPUS_SILK_SMULWW(S->invRatio_Q16, Fs_Hz_out)
         < (int32_t)((uint32_t)Fs_Hz_in << up2x))
      S->invRatio_Q16++;
   return 0;
}

static void ropus_resampler_up2_HQ(int32_t *S, int16_t *out,
      const int16_t *in, int32_t len)
{
   int32_t k, in32, out32_1, out32_2, Y, X;
   for (k = 0; k < len; k++)
   {
      in32 = (int32_t)((uint32_t)in[k] << 10);
      Y = in32 - S[0];
      X = ROPUS_SILK_SMULWB(Y, ropus_resampler_up2_hq_0[0]);
      out32_1 = S[0] + X;
      S[0] = in32 + X;
      Y = out32_1 - S[1];
      X = ROPUS_SILK_SMULWB(Y, ropus_resampler_up2_hq_0[1]);
      out32_2 = S[1] + X;
      S[1] = out32_1 + X;
      Y = out32_2 - S[2];
      X = ROPUS_SILK_SMLAWB(Y, Y, ropus_resampler_up2_hq_0[2]);
      out32_1 = S[2] + X;
      S[2] = out32_2 + X;
      out[2 * k] = (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(out32_1, 10));
      Y = in32 - S[3];
      X = ROPUS_SILK_SMULWB(Y, ropus_resampler_up2_hq_1[0]);
      out32_1 = S[3] + X;
      S[3] = in32 + X;
      Y = out32_1 - S[4];
      X = ROPUS_SILK_SMULWB(Y, ropus_resampler_up2_hq_1[1]);
      out32_2 = S[4] + X;
      S[4] = out32_1 + X;
      Y = out32_2 - S[5];
      X = ROPUS_SILK_SMLAWB(Y, Y, ropus_resampler_up2_hq_1[2]);
      out32_1 = S[5] + X;
      S[5] = out32_2 + X;
      out[2 * k + 1] =
         (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(out32_1, 10));
   }
}

static int16_t *ropus_resampler_IIR_FIR_interpol(int16_t *out,
      int16_t *buf, int32_t max_index_Q16, int32_t index_increment_Q16)
{
   int32_t index_Q16, res_Q15, table_index;
   int16_t *buf_ptr;
   for (index_Q16 = 0; index_Q16 < max_index_Q16;
        index_Q16 += index_increment_Q16)
   {
      table_index = ROPUS_SILK_SMULWB(index_Q16 & 0xFFFF, 12);
      buf_ptr = &buf[index_Q16 >> 16];
      res_Q15 = ROPUS_SILK_SMULBB(buf_ptr[0],
         ropus_resampler_frac_FIR_12[table_index][0]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[1],
         ropus_resampler_frac_FIR_12[table_index][1]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[2],
         ropus_resampler_frac_FIR_12[table_index][2]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[3],
         ropus_resampler_frac_FIR_12[table_index][3]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[4],
         ropus_resampler_frac_FIR_12[11 - table_index][3]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[5],
         ropus_resampler_frac_FIR_12[11 - table_index][2]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[6],
         ropus_resampler_frac_FIR_12[11 - table_index][1]);
      res_Q15 = ROPUS_SILK_SMLABB(res_Q15, buf_ptr[7],
         ropus_resampler_frac_FIR_12[11 - table_index][0]);
      *out++ = (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(res_Q15, 15));
   }
   return out;
}

static void ropus_resampler_IIR_FIR(ropus_silk_resampler *S, int16_t *out,
      const int16_t *in, int32_t inLen)
{
   int32_t nSamplesIn, max_index_Q16, index_increment_Q16;
   int16_t buf[2 * 160 + ROPUS_RESAMPLER_ORDER_FIR_12];
   memcpy(buf, S->sFIR_i16,
      ROPUS_RESAMPLER_ORDER_FIR_12 * sizeof(int16_t));
   index_increment_Q16 = S->invRatio_Q16;
   for (;;)
   {
      nSamplesIn = ropus_imin(inLen, S->batchSize);
      ropus_resampler_up2_HQ(S->sIIR,
         &buf[ROPUS_RESAMPLER_ORDER_FIR_12], in, nSamplesIn);
      max_index_Q16 = (int32_t)((uint32_t)nSamplesIn << (16 + 1));
      out = ropus_resampler_IIR_FIR_interpol(out, buf, max_index_Q16,
         index_increment_Q16);
      in += nSamplesIn;
      inLen -= nSamplesIn;
      if (inLen > 0)
         memcpy(buf, &buf[nSamplesIn << 1],
            ROPUS_RESAMPLER_ORDER_FIR_12 * sizeof(int16_t));
      else
         break;
   }
   memcpy(S->sFIR_i16, &buf[nSamplesIn << 1],
      ROPUS_RESAMPLER_ORDER_FIR_12 * sizeof(int16_t));
}

static int ropus_silk_resampler_run(ropus_silk_resampler *S, int16_t *out,
      const int16_t *in, int32_t inLen)
{
   int nSamples = S->Fs_in_kHz - S->inputDelay;
   memcpy(&S->delayBuf[S->inputDelay], in, nSamples * sizeof(int16_t));
   switch (S->resampler_function)
   {
      case 1:
         ropus_resampler_up2_HQ(S->sIIR, out, S->delayBuf, S->Fs_in_kHz);
         ropus_resampler_up2_HQ(S->sIIR, &out[S->Fs_out_kHz],
            &in[nSamples], inLen - S->Fs_in_kHz);
         break;
      case 2:
         ropus_resampler_IIR_FIR(S, out, S->delayBuf, S->Fs_in_kHz);
         ropus_resampler_IIR_FIR(S, &out[S->Fs_out_kHz], &in[nSamples],
            inLen - S->Fs_in_kHz);
         break;
      default:
         memcpy(out, S->delayBuf, S->Fs_in_kHz * sizeof(int16_t));
         memcpy(&out[S->Fs_out_kHz], &in[nSamples],
            (inLen - S->Fs_in_kHz) * sizeof(int16_t));
         break;
   }
   memcpy(S->delayBuf, &in[inLen - S->inputDelay],
      S->inputDelay * sizeof(int16_t));
   return 0;
}

/* ==================================================================== */
/* SILK decoder setup (decoder_set_fs.c subset).                        */
/* ==================================================================== */
static void ropus_silk_set_fs(ropus_silk_state *st, int fs_kHz,
      int nb_subfr)
{
   st->fs_kHz = fs_kHz;
   st->nb_subfr = nb_subfr;
   st->frame_length = 5 * nb_subfr * fs_kHz;
   st->subfr_length = 5 * fs_kHz;
   st->ltp_mem_length = 20 * fs_kHz;
   if (fs_kHz == 16)
   {
      st->LPC_order = 16;
      st->pitch_lag_low_bits_iCDF = ropus_uniform8_iCDF;
   }
   else if (fs_kHz == 12)
   {
      st->LPC_order = 10;
      st->pitch_lag_low_bits_iCDF = ropus_uniform6_iCDF;
   }
   else
   {
      st->LPC_order = 10;
      st->pitch_lag_low_bits_iCDF = ropus_uniform4_iCDF;
   }
   if (nb_subfr == 4)
      st->pitch_contour_iCDF = fs_kHz == 8
         ? ropus_pitch_contour_NB_iCDF : ropus_pitch_contour_iCDF;
   else
      st->pitch_contour_iCDF = fs_kHz == 8
         ? ropus_pitch_contour_10_ms_NB_iCDF
         : ropus_pitch_contour_10_ms_iCDF;
   st->psNLSF_CB = fs_kHz == 16 ? &ropus_nlsf_cb_wb : &ropus_nlsf_cb_nb_mb;
}

/* ==================================================================== */
/* SILK stereo (stereo_decode_pred.c, stereo_MS_to_LR.c, dec_API.c).    */
/* ==================================================================== */
static void ropus_silk_stereo_decode_pred(ropus_ec *dec,
      int32_t *pred_Q13)
{
   int n, ix[2][3];
   int32_t low_Q13, step_Q13;
   n = ropus_ec_dec_icdf(dec, ropus_stereo_pred_joint_iCDF, 8);
   ix[0][2] = n / 5;
   ix[1][2] = n - 5 * ix[0][2];
   for (n = 0; n < 2; n++)
   {
      ix[n][0] = ropus_ec_dec_icdf(dec, ropus_uniform3_iCDF, 8);
      ix[n][1] = ropus_ec_dec_icdf(dec, ropus_uniform5_iCDF, 8);
   }
   for (n = 0; n < 2; n++)
   {
      ix[n][0] += 3 * ix[n][2];
      low_Q13 = ropus_stereo_pred_quant_Q13[ix[n][0]];
      step_Q13 = ROPUS_SILK_SMULWB(
         ropus_stereo_pred_quant_Q13[ix[n][0] + 1] - low_Q13, 6554);
      pred_Q13[n] = ROPUS_SILK_SMLABB(low_Q13, step_Q13, 2 * ix[n][1] + 1);
   }
   pred_Q13[0] -= pred_Q13[1];
}

typedef struct
{
   int16_t pred_prev_Q13[2];
   int16_t sMid[2], sSide[2];
} ropus_silk_stereo;

static void ropus_silk_ms_to_lr(ropus_silk_stereo *state, int16_t *x1,
      int16_t *x2, const int32_t *pred_Q13, int fs_kHz, int frame_length)
{
   int n, denom_Q16, delta0_Q13, delta1_Q13;
   int32_t sum, diff, pred0_Q13, pred1_Q13;
   memcpy(x1, state->sMid, 2 * sizeof(int16_t));
   memcpy(x2, state->sSide, 2 * sizeof(int16_t));
   memcpy(state->sMid, &x1[frame_length], 2 * sizeof(int16_t));
   memcpy(state->sSide, &x2[frame_length], 2 * sizeof(int16_t));
   pred0_Q13 = state->pred_prev_Q13[0];
   pred1_Q13 = state->pred_prev_Q13[1];
   denom_Q16 = ((int32_t)1 << 16) / (8 * fs_kHz);
   delta0_Q13 = ROPUS_SILK_RSHIFT_ROUND(ROPUS_SILK_SMULBB(
      pred_Q13[0] - state->pred_prev_Q13[0], denom_Q16), 16);
   delta1_Q13 = ROPUS_SILK_RSHIFT_ROUND(ROPUS_SILK_SMULBB(
      pred_Q13[1] - state->pred_prev_Q13[1], denom_Q16), 16);
   for (n = 0; n < 8 * fs_kHz; n++)
   {
      pred0_Q13 += delta0_Q13;
      pred1_Q13 += delta1_Q13;
      sum = (int32_t)((uint32_t)(x1[n] + (int32_t)x1[n + 2]
         + ((int32_t)((uint32_t)x1[n + 1] << 1))) << 9);
      sum = ROPUS_SILK_SMLAWB((int32_t)((uint32_t)x2[n + 1] << 8),
         sum, pred0_Q13);
      sum = ROPUS_SILK_SMLAWB(sum,
         (int32_t)((uint32_t)x1[n + 1] << 11), pred1_Q13);
      x2[n + 1] = (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(sum, 8));
   }
   pred0_Q13 = pred_Q13[0];
   pred1_Q13 = pred_Q13[1];
   for (n = 8 * fs_kHz; n < frame_length; n++)
   {
      sum = (int32_t)((uint32_t)(x1[n] + (int32_t)x1[n + 2]
         + ((int32_t)((uint32_t)x1[n + 1] << 1))) << 9);
      sum = ROPUS_SILK_SMLAWB((int32_t)((uint32_t)x2[n + 1] << 8),
         sum, pred0_Q13);
      sum = ROPUS_SILK_SMLAWB(sum,
         (int32_t)((uint32_t)x1[n + 1] << 11), pred1_Q13);
      x2[n + 1] = (int16_t)ROPUS_SILK_SAT16(ROPUS_SILK_RSHIFT_ROUND(sum, 8));
   }
   state->pred_prev_Q13[0] = (int16_t)pred_Q13[0];
   state->pred_prev_Q13[1] = (int16_t)pred_Q13[1];
   for (n = 0; n < frame_length; n++)
   {
      sum = x1[n + 1] + (int32_t)x2[n + 1];
      diff = x1[n + 1] - (int32_t)x2[n + 1];
      x1[n + 1] = (int16_t)ROPUS_SILK_SAT16(sum);
      x2[n + 1] = (int16_t)ROPUS_SILK_SAT16(diff);
   }
}

/* Two-channel SILK decoder wrapper (dec_API.c silk_Decode, no loss).   */
typedef struct
{
   ropus_silk_state ch[2];
   int32_t prev_gain_Q16[2];
   ropus_silk_resampler resampler[2];
   ropus_silk_stereo sStereo;
   int nChannelsInternal;
   int prev_decode_only_middle;

   /* Decode scratch, per state rather than per call: these were the
    * decode-path stack frames (sLTP alone is 3.2 KiB with its Q15
    * shadow) on the audio task thread, against the tree's 8 KiB
    * floor.  All four are transient within one call -- buf spans the
    * MS->LR step inside one ropus_silk2_decode, the others live
    * within one channel's frame decode -- and channels decode
    * sequentially, so one set serves both. */
   int16_t scr_buf[2][2 + ROPUS_SILK_MAX_FRAME_LEN];
   int16_t scr_pulses[ROPUS_SILK_MAX_FRAME_LEN + ROPUS_SILK_SHELL_LEN];
   int16_t scr_sLTP[20 * 16];
   int32_t scr_sLTP_Q15[20 * 16 + ROPUS_SILK_MAX_FRAME_LEN];
} ropus_silk2;

static void ropus_silk2_init(ropus_silk2 *s)
{
   int n;
   memset(s, 0, sizeof(*s));
   for (n = 0; n < 2; n++)
   {
      s->ch[n].lagPrev = 100;
      s->ch[n].LastGainIndex = 10;
      s->ch[n].first_frame_after_reset = 1;
      s->prev_gain_Q16[n] = 65536;
   }
   s->nChannelsInternal = 0;
}

static void ropus_silk2_decode_frame_ch(ropus_silk2 *s, int n,
      ropus_ec *dec, int16_t *pOut, int condCoding)
{
   ropus_silk_state *st = &s->ch[n];
   ropus_silk_ctrl ctrl;
   int16_t *pulses = s->scr_pulses;
   int mv_len;
   memset(&ctrl, 0, sizeof ctrl);
   ropus_silk_decode_indices(st, dec, st->nFramesDecoded, 0, condCoding);
   ropus_silk_decode_pulses(dec, pulses, st->indices.signalType,
      st->indices.quantOffsetType, st->frame_length);
   ropus_silk_decode_parameters(st, &ctrl, condCoding);
   ropus_silk_decode_core(st, &ctrl, pOut, pulses, &s->prev_gain_Q16[n],
      s->scr_sLTP, s->scr_sLTP_Q15);
   st->prevSignalType = st->indices.signalType;
   st->first_frame_after_reset = 0;
   mv_len = st->ltp_mem_length - st->frame_length;
   memmove(st->outBuf, &st->outBuf[st->frame_length],
      mv_len * sizeof(int16_t));
   memcpy(&st->outBuf[mv_len], pOut,
      st->frame_length * sizeof(int16_t));
   st->lagPrev = ctrl.pitchL[st->nb_subfr - 1];
}

/* Decode one frame of a SILK packet (mono or stereo) to 48 kHz
 * interleaved-by-caller output: out48[ch] buffers.
 * Returns per-channel 48 kHz sample count or <0.                       */
static int ropus_silk2_decode(ropus_silk2 *s, ropus_ec *dec,
      int16_t *out48_l, int16_t *out48_r, int nch, int fs_kHz,
      int nb_subfr, int nFramesPerPacket, int newPacket)
{
   int i, n, nOut, frame_length;
   int32_t MS_pred_Q13[2] = { 0, 0 };
   int decode_only_middle = 0, has_side;
   int16_t (*buf)[2 + ROPUS_SILK_MAX_FRAME_LEN] = s->scr_buf;

   if (newPacket)
      for (n = 0; n < nch; n++)
         s->ch[n].nFramesDecoded = 0;
   if (nch > s->nChannelsInternal && s->nChannelsInternal > 0)
   {
      /* mono -> stereo transition: reset side channel */
      memset(&s->ch[1], 0, sizeof(s->ch[1]));
      s->ch[1].lagPrev = 100;
      s->ch[1].LastGainIndex = 10;
      s->ch[1].first_frame_after_reset = 1;
      s->prev_gain_Q16[1] = 65536;
   }
   if (s->ch[0].nFramesDecoded == 0)
      for (n = 0; n < nch; n++)
      {
         if (s->ch[n].fs_kHz != fs_kHz || s->ch[n].nb_subfr != nb_subfr)
         {
            ropus_silk_set_fs(&s->ch[n], fs_kHz, nb_subfr);
            ropus_silk_resampler_init(&s->resampler[n],
               fs_kHz * 1000, 48000);
         }
         s->ch[n].nFramesPerPacket = nFramesPerPacket;
      }
   s->nChannelsInternal = nch;
   frame_length = s->ch[0].frame_length;

   if (newPacket)
   {
      for (n = 0; n < nch; n++)
      {
         for (i = 0; i < nFramesPerPacket; i++)
            s->ch[n].VAD_flags[i] = ropus_ec_dec_bit_logp(dec, 1);
         s->ch[n].LBRR_flag = ropus_ec_dec_bit_logp(dec, 1);
         if (s->ch[n].LBRR_flag)
            return -1;
      }
   }

   if (nch == 2)
   {
      ropus_silk_stereo_decode_pred(dec, MS_pred_Q13);
      if (s->ch[1].VAD_flags[s->ch[0].nFramesDecoded] == 0)
         decode_only_middle = ropus_ec_dec_icdf(dec,
            ropus_stereo_only_code_mid_iCDF, 8);
      else
         decode_only_middle = 0;
      if (decode_only_middle == 0 && s->prev_decode_only_middle == 1)
      {
         memset(s->ch[1].outBuf, 0, sizeof(s->ch[1].outBuf));
         memset(s->ch[1].sLPC_Q14_buf, 0, sizeof(s->ch[1].sLPC_Q14_buf));
         s->ch[1].lagPrev = 100;
         s->ch[1].LastGainIndex = 10;
         s->ch[1].prevSignalType = 0;
         s->ch[1].first_frame_after_reset = 1;
      }
   }

   has_side = !decode_only_middle;
   for (n = 0; n < nch; n++)
   {
      if (n == 0 || has_side)
      {
         int FrameIndex = s->ch[0].nFramesDecoded - n;
         int condCoding;
         if (FrameIndex <= 0)
            condCoding = 0;
         else if (n > 0 && s->prev_decode_only_middle)
            condCoding = 1;   /* CODE_INDEPENDENTLY_NO_LTP_SCALING     */
         else
            condCoding = 2;
         ropus_silk2_decode_frame_ch(s, n, dec, &buf[n][2], condCoding);
      }
      else
         memset(&buf[n][2], 0, frame_length * sizeof(int16_t));
      s->ch[n].nFramesDecoded++;
   }

   if (nch == 2)
      ropus_silk_ms_to_lr(&s->sStereo, buf[0], buf[1], MS_pred_Q13,
         fs_kHz, frame_length);
   else
   {
      memcpy(buf[0], s->sStereo.sMid, 2 * sizeof(int16_t));
      memcpy(s->sStereo.sMid, &buf[0][frame_length],
         2 * sizeof(int16_t));
   }
   s->prev_decode_only_middle = decode_only_middle;

   nOut = frame_length * 48 / fs_kHz;
   ropus_silk_resampler_run(&s->resampler[0], out48_l, &buf[0][1],
      frame_length);
   if (nch == 2)
      ropus_silk_resampler_run(&s->resampler[1], out48_r, &buf[1][1],
      frame_length);
   return nOut;
}

/* ==================================================================== */
/* Top-level Opus decoder, s16 pipeline (src/opus_decoder.c, no PLC).   */
/* Handles SILK-only, hybrid and CELT-only packets, in-band redundancy, */
/* and SILK<->hybrid mode switching.  CELT-only<->other transitions     */
/* currently decode without the 2.5 ms PLC crossfade (loss-free media   */
/* streams from typical encoders carry redundancy there instead).       */
/* ==================================================================== */
#define ROPUS_MODE_SILK   0
#define ROPUS_MODE_HYBRID 1
#define ROPUS_MODE_CELT   2

typedef struct
{
   int channels;            /* API channels (1/2)                       */
   int stream_channels;
   int prev_mode;           /* 0 = none yet                             */
   int prev_redundancy;
   ropus_celt_q celt;
   ropus_silk2 silk;
} ropus_dec_q;

static void ropus_dec_q_init(ropus_dec_q *st, int channels)
{
   memset(st, 0, sizeof(*st));
   st->channels = channels;
   st->stream_channels = channels;
   ropus_celt_init_q(&st->celt, channels);
   ropus_silk2_init(&st->silk);
   st->prev_mode = -1;
}

static void ropus_celt_reset_q(ropus_celt_q *st)
{
   int start = st->start, end = st->end;
   int sc = st->stream_channels, ch = st->channels;
   ropus_celt_init_q(st, ch);
   st->start = start;
   st->end = end;
   st->stream_channels = sc;
}

static void ropus_smooth_fade_q(const int16_t *in1, const int16_t *in2,
      int16_t *out, int overlap, int channels)
{
   int i, c;
   for (c = 0; c < channels; c++)
      for (i = 0; i < overlap; i++)
      {
         int16_t w = (int16_t)ROPUS_MULT16_16_Q15(
            ropus_window120_q15[i], ropus_window120_q15[i]);
         out[i * channels + c] = (int16_t)((
            ROPUS_MULT16_16(w, in2[i * channels + c])
            + ROPUS_MULT16_16((int16_t)(32767 - w),
               in1[i * channels + c])) >> 15);
      }
}

/* Decode one frame of an Opus packet.  data/len cover the frame's
 * bytes; toc_* give the packet TOC properties.  pcm receives
 * frame_size48 interleaved s16 samples at 48 kHz.                      */
static int ropus_decode_frame_q(ropus_dec_q *st,
      ropus_frame_scratch *scr, const uint8_t *data,
      int32_t len, int16_t *pcm, int frame_size48, int mode,
      int bandwidth, int stream_channels, int nfp, int newPacket)
{
   ropus_ec dec;
   int i, audiosize = frame_size48;
   int redundancy = 0, redundancy_bytes = 0, celt_to_silk = 0;
   int start_band = 0;
   int F2_5 = 120, F5 = 240, F20 = 960;
   int celt_accum;
   int16_t *redundant_audio = scr->redundant.q;
   int celt_ret = 0;

   st->stream_channels = stream_channels;
   ropus_ec_dec_init(&dec, data, len);

   celt_accum = (mode != ROPUS_MODE_CELT) && (frame_size48 >= 480);

   /* SILK part */
   if (mode != ROPUS_MODE_CELT)
   {
      int fs_khz, nb_subfr;
      if (st->prev_mode == ROPUS_MODE_CELT)
         ropus_silk2_init(&st->silk);
      if (mode == ROPUS_MODE_HYBRID)
         fs_khz = 16;
      else
         fs_khz = bandwidth == 0 ? 8 : (bandwidth == 1 ? 12 : 16);
      nb_subfr = audiosize == 480 ? 2 : 4;   /* 10 ms vs 20 ms frame   */
      if (!celt_accum)
         return -10;                     /* frames < 10 ms in hybrid:  */
                                         /* unsupported (never emitted)*/
      memset(pcm, 0, audiosize * st->channels * sizeof(int16_t));
      {
         int16_t *bl = scr->bl;
         int16_t *br = scr->br;
         int fr, done = 0;
         for (fr = 0; fr < nfp; fr++)
         {
            int r = ropus_silk2_decode(&st->silk, &dec, bl, br,
               st->stream_channels, fs_khz, nb_subfr, nfp,
               newPacket && fr == 0);
            if (r <= 0)
               return -2;
            if (st->stream_channels == 2 && st->channels == 2)
               for (i = 0; i < r; i++)
               {
                  pcm[2 * (done + i)] = bl[i];
                  pcm[2 * (done + i) + 1] = br[i];
               }
            else if (st->channels == 2)
               for (i = 0; i < r; i++)
                  pcm[2 * (done + i)] = pcm[2 * (done + i) + 1] = bl[i];
            else
               memcpy(pcm + done, bl, r * sizeof(int16_t));
            done += r;
         }
      }
   }

   if (mode == ROPUS_MODE_HYBRID)
      start_band = 17;

   /* In-band redundancy parse */
   if (mode != ROPUS_MODE_CELT && data != NULL
         && ropus_ec_tell(&dec) + 17
            + 20 * (mode == ROPUS_MODE_HYBRID) <= 8 * len)
   {
      if (mode == ROPUS_MODE_HYBRID)
         redundancy = ropus_ec_dec_bit_logp(&dec, 12);
      else
         redundancy = 1;
      if (redundancy)
      {
         celt_to_silk = ropus_ec_dec_bit_logp(&dec, 1);
         redundancy_bytes = mode == ROPUS_MODE_HYBRID
            ? (int32_t)ropus_ec_dec_uint(&dec, 256) + 2
            : len - ((ropus_ec_tell(&dec) + 7) >> 3);
         len -= redundancy_bytes;
         if (len * 8 < ropus_ec_tell(&dec))
         {
            len = 0;
            redundancy_bytes = 0;
            redundancy = 0;
         }
         dec.storage -= redundancy_bytes;
      }
   }

   /* CELT endband by bandwidth */
   {
      static const int8_t endband_tab[5] = { 13, 17, 17, 19, 21 };
      st->celt.end = endband_tab[bandwidth];
   }
   st->celt.stream_channels = st->stream_channels;

   /* redundant CELT frame decoded before the main frame (CELT->SILK)  */
   if (redundancy && celt_to_silk)
   {
      ropus_ec rdec;
      st->celt.start = 0;
      ropus_ec_dec_init(&rdec, data + len, redundancy_bytes);
      ropus_celt_decode_q(&st->celt, scr, data + len, redundancy_bytes,
         redundant_audio, F5, &rdec, 0);
   }

   st->celt.start = start_band;

   if (mode != ROPUS_MODE_SILK)
   {
      int celt_frame_size = ropus_imin(F20, audiosize);
      if (mode != st->prev_mode && st->prev_mode >= 0
            && !st->prev_redundancy)
         ropus_celt_reset_q(&st->celt);              /* RESET_STATE    */
      st->celt.start = start_band;
      st->celt.end = mode == ROPUS_MODE_CELT
         ? st->celt.end : st->celt.end;
      st->celt.stream_channels = st->stream_channels;
      celt_ret = ropus_celt_decode_q(&st->celt, scr, data, len, pcm,
         celt_frame_size, &dec, celt_accum);
   }
   else
   {
      static const uint8_t silence[2] = { 0xFF, 0xFF };
      if (!celt_accum)
         memset(pcm, 0, audiosize * st->channels * sizeof(int16_t));
      if (st->prev_mode == ROPUS_MODE_HYBRID
            && !(redundancy && celt_to_silk && st->prev_redundancy))
      {
         ropus_ec sdec;
         st->celt.start = 0;
         ropus_ec_dec_init(&sdec, silence, 2);
         ropus_celt_decode_q(&st->celt, scr, silence, 2, pcm, F2_5, &sdec,
            celt_accum);
      }
   }

   /* redundant CELT frame decoded after the main frame (SILK->CELT)   */
#ifdef ROPUS_DEBUG_REDAUD
   extern int16_t g_redaud[480]; extern int g_redaud_n;
#endif
   if (redundancy && !celt_to_silk)
   {
      ropus_ec rdec;
      ropus_celt_reset_q(&st->celt);
      st->celt.start = 0;
      ropus_ec_dec_init(&rdec, data + len, redundancy_bytes);
      ropus_celt_decode_q(&st->celt, scr, data + len, redundancy_bytes,
         redundant_audio, F5, &rdec, 0);
#ifdef ROPUS_DEBUG_REDAUD
      { int z; for (z = 0; z < F5 * st->channels; z++) g_redaud[z] = redundant_audio[z]; g_redaud_n = F5 * st->channels; }
#endif
      ropus_smooth_fade_q(pcm + st->channels * (audiosize - F2_5),
         redundant_audio + st->channels * F2_5,
         pcm + st->channels * (audiosize - F2_5), F2_5, st->channels);
   }
   if (redundancy && celt_to_silk
         && (st->prev_mode != ROPUS_MODE_SILK || st->prev_redundancy))
   {
      int c;
      for (c = 0; c < st->channels; c++)
         for (i = 0; i < F2_5; i++)
            pcm[st->channels * i + c] =
               redundant_audio[st->channels * i + c];
      ropus_smooth_fade_q(redundant_audio + st->channels * F2_5,
         pcm + st->channels * F2_5,
         pcm + st->channels * F2_5, F2_5, st->channels);
   }

   st->prev_mode = mode;
   st->prev_redundancy = redundancy && !celt_to_silk;
   return celt_ret < 0 ? celt_ret : audiosize;
}

/* ==================================================================== */
/* Top-level Opus decoder, float pipeline (matches libopus float build).*/
/* ==================================================================== */
typedef struct
{
   int channels;
   int stream_channels;
   int prev_mode;
   int prev_redundancy;
   ropus_celt celt;
   ropus_silk2 silk;
} ropus_dec_f;

static void ropus_dec_f_init(ropus_dec_f *st, int channels)
{
   memset(st, 0, sizeof(*st));
   st->channels = channels;
   st->stream_channels = channels;
   ropus_celt_init(&st->celt, channels);
   ropus_silk2_init(&st->silk);
   st->prev_mode = -1;
}

static void ropus_celt_reset(ropus_celt *st)
{
   int start = st->start, end = st->end;
   int sc = st->stream_channels, ch = st->channels;
   ropus_celt_init(st, ch);
   st->start = start;
   st->end = end;
   st->stream_channels = sc;
}

static void ropus_smooth_fade(const float *in1, const float *in2,
      float *out, int overlap, int channels)
{
   int i, c;
   for (c = 0; c < channels; c++)
      for (i = 0; i < overlap; i++)
      {
         float w = ropus_window120[i] * ropus_window120[i];
         out[i * channels + c] = w * in2[i * channels + c]
            + (1.f - w) * in1[i * channels + c];
      }
}

static int ropus_decode_frame_f(ropus_dec_f *st,
      ropus_frame_scratch *scr, const uint8_t *data,
      int32_t len, float *pcm, int frame_size48, int mode,
      int bandwidth, int stream_channels, int nfp, int newPacket)
{
   ropus_ec dec;
   int i, audiosize = frame_size48;
   int redundancy = 0, redundancy_bytes = 0, celt_to_silk = 0;
   int start_band = 0;
   int F2_5 = 120, F5 = 240, F20 = 960;
   float *redundant_audio = scr->redundant.f;
   int16_t *pcm_silk = scr->pcm_silk;
   int have_silk = 0, silk_n = 0;
   int celt_ret = 0;

   st->stream_channels = stream_channels;
   ropus_ec_dec_init(&dec, data, len);

   if (mode != ROPUS_MODE_CELT)
   {
      int fs_khz, nb_subfr;
      int16_t *bl = scr->bl;
      int16_t *br = scr->br;
      int fr;
      if (st->prev_mode == ROPUS_MODE_CELT)
         ropus_silk2_init(&st->silk);
      if (mode == ROPUS_MODE_HYBRID)
         fs_khz = 16;
      else
         fs_khz = bandwidth == 0 ? 8 : (bandwidth == 1 ? 12 : 16);
      nb_subfr = audiosize == 480 ? 2 : 4;
      for (fr = 0; fr < nfp; fr++)
      {
         int r = ropus_silk2_decode(&st->silk, &dec, bl, br,
            st->stream_channels, fs_khz, nb_subfr, nfp,
            newPacket && fr == 0);
         if (r <= 0)
            return -2;
         if (st->stream_channels == 2 && st->channels == 2)
            for (i = 0; i < r; i++)
            {
               pcm_silk[2 * (silk_n + i)] = bl[i];
               pcm_silk[2 * (silk_n + i) + 1] = br[i];
            }
         else if (st->channels == 2)
            for (i = 0; i < r; i++)
               pcm_silk[2 * (silk_n + i)]
                  = pcm_silk[2 * (silk_n + i) + 1] = bl[i];
         else
            memcpy(pcm_silk + silk_n, bl, r * sizeof(int16_t));
         silk_n += r;
      }
      have_silk = 1;
   }

   if (mode == ROPUS_MODE_HYBRID)
      start_band = 17;

   if (mode != ROPUS_MODE_CELT && data != NULL
         && ropus_ec_tell(&dec) + 17
            + 20 * (mode == ROPUS_MODE_HYBRID) <= 8 * len)
   {
      if (mode == ROPUS_MODE_HYBRID)
         redundancy = ropus_ec_dec_bit_logp(&dec, 12);
      else
         redundancy = 1;
      if (redundancy)
      {
         celt_to_silk = ropus_ec_dec_bit_logp(&dec, 1);
         redundancy_bytes = mode == ROPUS_MODE_HYBRID
            ? (int32_t)ropus_ec_dec_uint(&dec, 256) + 2
            : len - ((ropus_ec_tell(&dec) + 7) >> 3);
         len -= redundancy_bytes;
         if (len * 8 < ropus_ec_tell(&dec))
         {
            len = 0;
            redundancy_bytes = 0;
            redundancy = 0;
         }
         dec.storage -= redundancy_bytes;
      }
   }

   {
      static const int8_t endband_tab[5] = { 13, 17, 17, 19, 21 };
      st->celt.end = endband_tab[bandwidth];
   }
   st->celt.stream_channels = st->stream_channels;

   if (redundancy && celt_to_silk)
   {
      ropus_ec rdec;
      st->celt.start = 0;
      ropus_ec_dec_init(&rdec, data + len, redundancy_bytes);
      ropus_celt_decode(&st->celt, scr, data + len, redundancy_bytes,
         redundant_audio, F5, &rdec);
   }

   st->celt.start = start_band;

   if (mode != ROPUS_MODE_SILK)
   {
      int celt_frame_size = ropus_imin(F20, audiosize);
      if (mode != st->prev_mode && st->prev_mode >= 0
            && !st->prev_redundancy)
         ropus_celt_reset(&st->celt);
      celt_ret = ropus_celt_decode(&st->celt, scr, data, len, pcm,
         celt_frame_size, &dec);
   }
   else
   {
      static const uint8_t silence[2] = { 0xFF, 0xFF };
      for (i = 0; i < audiosize * st->channels; i++)
         pcm[i] = 0;
      if (st->prev_mode == ROPUS_MODE_HYBRID
            && !(redundancy && celt_to_silk && st->prev_redundancy))
      {
         ropus_ec sdec;
         st->celt.start = 0;
         ropus_ec_dec_init(&sdec, silence, 2);
         ropus_celt_decode(&st->celt, scr, silence, 2, pcm, F2_5, &sdec);
      }
   }

   if (have_silk)
      for (i = 0; i < silk_n * st->channels; i++)
         pcm[i] = pcm[i] + (1.f / 32768.f) * pcm_silk[i];

   if (redundancy && !celt_to_silk)
   {
      ropus_ec rdec;
      ropus_celt_reset(&st->celt);
      st->celt.start = 0;
      ropus_ec_dec_init(&rdec, data + len, redundancy_bytes);
      ropus_celt_decode(&st->celt, scr, data + len, redundancy_bytes,
         redundant_audio, F5, &rdec);
      ropus_smooth_fade(pcm + st->channels * (audiosize - F2_5),
         redundant_audio + st->channels * F2_5,
         pcm + st->channels * (audiosize - F2_5), F2_5, st->channels);
   }
   if (redundancy && celt_to_silk
         && (st->prev_mode != ROPUS_MODE_SILK || st->prev_redundancy))
   {
      int c;
      for (c = 0; c < st->channels; c++)
         for (i = 0; i < F2_5; i++)
            pcm[st->channels * i + c] =
               redundant_audio[st->channels * i + c];
      ropus_smooth_fade(redundant_audio + st->channels * F2_5,
         pcm + st->channels * F2_5,
         pcm + st->channels * F2_5, F2_5, st->channels);
   }

   st->prev_mode = mode;
   st->prev_redundancy = redundancy && !celt_to_silk;
   return celt_ret < 0 ? celt_ret : audiosize;
}

/* ==================================================================== */
/* Public API.                                                          */
/* ==================================================================== */
#define ROPUS_FMT_NONE 0
#define ROPUS_FMT_S16  1
#define ROPUS_FMT_F32  2

#include <formats/ropus.h>

/* An Opus stream above stereo is several streams (RFC 7845 s5.1.1):
 * nb_streams substreams, the first nb_coupled of them stereo and the
 * rest mono, decoded independently and then scattered to the output
 * channels by a mapping table.  Family 0 is the degenerate case of one
 * substream, so it runs the same path with nb_streams == 1 and no
 * table.
 *
 * Each substream needs its own decoder state.  They are allocated for
 * the count the header states rather than a worst case, one pipeline's
 * worth being about 24 KB. */
struct ropus
{
   int channels;            /* output channels                          */
   unsigned preskip;
   int gain_q8;
   int fmt;
   int nb_streams;
   int nb_coupled;
   /* Output channel -> decoded channel, or 255 for a silent one.  The
    * identity for family 0. */
   uint8_t mapping[ROPUS_MAX_CHANNELS];
   ropus_dec_q *q;          /* nb_streams of each                       */
   ropus_dec_f *f;
   /* One substream's output, before it is scattered.  Per context, not
    * shared: the mixer runs several voices at once and a static here
    * would have them writing over each other.  Only a multistream
    * context needs it - a single stream decodes straight into the
    * caller's buffer, as it always did. */
   int16_t *sub_q;          /* 5760 * 2, or NULL                        */
   float   *sub_f;
   ropus_frame_scratch fscr;
};

/* Where a substream's channels land in the decoded (pre-mapping)
 * channel order: the coupled streams come first, two channels each. */
static int ropus_stream_base(const ropus_t *o, int s)
{
   return (s < o->nb_coupled) ? s * 2 : o->nb_coupled + s;
}

static int ropus_stream_channels(const ropus_t *o, int s)
{
   return (s < o->nb_coupled) ? 2 : 1;
}

/* Parse an OpusHead (RFC 7845 section 5.1) and create a decoder.       */
ropus_t *ropus_open(const void *head, size_t head_size)
{
   const uint8_t *h = (const uint8_t *)head;
   ropus_t *o;
   int channels, i;
   if (!h || head_size < 19 || memcmp(h, "OpusHead", 8) != 0)
      return NULL;
   if (h[8] != 1)                        /* version                     */
      return NULL;
   channels = h[9];
   if (channels < 1 || channels > ROPUS_MAX_CHANNELS)
      return NULL;
   o = (ropus_t *)calloc(1, sizeof(*o));
   if (!o)
      return NULL;
   o->channels = channels;
   o->preskip = (unsigned)h[10] | ((unsigned)h[11] << 8);
   o->gain_q8 = (int16_t)((unsigned)h[16] | ((unsigned)h[17] << 8));

   if (h[18] == 0)
   {
      /* Family 0: one substream, mono or stereo, no table. */
      if (channels > 2)
      {
         free(o);
         return NULL;
      }
      o->nb_streams = 1;
      o->nb_coupled = channels - 1;
      for (i = 0; i < channels; i++)
         o->mapping[i] = (uint8_t)i;
   }
   else if (h[18] == 1)
   {
      /* Family 1: stream counts and a channel mapping follow the
       * head, one byte per output channel. */
      if (head_size < (size_t)21 + channels)
      {
         free(o);
         return NULL;
      }
      o->nb_streams = h[19];
      o->nb_coupled = h[20];
      if (   o->nb_streams < 1
          || o->nb_coupled < 0
          || o->nb_coupled > o->nb_streams
          || o->nb_streams + o->nb_coupled > ROPUS_MAX_CHANNELS)
      {
         free(o);
         return NULL;
      }
      for (i = 0; i < channels; i++)
      {
         uint8_t m = h[21 + i];
         /* 255 is a channel the mapping leaves silent; anything else
          * has to name a channel some substream actually decodes. */
         if (m != 255 && m >= o->nb_streams + o->nb_coupled)
         {
            free(o);
            return NULL;
         }
         o->mapping[i] = m;
      }
   }
   else
   {
      free(o);                           /* families 2, 3, 255          */
      return NULL;
   }

   o->q = (ropus_dec_q *)calloc((size_t)o->nb_streams, sizeof(*o->q));
   o->f = (ropus_dec_f *)calloc((size_t)o->nb_streams, sizeof(*o->f));
   if (o->nb_streams > 1)
   {
      o->sub_q = (int16_t *)calloc((size_t)ROPUS_MAX_FRAME * 2,
            sizeof(int16_t));
      o->sub_f = (float   *)calloc((size_t)ROPUS_MAX_FRAME * 2,
            sizeof(float));
   }
   if (   !o->q || !o->f
       || (o->nb_streams > 1 && (!o->sub_q || !o->sub_f)))
   {
      free(o->sub_q);
      free(o->sub_f);
      free(o->q);
      free(o->f);
      free(o);
      return NULL;
   }
   for (i = 0; i < o->nb_streams; i++)
   {
      ropus_dec_q_init(&o->q[i], ropus_stream_channels(o, i));
      ropus_dec_f_init(&o->f[i], ropus_stream_channels(o, i));
   }
   return o;
}

void ropus_close(ropus_t *o)
{
   if (o)
   {
      free(o->sub_q);
      free(o->sub_f);
      free(o->q);
      free(o->f);
   }
   free(o);
}

unsigned ropus_channels(const ropus_t *o)
{
   return (unsigned)o->channels;
}

unsigned ropus_preskip(const ropus_t *o)
{
   return o->preskip;
}

void ropus_reset(ropus_t *o)
{
   int i;
   for (i = 0; i < o->nb_streams; i++)
   {
      ropus_dec_q_init(&o->q[i], ropus_stream_channels(o, i));
      ropus_dec_f_init(&o->f[i], ropus_stream_channels(o, i));
   }
   o->fmt = ROPUS_FMT_NONE;
}

/* TOC -> mode / bandwidth-index / silk-frames-per-frame.               */
static void ropus_toc_props(uint8_t toc, int *mode, int *bw, int *nfp)
{
   int config = toc >> 3;
   if (config < 12)
   {
      int dur = config & 3;
      *mode = ROPUS_MODE_SILK;
      *bw = config >> 2;                 /* 0 NB, 1 MB, 2 WB            */
      *nfp = dur <= 1 ? 1 : (dur == 2 ? 2 : 3);
   }
   else if (config < 16)
   {
      *mode = ROPUS_MODE_HYBRID;
      *bw = config < 14 ? 3 : 4;         /* SWB : FB                    */
      *nfp = 1;
   }
   else
   {
      int b = (config >> 2) - 4;         /* 0 NB, 1 WB, 2 SWB, 3 FB     */
      *mode = ROPUS_MODE_CELT;
      *bw = b == 0 ? 0 : b + 1;
      *nfp = 1;
   }
}

/* Decode one Opus packet to interleaved 48 kHz s16.  out must hold
 * 5760 * channels samples (120 ms).  Returns frames or < 0.            */
int ropus_decode_s16(ropus_t *o, const void *pkt, size_t len,
      int16_t *out, size_t out_samples)
{
   ropus_packet pk;
   const uint8_t *d = (const uint8_t *)pkt;
   int32_t left = (int32_t)len;
   int mode, bw, nfp, fr, s, total = 0;
   if (o->fmt == ROPUS_FMT_F32)
      return ROPUS_ERR_FMT;
   o->fmt = ROPUS_FMT_S16;

   /* Each substream is a packet in its own right, laid end to end.
    * All but the last are self-delimited so their extent is known
    * before the next begins. */
   for (s = 0; s < o->nb_streams; s++)
   {
      int      sch  = ropus_stream_channels(o, s);
      int      base = ropus_stream_base(o, s);
      int32_t  used = 0;
      int      got  = 0;
      int      c;
      /* One stream: its channels are the output's, so decode there
       * directly and skip the scatter entirely. */
      int16_t *sub  = o->sub_q ? o->sub_q : out;
      if (ropus_packet_parse(d, left, &pk, s < o->nb_streams - 1,
               &used) < 0)
         return ROPUS_ERR_PACKET;
      /* What this packet can write to out, whether the frames land
       * there directly (one substream) or through the scatter below
       * (several).  Checked before anything is written, and on every
       * substream, they all having to agree on the span anyway. */
      if ((size_t)pk.nframes * (size_t)pk.frame_size
            * (size_t)o->channels > out_samples)
         return ROPUS_ERR_ROOM;
      ropus_toc_props(d[0], &mode, &bw, &nfp);
      for (fr = 0; fr < pk.nframes; fr++)
      {
         int r = ropus_decode_frame_q(&o->q[s], &o->fscr, pk.frames[fr],
            pk.sizes[fr], sub + got * sch, pk.frame_size, mode, bw,
            (d[0] & 4) ? 2 : 1, nfp, 1);
         if (r <= 0)
            return ROPUS_ERR_DECODE;
         got += r;
      }
      /* Every substream of a packet codes the same span; a stream
       * that disagrees is malformed rather than something to mix. */
      if (s == 0)
         total = got;
      else if (got != total)
         return ROPUS_ERR_DECODE;
      /* Scatter this substream's channels to whichever output
       * channels the table points at them. */
      if (sub != out)
         for (c = 0; c < o->channels; c++)
         {
            int m = o->mapping[c];
            int i;
            if (m == 255 || m < base || m >= base + sch)
               continue;
            for (i = 0; i < total; i++)
               out[i * o->channels + c] = sub[i * sch + (m - base)];
         }
      d    += used;
      left -= used;
   }
   /* Channels the mapping leaves out are silent, and nothing above
    * has written them. */
   {
      int c, i;
      for (c = 0; c < o->channels; c++)
         if (o->mapping[c] == 255)
            for (i = 0; i < total; i++)
               out[i * o->channels + c] = 0;
   }
   if (o->gain_q8)
   {
      /* libopus fixed decode_gain path                                 */
      int i;
      int32_t gain = ropus_celt_exp2_q(
         (int16_t)ROPUS_MULT16_16_P15(21771, o->gain_q8));
      for (i = 0; i < total * o->channels; i++)
      {
         int32_t x = (int32_t)((ROPUS_SILK_SMULL(out[i], gain) + 32768) >> 16);
         out[i] = (int16_t)ROPUS_SAT16(x);
      }
   }
   return total;
}

/* Decode one Opus packet to interleaved 48 kHz float.                  */
int ropus_decode_f32(ropus_t *o, const void *pkt, size_t len,
      float *out, size_t out_samples)
{
   ropus_packet pk;
   const uint8_t *d = (const uint8_t *)pkt;
   int32_t left = (int32_t)len;
   int mode, bw, nfp, fr, s, total = 0;
   if (o->fmt == ROPUS_FMT_S16)
      return ROPUS_ERR_FMT;
   o->fmt = ROPUS_FMT_F32;

   /* See the s16 path: substreams end to end, all but the last
    * self-delimited, scattered by the mapping table. */
   for (s = 0; s < o->nb_streams; s++)
   {
      int      sch  = ropus_stream_channels(o, s);
      int      base = ropus_stream_base(o, s);
      int32_t  used = 0;
      int      got  = 0;
      int      c;
      float   *sub  = o->sub_f ? o->sub_f : out;
      if (ropus_packet_parse(d, left, &pk, s < o->nb_streams - 1,
               &used) < 0)
         return ROPUS_ERR_PACKET;
      /* What this packet can write to out, whether the frames land
       * there directly (one substream) or through the scatter below
       * (several).  Checked before anything is written, and on every
       * substream, they all having to agree on the span anyway. */
      if ((size_t)pk.nframes * (size_t)pk.frame_size
            * (size_t)o->channels > out_samples)
         return ROPUS_ERR_ROOM;
      ropus_toc_props(d[0], &mode, &bw, &nfp);
      for (fr = 0; fr < pk.nframes; fr++)
      {
         int r = ropus_decode_frame_f(&o->f[s], &o->fscr, pk.frames[fr],
            pk.sizes[fr], sub + got * sch, pk.frame_size, mode, bw,
            (d[0] & 4) ? 2 : 1, nfp, 1);
         if (r <= 0)
            return ROPUS_ERR_DECODE;
         got += r;
      }
      if (s == 0)
         total = got;
      else if (got != total)
         return ROPUS_ERR_DECODE;
      if (sub != out)
         for (c = 0; c < o->channels; c++)
         {
            int m = o->mapping[c];
            int i;
            if (m == 255 || m < base || m >= base + sch)
               continue;
            for (i = 0; i < total; i++)
               out[i * o->channels + c] = sub[i * sch + (m - base)];
         }
      d    += used;
      left -= used;
   }
   {
      int c, i;
      for (c = 0; c < o->channels; c++)
         if (o->mapping[c] == 255)
            for (i = 0; i < total; i++)
               out[i * o->channels + c] = 0.0f;
   }
   if (o->gain_q8)
   {
      int i;
      float gain = ropus_exp2f(6.48814081e-4f * (float)o->gain_q8);
      for (i = 0; i < total * o->channels; i++)
         out[i] *= gain;
   }
   return total;
}
